using System.Globalization;
using System.Text;

namespace DCAD.Dlayout;

// AutoCAD R12 (AC1009) DXF: simple, widely compatible POLYLINE/VERTEX/SEQEND
// with declared layers and linetype. No R2000-only subclass markers or bare
// orphan entities. Curves remain tessellated just as in the imported outline.
internal static class DxfExporter
{
    public static void Save(string path, Solution solution, int copies, double top, double bottom, double gap)
    {
        if (!Geometry.ValidPeriod(solution.Places, gap, solution.Pitch))
            throw new InvalidDataException("Selected layout fails periodic clearance revalidation.");
        if (copies < 2) throw new InvalidDataException("At least two stations are required.");
        solution = StepPhase.Rebase(solution);
        var inv = CultureInfo.InvariantCulture;
        using StreamWriter writer = new(path, false, Encoding.ASCII);
        void Pair(int code, string value) { writer.WriteLine(code.ToString(inv)); writer.WriteLine(value); }
        void Int(int code, int value) => Pair(code, value.ToString(inv));
        void Num(int code, double value)
        {
            if (!double.IsFinite(value)) throw new InvalidDataException("Non-finite geometry coordinate in DXF.");
            Pair(code, value.ToString("R", inv));
        }
        void Section(string name) { Pair(0, "SECTION"); Pair(2, name); }
        void EndSection() => Pair(0, "ENDSEC");
        void Layer(string name, int aci)
        {
            Pair(0, "LAYER"); Pair(2, name); Int(70, 0);
            Int(62, aci); Pair(6, "CONTINUOUS");
        }
        void Polyline(IReadOnlyList<Pt> polygon, string layer)
        {
            if (polygon.Count < 3) throw new InvalidDataException("Invalid polygon (less than 3 vertices).");
            // 2D closed legacy polyline, supported by AutoCAD and GstarCAD.
            Pair(0, "POLYLINE"); Pair(8, layer);
            Int(62, layer == "DLAYOUT_STEP_RED" ? 1 : layer == "DLAYOUT_STEP_YELLOW" ? 2 : 7);
            Int(66, 1);
            Num(10, 0); Num(20, 0); Num(30, 0); Int(70, 1);
            foreach (var p in polygon)
            {
                Pair(0, "VERTEX"); Pair(8, layer);
                Num(10, p.X); Num(20, p.Y); Num(30, 0); Int(70, 0);
            }
            Pair(0, "SEQEND"); Pair(8, layer);
        }
        void Text(string value, Pt point, double height)
        {
            Pair(0, "TEXT"); Pair(8, "DLAYOUT_INFO");
            Num(10, point.X); Num(20, point.Y); Num(30, 0);
            Num(40, height); Pair(1, value); Pair(7, "STANDARD");
        }

        BBox box = Geometry.Bounds(solution.Places);
        double stripMinY = box.MinY - bottom, stripMaxY = box.MaxY + top;
        double x0 = box.MinX, x1 = box.MaxX + (copies - 1) * solution.Pitch;
        if (x1 <= x0 || stripMaxY <= stripMinY)
            throw new InvalidDataException("Invalid strip extents.");
        Section("HEADER");
        Pair(9, "$ACADVER"); Pair(1, "AC1009");
        Pair(9, "$INSBASE"); Num(10, 0); Num(20, 0); Num(30, 0);
        Pair(9, "$MEASUREMENT"); Int(70, 1);
        Pair(9, "$EXTMIN"); Num(10, x0); Num(20, stripMinY); Num(30, 0);
        Pair(9, "$EXTMAX"); Num(10, x1); Num(20, stripMaxY + 10); Num(30, 0);
        EndSection();
        Section("TABLES");
        Pair(0, "TABLE"); Pair(2, "LTYPE"); Int(70, 1);
        Pair(0, "LTYPE"); Pair(2, "CONTINUOUS"); Int(70, 0);
        Pair(3, "Solid line"); Int(72, 65); Int(73, 0); Num(40, 0);
        Pair(0, "ENDTAB");
        Pair(0, "TABLE"); Pair(2, "LAYER"); Int(70, 5);
        Layer("0", 7); Layer("DLAYOUT_STEP_RED", 1); Layer("DLAYOUT_STEP_YELLOW", 2);
        Layer("DLAYOUT_STRIP", 7); Layer("DLAYOUT_INFO", 7);
        Pair(0, "ENDTAB");
        Pair(0, "TABLE"); Pair(2, "STYLE"); Int(70, 1);
        Pair(0, "STYLE"); Pair(2, "STANDARD"); Int(70, 0);
        Num(40, 0); Num(41, 1); Num(50, 0); Int(71, 0); Num(42, 2.5);
        Pair(3, "txt"); Pair(4, ""); Pair(0, "ENDTAB");
        EndSection();
        Section("BLOCKS"); EndSection();
        Section("ENTITIES");
        for (int cycle = 0; cycle < copies; cycle++)
            foreach (var place in solution.Places)
                Polyline(place.Points.Select(p => new Pt(p.X + cycle * solution.Pitch, p.Y)).ToArray(),
                    cycle == 0 ? "DLAYOUT_STEP_RED" : "DLAYOUT_STEP_YELLOW");
        Polyline([new Pt(x0, stripMinY), new Pt(x1, stripMinY),
            new Pt(x1, stripMaxY), new Pt(x0, stripMaxY)], "DLAYOUT_STRIP");
        double height = Math.Max(0.5, Math.Min(4, solution.StripWidth * .05));
        Text($"DLAYOUT P={solution.Pitch:0.###}  W={solution.StripWidth:0.###}  ETA={solution.Efficiency:0.##}%",
            new Pt(x0, stripMaxY + height * 1.5), height);
        EndSection(); Pair(0, "EOF");
    }
}
