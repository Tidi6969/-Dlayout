
namespace DCAD.Dlayout;

internal readonly record struct Pt(double X, double Y)
{
    public static Pt operator +(Pt a, Pt b) => new(a.X + b.X, a.Y + b.Y);
    public static Pt operator -(Pt a, Pt b) => new(a.X - b.X, a.Y - b.Y);
    public static Pt operator *(Pt a, double k) => new(a.X * k, a.Y * k);
    public double Dist2(Pt b) => (X - b.X) * (X - b.X) + (Y - b.Y) * (Y - b.Y);
    public Pt Rotate(double a) => new(X * Math.Cos(a) - Y * Math.Sin(a), X * Math.Sin(a) + Y * Math.Cos(a));
}

internal readonly record struct BBox(double MinX, double MinY, double MaxX, double MaxY)
{
    public double Width => MaxX - MinX;
    public double Height => MaxY - MinY;
    public static BBox From(IReadOnlyList<Pt> points) => new(points.Min(p => p.X), points.Min(p => p.Y), points.Max(p => p.X), points.Max(p => p.Y));
    public static BBox Union(BBox a, BBox b) => new(Math.Min(a.MinX, b.MinX), Math.Min(a.MinY, b.MinY), Math.Max(a.MaxX, b.MaxX), Math.Max(a.MaxY, b.MaxY));
    public BBox Shift(double dx, double dy = 0) => new(MinX + dx, MinY + dy, MaxX + dx, MaxY + dy);
    public bool Separated(BBox b, double gap) => MaxX + gap < b.MinX || b.MaxX + gap < MinX || MaxY + gap < b.MinY || b.MaxY + gap < MinY;
}

internal sealed class Shape
{
    public required string Handle { get; init; }
    public required Pt OriginalCenter { get; init; }
    public required Pt[] LocalPoints { get; init; }
    public double Area { get; init; }
    public ShapePlace At(Pt center, double degrees)
    {
        double rad = degrees * Math.PI / 180.0;
        Pt[] points = LocalPoints.Select(p => p.Rotate(rad) + center).ToArray();
        return new ShapePlace(this, center, degrees, points, BBox.From(points));
    }
}

internal sealed record ShapePlace(Shape Shape, Pt Center, double AngleDeg, Pt[] Points, BBox Bounds);

internal sealed class Job
{
    public required string Id { get; init; }
    public required List<Shape> Shapes { get; init; }
    public double Gap { get; init; }
    public double Top { get; init; }
    public double Bottom { get; init; }
    public static Job LoadDxfFiles(IEnumerable<string> paths)
    {
        var all = new List<Shape>();
        int i = 0;
        foreach (string file in paths)
        {
            foreach (var src in DxfImporter.Load(file))
            {
                i++;
                all.Add(new Shape { Handle = $"PART_{i:D2}", OriginalCenter = src.OriginalCenter,
                    LocalPoints = src.LocalPoints, Area = src.Area });
            }
        }
        if (all.Count is < 1 or > 12)
            throw new InvalidDataException("Select 1–12 closed separate contours in one or more DXF files.");
        return new Job { Id = Guid.NewGuid().ToString("N"), Shapes = all, Gap = 1, Top = 1, Bottom = 1 };
    }
}

internal static class Geometry
{
    private static double Cross(Pt a, Pt b) => a.X * b.Y - a.Y * b.X;
    private static double Orient(Pt a, Pt b, Pt c) => Cross(b - a, c - a);
    public static double Area(Pt[] p)
    {
        double sum = 0;
        for (int i = 0; i < p.Length; i++) sum += Cross(p[i], p[(i + 1) % p.Length]);
        return sum * 0.5;
    }
    private static bool ProperIntersect(Pt a, Pt b, Pt c, Pt d)
    {
        double a1 = Orient(a, b, c), a2 = Orient(a, b, d);
        double b1 = Orient(c, d, a), b2 = Orient(c, d, b);
        return a1 * a2 < -1e-16 && b1 * b2 < -1e-16;
    }
    public static bool HasSelfIntersection(Pt[] pts)
    {
        for (int i = 0; i < pts.Length; i++)
        for (int j = i + 1; j < pts.Length; j++)
        {
            if (j == i + 1 || (i == 0 && j == pts.Length - 1)) continue;
            if (ProperIntersect(pts[i], pts[(i + 1) % pts.Length], pts[j], pts[(j + 1) % pts.Length])) return true;
        }
        return false;
    }
    private static double SegmentPointDist2(Pt a, Pt b, Pt p)
    {
        Pt ab = b - a, ap = p - a;
        double denom = ab.X * ab.X + ab.Y * ab.Y;
        if (denom <= 1e-20) return p.Dist2(a);
        double t = Math.Clamp((ab.X * ap.X + ab.Y * ap.Y) / denom, 0, 1);
        return p.Dist2(a + ab * t);
    }
    public static double Distance(Pt a, Pt b) => Math.Sqrt(a.Dist2(b));
    public static bool PointInPolygon(Pt p, IReadOnlyList<Pt> poly) => Contains(poly.ToArray(), p);
    private static bool Contains(Pt[] boundary, Pt p)
    {
        bool inside = false;
        for (int i = 0, j = boundary.Length - 1; i < boundary.Length; j = i++)
        {
            Pt a = boundary[i], b = boundary[j];
            if ((a.Y > p.Y) != (b.Y > p.Y) &&
                p.X < (b.X - a.X) * (p.Y - a.Y) / (b.Y - a.Y) + a.X) inside = !inside;
        }
        return inside;
    }
    // Conservative margin covers the tessellation of CAD arc segments (CAD sampling sagitta <= 0.005).
    // Only used to reject candidates, never changes exported source geometry.
    public static bool TooClose(ShapePlace a, ShapePlace b, double gap, double dx = 0)
    {
        double required = gap + 0.01001;
        if (a.Bounds.Separated(b.Bounds.Shift(dx), required)) return false;
        var ap = a.Points; var bp = b.Points;
        if (Contains(ap, bp[0] + new Pt(dx, 0)) || ContainsShift(bp, dx, ap[0])) return true;
        double limit = required * required;
        for (int i = 0; i < ap.Length; i++)
        {
            Pt a1 = ap[i], a2 = ap[(i + 1) % ap.Length];
            for (int j = 0; j < bp.Length; j++)
            {
                Pt b1 = bp[j] + new Pt(dx, 0), b2 = bp[(j + 1) % bp.Length] + new Pt(dx, 0);
                // Segment broad phase: avoid expensive distance calculations
                // for pairs whose X/Y ranges cannot violate clearance.
                if (Math.Max(a1.X, a2.X) + required < Math.Min(b1.X, b2.X) ||
                    Math.Max(b1.X, b2.X) + required < Math.Min(a1.X, a2.X) ||
                    Math.Max(a1.Y, a2.Y) + required < Math.Min(b1.Y, b2.Y) ||
                    Math.Max(b1.Y, b2.Y) + required < Math.Min(a1.Y, a2.Y)) continue;
                if (ProperIntersect(a1, a2, b1, b2)) return true;
                if (SegmentPointDist2(a1, a2, b1) < limit || SegmentPointDist2(a1, a2, b2) < limit ||
                    SegmentPointDist2(b1, b2, a1) < limit || SegmentPointDist2(b1, b2, a2) < limit) return true;
            }
        }
        return false;
    }
    private static bool ContainsShift(Pt[] polygon, double dx, Pt p) => Contains(polygon, p - new Pt(dx, 0));
    public static BBox Bounds(IReadOnlyList<ShapePlace> shapes)
    {
        BBox result = shapes[0].Bounds;
        for (int i = 1; i < shapes.Count; i++) result = BBox.Union(result, shapes[i].Bounds);
        return result;
    }
    public static bool ValidPeriod(IReadOnlyList<ShapePlace> places, double gap, double pitch)
    {
        if (pitch <= 0) return false;
        for (int i = 0; i < places.Count; i++)
            for (int j = i + 1; j < places.Count; j++)
                if (TooClose(places[i], places[j], gap)) return false;
        var bounds = Bounds(places);
        int periods = (int)Math.Ceiling((bounds.Width + gap + 0.02) / pitch);
        for (int period = 1; period <= periods; period++)
        {
            double dx = period * pitch;
            for (int i = 0; i < places.Count; i++)
                for (int j = 0; j < places.Count; j++)
                    if (TooClose(places[i], places[j], gap, dx)) return false;
        }
        return true;
    }
}
