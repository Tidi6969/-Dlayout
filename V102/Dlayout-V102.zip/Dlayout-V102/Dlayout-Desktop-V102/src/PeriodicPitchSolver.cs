// One common horizontal translation P for every part in the basic stamping step.
// This solver explores P in ascending order. Validity is NOT monotone for concave
// interlocking outlines, therefore it never uses a global binary search.
// The AABB contact events below are only hints; Geometry.ValidPeriod is final.
namespace DCAD.Dlayout;

internal static class PeriodicPitchSolver
{
    internal readonly record struct Result(double Pitch, double StripWidth, double Efficiency);

    public static Result? Find(Job job, IReadOnlyList<ShapePlace> places,
        OptimizationSettings opt, int samples, int refinements, CancellationToken cancel)
    {
        if (places.Count == 0) return null;
        var box = Geometry.Bounds(places);
        double width = box.Height + opt.Top + opt.Bottom;
        if (!double.IsFinite(width) || width <= 0 ||
            (opt.MaxWidth > 0 && width > opt.MaxWidth + 1e-8)) return null;

        // A candidate must already be a legal stamping step before finding P.
        for (int i = 0; i < places.Count; i++)
        for (int j = i + 1; j < places.Count; j++)
            if (Geometry.TooClose(places[i], places[j], opt.Gap)) return null;

        double area = job.Shapes.Sum(p => p.Area);
        double min = Math.Max(area / width, 1e-7);
        // Periodic separation is automatically valid beyond the full horizontal
        // span plus margin; this supplies a guaranteed feasible upper bound.
        double max = Math.Max(min + 0.01, box.Width + opt.Gap + 0.05);
        double tolerance = Math.Max(0.00025, 0.00002 * Math.Max(1, box.Width));
        samples = Math.Max(12, samples);
        var trials = new SortedSet<double> { min, max };
        for (int i = 1; i < samples; i++)
            trials.Add(min + (max - min) * i / samples);

        // Minkowski / NFP-inspired CONTACT HINTS: near distances at which the
        // X projection of two silhouettes' bounding envelopes meet. They are
        // NOT treated as NFP or exact collision intervals; the real polygon
        // verifier decides every candidate. Include multiples kP (k>1).
        double eps = Math.Max(tolerance, opt.Gap * 0.005);
        for (int i = 0; i < places.Count; i++)
        for (int j = 0; j < places.Count; j++)
        {
            var a = places[i].Bounds;
            var b = places[j].Bounds;
            if (a.MaxY + opt.Gap < b.MinY || b.MaxY + opt.Gap < a.MinY) continue;
            double d = a.MaxX - b.MinX + opt.Gap + 0.01001;
            if (d <= 0) continue;
            for (int k = 1; k <= 4; k++)
            {
                double contact = d / k;
                if (contact > min && contact < max)
                {
                    trials.Add(contact);
                    if (contact + eps < max) trials.Add(contact + eps);
                }
            }
        }
        double? best = null;
        double lowerInvalid = min;
        int tick = 0;
        foreach (double candidate in trials)
        {
            if ((++tick & 15) == 0) cancel.ThrowIfCancellationRequested();
            if (Geometry.ValidPeriod(places, opt.Gap, candidate))
            {
                best = candidate;
                break;
            }
            lowerInvalid = candidate;
        }
        if (!best.HasValue) return null;

        // Refine the FIRST sampled feasible band by a finer increasing sweep.
        // A search interval can contain several valid/invalid islands; this
        // deliberately avoids binary-search monotonicity assumptions.
        double current = best.Value;
        for (int pass = 0; pass < refinements; pass++)
        {
            cancel.ThrowIfCancellationRequested();
            if (current - lowerInvalid <= tolerance) break;
            double previous = lowerInvalid;
            bool improved = false;
            const int subdivisions = 14;
            for (int step = 1; step < subdivisions; step++)
            {
                double attempt = lowerInvalid + (current - lowerInvalid) * step / subdivisions;
                if (Geometry.ValidPeriod(places, opt.Gap, attempt))
                {
                    current = attempt;
                    lowerInvalid = previous;
                    improved = true;
                    break;
                }
                previous = attempt;
            }
            if (!improved) lowerInvalid = previous;
        }
        if (!Geometry.ValidPeriod(places, opt.Gap, current)) return null;
        return new Result(current, width, area / (current * width) * 100);
    }
}
