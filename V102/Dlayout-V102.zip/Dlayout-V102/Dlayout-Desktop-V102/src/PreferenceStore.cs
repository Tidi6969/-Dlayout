using System.Globalization;

namespace DCAD.Dlayout;
internal sealed record Preferences(int Quality = 1, int Objective = 1, int Stations = 2,
    decimal MaxWidth = 0, int ResultLimit = 50, double CustomAngleStep = 5,
    int ResultSortField = (int)ResultMetric.Efficiency,
    int ResultSortDirection = (int)ResultDirection.Descending);
internal static class PreferenceStore
{
    public static int LoadLanguage() => DlayoutSettingsStore.Int(
        DlayoutSettingsStore.Read(), "Interface.Language", 0, 0, 5);
    public static void SaveLanguage(int id)
    {
        if (id is < 0 or > 5) throw new ArgumentOutOfRangeException(nameof(id));
        DlayoutSettingsStore.SaveSections(new() {
            ["Interface"] = new() { ["Language"] = id.ToString(CultureInfo.InvariantCulture) }
        });
    }
    public static Preferences Load()
    {
        var data = DlayoutSettingsStore.Read();
        int quality = DlayoutSettingsStore.Int(data, "Optimization.Quality", 1, 0, 5);
        int objective = DlayoutSettingsStore.Int(data, "Optimization.Objective", 1, 0, 1);
        double maxWidth = DlayoutSettingsStore.Number(data, "Optimization.MaxWidth", 0, 0, 1000000);
        int limit = DlayoutSettingsStore.Int(data, "Optimization.ResultLimit", 50, 1, 500);
        double angle = DlayoutSettingsStore.Number(data, "Optimization.CustomAngle", 5, 0.000001, 89.999999);
        int sortField = DlayoutSettingsStore.Int(data, "Interface.ResultSortField",
            (int)ResultMetric.Efficiency, 0, 3);
        int sortDirection = DlayoutSettingsStore.Int(data, "Interface.ResultSortDirection",
            (int)ResultDirection.Descending, 0, 1);

        // Migrate V100's one-field efficiency sort without discarding the user's
        // previous low-to-high / high-to-low choice.
        if (!data.ContainsKey("Interface.ResultSortField") &&
            data.TryGetValue("Interface.ResultSort", out string? legacyRaw) &&
            int.TryParse(legacyRaw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int legacySort))
        {
            sortField = (int)ResultMetric.Efficiency;
            sortDirection = legacySort == 1
                ? (int)ResultDirection.Ascending
                : (int)ResultDirection.Descending;
        }
        return new Preferences(quality, objective, 2, (decimal)maxWidth, limit, angle,
            sortField, sortDirection);
    }
    public static void Save(OptimizationSettings settings, int sortField, int sortDirection)
    {
        var inv = CultureInfo.InvariantCulture;
        DlayoutSettingsStore.SaveSections(new() {
            ["Optimization"] = new() {
                ["Quality"] = settings.Level.ToString(inv),
                ["Objective"] = (settings.ByMaterialArea ? 1 : 0).ToString(inv),
                ["MaxWidth"] = settings.MaxWidth.ToString("R", inv),
                ["ResultLimit"] = settings.ResultLimit.ToString(inv),
                ["CustomAngle"] = settings.CustomAngleStep.ToString("R", inv)
            },
            ["Interface"] = new() {
                ["ResultSortField"] = Math.Clamp(sortField, 0, 3).ToString(inv),
                ["ResultSortDirection"] = Math.Clamp(sortDirection, 0, 1).ToString(inv)
            },
            ["Calculation"] = new() {
                ["Gap"] = settings.Gap.ToString("R", inv),
                ["Top"] = settings.Top.ToString("R", inv),
                ["Bottom"] = settings.Bottom.ToString("R", inv)
            }
        });
    }
}
