using System.Globalization;
using System.Xml;
using System.Xml.Linq;

namespace DCAD.Dlayout;

// Isolated AutoCAD 2022 interchange. No AutoCAD SDK dependency in Desktop.
// The original CAD entities are NEVER exported as tessellated geometry:
// coordinates below are only for solving; CAD clones the original geometry.
internal sealed record CadJobRequest(string Id, string Path, Job Input);

internal static class CadJobBridge
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    private static double Number(XElement el, string name)
    {
        var raw = (string?)el.Attribute(name);
        if (!double.TryParse(raw, NumberStyles.Float, Inv, out double result) || !double.IsFinite(result))
            throw new InvalidDataException($"Invalid CAD job number: {name}.");
        return result;
    }
    private static string Num(double value) => value.ToString("R", Inv);

    internal static CadJobRequest Load(string file)
    {
        file = System.IO.Path.GetFullPath(file);
        using var xr = XmlReader.Create(file, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
        var root = XDocument.Load(xr).Root ?? throw new InvalidDataException("Empty CAD job.");
        if (root.Name != "dlayoutJob" || (string?)root.Attribute("protocol") != "2" ||
            (string?)root.Attribute("version") != "98")
            throw new InvalidDataException("Dlayout V102 CAD Job required (version/protocol mismatch).");
        string id = (string?)root.Attribute("id") ?? "";
        if (id.Length != 32 || !id.All(Uri.IsHexDigit))
            throw new InvalidDataException("Invalid CAD job ID.");
        double gap = Number(root, "gap"), top = Number(root, "top"), bottom = Number(root, "bottom");
        if (gap < 0 || top < 0 || bottom < 0) throw new InvalidDataException("Negative CAD clearances.");
        var elements = root.Element("parts")?.Elements("part").ToList()
            ?? throw new InvalidDataException("Missing CAD part list.");
        if (elements.Count is < 1 or > 12) throw new InvalidDataException("CAD job requires 1-12 source silhouettes.");
        List<Shape> shapes = new();
        HashSet<string> names = new(StringComparer.OrdinalIgnoreCase);
        foreach (var el in elements)
        {
            string handle = (string?)el.Attribute("handle") ?? "";
            if (handle.Length is < 1 or > 64 || handle.IndexOf('#') >= 0 || !names.Add(handle))
                throw new InvalidDataException("Duplicate or invalid source CAD handle.");
            double cx = Number(el, "cx"), cy = Number(el, "cy");
            var points = el.Elements("p").Select(p => new Pt(Number(p, "x"), Number(p, "y"))).ToArray();
            if (points.Length is < 3 or > 2000 || Math.Abs(Geometry.Area(points)) < 1e-8 || Geometry.HasSelfIntersection(points))
                throw new InvalidDataException("Invalid outer CAD silhouette: " + handle);
            var center = new Pt(cx, cy);
            double grossArea = Math.Abs(Geometry.Area(points));
            // Optional netArea is supplied by V70 CAD bridge after subtracting
            // actual CAD inner curves. Geometry/Gap still use OUTER points.
            double usefulArea = el.Attribute("netArea") == null ? grossArea : Number(el, "netArea");
            if (usefulArea <= 0 || usefulArea > grossArea + Math.Max(0.1, grossArea * 0.005))
                throw new InvalidDataException("Invalid CAD useful area: " + handle);
            shapes.Add(new Shape { Handle = handle, OriginalCenter = center,
                LocalPoints = points.Select(p => p - center).ToArray(), Area = usefulArea });
        }
        return new CadJobRequest(id, file, new Job { Id = id, Shapes = shapes, Gap = gap, Top = top, Bottom = bottom });
    }

    // V82: send the entire distinct solution archive, not only one selected
    // placement. Geometry is transmitted once in job.xml; every solution carries
    // only part identities and rigid transforms, so 500 solutions remain small.
    internal static string SaveResult(CadJobRequest request, Job expanded, Solution result,
        double gap, double top, double bottom, double maxWidth) =>
        SaveResult(request, expanded, new[] { result }, result, gap, top, bottom, maxWidth);

    internal static string SaveResult(CadJobRequest request, Job expanded,
        IReadOnlyList<Solution> archive, Solution selected,
        double gap, double top, double bottom, double maxWidth)
    {
        if (archive.Count is < 1 or > 500 || expanded.Shapes.Count is < 1 or > 12)
            throw new InvalidDataException("Invalid Dlayout solution archive size.");
        var allowed = new HashSet<string>(request.Input.Shapes.Select(x => x.Handle),
            StringComparer.OrdinalIgnoreCase);
        var expandedHandles = new HashSet<string>(expanded.Shapes.Select(x => x.Handle),
            StringComparer.OrdinalIgnoreCase);
        var solutions = new XElement("solutions");
        int selectedIndex = -1;
        for (int i = 0; i < archive.Count; i++)
        {
            Solution solution = archive[i];
            if (ReferenceEquals(solution, selected)) selectedIndex = i;
            if (solution.Places.Count != expanded.Shapes.Count ||
                !double.IsFinite(solution.Pitch) || solution.Pitch <= 0 ||
                !double.IsFinite(solution.StripWidth) || solution.StripWidth <= 0 ||
                !double.IsFinite(solution.RelativeAngle) ||
                !Geometry.ValidPeriod(solution.Places, gap, solution.Pitch) ||
                (maxWidth > 0 && solution.StripWidth > maxWidth + 1e-6))
                throw new InvalidDataException("Invalid archived periodic solution #" + (i + 1));
            // Keep geometry/P/angle unchanged, but avoid sending a silhouette
            // whose anchor lies many stations away from station 1.
            var drawingPlaces = StepPhase.Rebase(solution.Places, solution.Pitch);
            var placements = new XElement("placements");
            HashSet<string> identities = new(StringComparer.OrdinalIgnoreCase);
            foreach (var p in drawingPlaces)
            {
                if (!identities.Add(p.Shape.Handle) || !expandedHandles.Contains(p.Shape.Handle))
                    throw new InvalidDataException("Duplicate or unknown CAD part identity.");
                int separator = p.Shape.Handle.LastIndexOf('#');
                if (separator < 1 || !int.TryParse(p.Shape.Handle[(separator + 1)..], out int unit) ||
                    unit < 1 || unit > StepSchedule.MaxPerStep ||
                    !allowed.Contains(p.Shape.Handle[..separator]) ||
                    !double.IsFinite(p.Center.X) || !double.IsFinite(p.Center.Y) ||
                    !double.IsFinite(p.AngleDeg))
                    throw new InvalidDataException("Invalid CAD part transformation.");
                placements.Add(new XElement("part", new XAttribute("handle", p.Shape.Handle),
                    new XAttribute("x", Num(p.Center.X)),
                    new XAttribute("y", Num(p.Center.Y)),
                    new XAttribute("angle", Num(p.AngleDeg))));
            }
            if (!identities.SetEquals(expandedHandles))
                throw new InvalidDataException("Missing CAD part placement.");
            solutions.Add(new XElement("solution",
                new XAttribute("pitch", Num(solution.Pitch)),
                new XAttribute("width", Num(solution.StripWidth)),
                new XAttribute("relativeAngle", Num(solution.RelativeAngle)),
                new XAttribute("efficiency", Num(solution.Efficiency)),
                new XAttribute("score", Num(solution.Score)), placements));
        }
        if (selectedIndex < 0)
            throw new InvalidDataException("Selected solution is not in the CAD archive.");
        solutions.SetAttributeValue("selected", selectedIndex);
        // Keep the selected solution at the root as a protocol-2 fallback.
        var selectedSolution = archive[selectedIndex];
        var legacyPlacements = new XElement("placements",
            solutions.Elements("solution").ElementAt(selectedIndex)
                .Element("placements")!.Elements("part").Select(x => new XElement(x)));
        string file = Path.Combine(Path.GetDirectoryName(request.Path)!, "result.xml");
        string temp = file + ".tmp";
        var xml = new XDocument(new XElement("dlayoutResult",
            new XAttribute("protocol", "2"), new XAttribute("id", request.Id),
            new XAttribute("status", "COMPLETED"),
            new XAttribute("pitch", Num(selectedSolution.Pitch)),
            new XAttribute("width", Num(selectedSolution.StripWidth)),
            new XAttribute("relativeAngle", Num(selectedSolution.RelativeAngle)),
            new XAttribute("gap", Num(gap)),
            new XAttribute("top", Num(top)), new XAttribute("bottom", Num(bottom)),
            new XAttribute("copies", "2"), legacyPlacements, solutions));
        try { xml.Save(temp); File.Move(temp, file, true); }
        finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        return file;
    }
}
