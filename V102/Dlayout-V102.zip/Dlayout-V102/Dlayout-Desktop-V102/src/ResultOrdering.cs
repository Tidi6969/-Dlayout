namespace DCAD.Dlayout;

internal enum ResultMetric
{
    Angle = 0,
    Efficiency = 1,
    Pitch = 2,
    Height = 3
}

internal enum ResultDirection
{
    Ascending = 0,
    Descending = 1
}

internal static class ResultOrdering
{
    public static List<Solution> Order(IEnumerable<Solution> originals, int metric, int direction)
    {
        var list = originals.ToList();
        Func<Solution, double> value = item => Metric(item, metric);
        return direction == (int)ResultDirection.Descending
            ? list.OrderByDescending(value).ThenBy(x => x.Score).ToList()
            : list.OrderBy(value).ThenBy(x => x.Score).ToList();
    }

    public static List<Solution> OrderNearest(IEnumerable<Solution> originals, int metric, double target)
    {
        if (!double.IsFinite(target)) throw new ArgumentOutOfRangeException(nameof(target));
        return originals.ToList()
            .OrderBy(x => Math.Abs(Metric(x, metric) - target))
            .ThenBy(x => x.Score)
            .ToList();
    }

    public static List<AngleOutcome> OrderAngles(IEnumerable<AngleOutcome> originals, int metric, int direction)
    {
        var list = originals.ToList();
        bool descending = direction == (int)ResultDirection.Descending;
        if (metric == (int)ResultMetric.Angle)
            return descending
                ? list.OrderByDescending(x => x.Angle).ThenBy(x => x.Index).ToList()
                : list.OrderBy(x => x.Angle).ThenBy(x => x.Index).ToList();

        Func<AngleOutcome, double> value = item => item.Best == null
            ? 0 : Metric(item.Best, metric);
        return descending
            ? list.OrderBy(x => x.Best == null ? 1 : 0)
                .ThenByDescending(value).ThenBy(x => x.Index).ToList()
            : list.OrderBy(x => x.Best == null ? 1 : 0)
                .ThenBy(value).ThenBy(x => x.Index).ToList();
    }

    public static List<AngleOutcome> OrderAnglesNearest(
        IEnumerable<AngleOutcome> originals, int metric, double target)
    {
        if (!double.IsFinite(target)) throw new ArgumentOutOfRangeException(nameof(target));
        return originals.ToList()
            .OrderBy(x => metric != (int)ResultMetric.Angle && x.Best == null ? 1 : 0)
            .ThenBy(x => metric != (int)ResultMetric.Angle && x.Best == null
                ? double.PositiveInfinity
                : Math.Abs(Metric(x, metric) - target))
            .ThenBy(x => x.Best?.Score ?? double.PositiveInfinity)
            .ThenBy(x => x.Index)
            .ToList();
    }

    private static double Metric(Solution item, int metric) => metric switch
    {
        (int)ResultMetric.Angle => item.RelativeAngle,
        (int)ResultMetric.Pitch => item.Pitch,
        (int)ResultMetric.Height => item.StripWidth,
        _ => item.Efficiency
    };

    private static double Metric(AngleOutcome item, int metric) => metric switch
    {
        (int)ResultMetric.Angle => item.Angle,
        _ => item.Best == null ? 0 : Metric(item.Best, metric)
    };

    public static int BestIndex(IReadOnlyList<Solution> results)
    {
        if (results.Count == 0) return -1;
        int index = 0;
        for (int i = 1; i < results.Count; i++)
            if (results[i].Score < results[index].Score) index = i;
        return index;
    }
}
