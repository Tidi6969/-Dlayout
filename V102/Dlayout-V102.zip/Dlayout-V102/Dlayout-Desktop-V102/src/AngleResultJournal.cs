using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace DCAD.Dlayout;

// A durable, append-only journal of the BEST VALID placement at EVERY tested angle.
// Stored under DIRECT DUser/Dlayout_results, not in Dlayout_settings.ini, AppData,
// or disposable CAD bridge sessions. Each angle is flushed before the next pass.
// The original geometry is not duplicated for every angle: the source fingerprint
// binds this journal to the exact CAD/DXF geometry and optimization settings.
internal sealed class AngleResultJournal
{
    private const int Format = 1;
    internal string PathName { get; }

    private AngleResultJournal(string path) => PathName = path;

    internal static AngleResultJournal Begin(string duser, Job job, OptimizationSettings settings)
    {
        string root = System.IO.Path.GetFullPath(duser);
        if (!Directory.Exists(root) || !string.Equals(
                System.IO.Path.GetFileName(System.IO.Path.TrimEndingDirectorySeparator(root)),
                "DUser", StringComparison.OrdinalIgnoreCase))
            throw new DirectoryNotFoundException("Dlayout per-angle results require DIRECT DUser.");
        string folder = System.IO.Path.Combine(root, "Dlayout_results");
        Directory.CreateDirectory(folder);
        string path = System.IO.Path.Combine(folder,
            $"Dlayout_{DateTime.Now:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}.jsonl");
        var journal = new AngleResultJournal(path);
        journal.WriteLine(JsonSerializer.Serialize(new
        {
            kind = "header", format = Format, appVersion = "98",
            createdUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
            signature = Signature(job, settings),
            parts = job.Shapes.Count,
            testedAngleCount = Optimizer.AngleCount(settings.Level, settings.CustomAngleStep),
            quality = settings.Level, objective = settings.ByMaterialArea ? "Area" : "Pitch",
            gap = settings.Gap, top = settings.Top, bottom = settings.Bottom,
            maxWidth = settings.MaxWidth, resultLimit = settings.ResultLimit,
            sourceShapes = job.Shapes.Select(shape => new
            {
                handle = shape.Handle, sourceX = shape.OriginalCenter.X,
                sourceY = shape.OriginalCenter.Y, usefulArea = shape.Area,
                localPoints = shape.LocalPoints.Select(point => new { x = point.X, y = point.Y }).ToArray()
            }).ToArray()
        }), create: true);
        return journal;
    }

    internal void Append(AngleOutcome outcome)
    {
        object? best = outcome.Best == null ? null : new
        {
            pitch = outcome.Best.Pitch, width = outcome.Best.StripWidth,
            efficiency = outcome.Best.Efficiency, score = outcome.Best.Score,
            referenceAngle = outcome.Best.RelativeAngle,
            usefulArea = outcome.Best.Places.Sum(p => p.Shape.Area),
            materialArea = outcome.Best.Pitch * outcome.Best.StripWidth,
            places = outcome.Best.Places.Select(p => new
            {
                handle = p.Shape.Handle, x = p.Center.X, y = p.Center.Y,
                angle = p.AngleDeg
            }).ToArray()
        };
        WriteLine(JsonSerializer.Serialize(new
        {
            kind = "angle", index = outcome.Index, angle = outcome.Angle,
            state = outcome.Complete ? (best == null ? "NO_SOLUTION" : "COMPLETED") : "PARTIAL",
            elapsedMs = outcome.ElapsedMilliseconds, best
        }), create: false);
    }

    internal void Finish(string status) => WriteLine(JsonSerializer.Serialize(new
    {
        kind = "end", status, completedUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture)
    }), create: false);

    // Each record is one complete newline-terminated JSON object. Flush(true)
    // makes an angle's data available even if EXE or CAD fails afterwards.
    private void WriteLine(string line, bool create)
    {
        using var file = new FileStream(PathName,
            create ? FileMode.CreateNew : FileMode.Append, FileAccess.Write, FileShare.Read);
        using var output = new StreamWriter(file, new UTF8Encoding(false), 4096, leaveOpen: true);
        output.WriteLine(line);
        output.Flush();
        file.Flush(true);
    }

    private static string Signature(Job job, OptimizationSettings o)
    {
        var b = new StringBuilder("Dlayout-angle-v1|");
        void D(double x) => b.Append(x.ToString("R", CultureInfo.InvariantCulture)).Append('|');
        b.Append(job.Shapes.Count).Append('|').Append(o.Level).Append('|')
            .Append(o.ResultLimit).Append('|').Append(o.ByMaterialArea).Append('|');
        D(o.CustomAngleStep); D(o.Gap); D(o.Top); D(o.Bottom); D(o.MaxWidth);
        foreach (Shape p in job.Shapes)
        {
            b.Append(p.Handle).Append('|').Append(p.LocalPoints.Length).Append('|');
            D(p.Area); D(p.OriginalCenter.X); D(p.OriginalCenter.Y);
            foreach (Pt pt in p.LocalPoints) { D(pt.X); D(pt.Y); }
        }
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(b.ToString())));
    }

    internal static IReadOnlyList<AngleOutcome> Load(string file, Job job, OptimizationSettings settings)
    {
        string full = System.IO.Path.GetFullPath(file);
        if (!File.Exists(full)) throw new FileNotFoundException("Dlayout angle results not found.", full);
        var knownShapes = job.Shapes.ToDictionary(s => s.Handle, StringComparer.OrdinalIgnoreCase);
        var results = new Dictionary<int, AngleOutcome>();
        bool headerFound = false;
        int expectedCount = Optimizer.AngleCount(settings.Level, settings.CustomAngleStep);
        int lineNumber = 0;
        foreach (var line in File.ReadLines(full, Encoding.UTF8))
        {
            lineNumber++;
            if (string.IsNullOrWhiteSpace(line))
                throw new InvalidDataException($"Empty record at line {lineNumber}.");
            try
            {
                using var doc = JsonDocument.Parse(line, new JsonDocumentOptions { MaxDepth = 32 });
                JsonElement root = doc.RootElement;
                string kind = root.GetProperty("kind").GetString() ?? "";
                if (!headerFound)
                {
                    if (kind != "header" || root.GetProperty("format").GetInt32() != Format ||
                        root.GetProperty("signature").GetString() != Signature(job, settings) ||
                        root.GetProperty("testedAngleCount").GetInt32() != expectedCount)
                        throw new InvalidDataException("Saved angles do not match this exact geometry and optimization settings.");
                    headerFound = true;
                    continue;
                }
                if (kind == "end") continue;
                if (kind != "angle") throw new InvalidDataException("Unknown angle record type.");
                int index = root.GetProperty("index").GetInt32();
                double angle = Numeric(root, "angle");
                bool complete = root.GetProperty("state").GetString() != "PARTIAL";
                if (index < 0 || index >= expectedCount ||
                    Math.Abs(angle - index * (settings.Level == 5 ? settings.CustomAngleStep :
                        settings.Level switch { 0 => 15, 1 => 10, 2 => 5, 3 => 3, _ => 1 })) > 1e-7)
                    throw new InvalidDataException("Angle does not match configured sweep.");
                JsonElement bestNode = root.GetProperty("best");
                Solution? solution = null;
                if (bestNode.ValueKind != JsonValueKind.Null)
                {
                    double pitch = Numeric(bestNode, "pitch"), stripWidth = Numeric(bestNode, "width");
                    double efficiency = Numeric(bestNode, "efficiency"), score = Numeric(bestNode, "score");
                    double reference = Numeric(bestNode, "referenceAngle");
                    double usefulArea = Numeric(bestNode, "usefulArea");
                    double materialArea = Numeric(bestNode, "materialArea");
                    if (pitch <= 0 || stripWidth <= 0 || usefulArea <= 0 ||
                        Math.Abs(materialArea - pitch * stripWidth) > Math.Max(1e-5, materialArea * 1e-8) ||
                        Math.Abs(usefulArea - job.Shapes.Sum(shape => shape.Area)) >
                            Math.Max(1e-5, usefulArea * 1e-8) ||
                        efficiency < 0 || efficiency > 100.0001 ||
                        Math.Abs(reference - angle) > 1e-7)
                        throw new InvalidDataException("Invalid saved periodic solution metrics.");
                    var placements = new List<ShapePlace>();
                    var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (JsonElement place in bestNode.GetProperty("places").EnumerateArray())
                    {
                        string handle = place.GetProperty("handle").GetString() ?? "";
                        if (!used.Add(handle) || !knownShapes.TryGetValue(handle, out Shape? shape))
                            throw new InvalidDataException("Unknown or duplicate saved placement.");
                        placements.Add(shape.At(new Pt(Numeric(place, "x"), Numeric(place, "y")),
                            Numeric(place, "angle")));
                    }
                    if (placements.Count != job.Shapes.Count ||
                        !Geometry.ValidPeriod(placements, settings.Gap, pitch) ||
                        (settings.MaxWidth > 0 && stripWidth > settings.MaxWidth + 1e-6))
                        throw new InvalidDataException("Saved angle placement is incomplete or violates periodic clearance.");
                    solution = new Solution { Places = placements, Pitch = pitch,
                        StripWidth = stripWidth, Efficiency = efficiency, Score = score,
                        RelativeAngle = reference };
                }
                string state = root.GetProperty("state").GetString() ?? "";
                if (state != "PARTIAL" && state != "NO_SOLUTION" && state != "COMPLETED" ||
                    (state == "COMPLETED" && solution == null) ||
                    (state == "NO_SOLUTION" && solution != null))
                    throw new InvalidDataException("Invalid per-angle result status.");
                results[index] = new AngleOutcome(index, angle, solution, complete,
                    root.GetProperty("elapsedMs").GetInt64());
            }
            catch (Exception ex) when (ex is JsonException or KeyNotFoundException or FormatException or OverflowException)
            {
                throw new InvalidDataException($"Corrupt saved angle file at line {lineNumber}: {ex.Message}", ex);
            }
        }
        if (!headerFound) throw new InvalidDataException("Saved angle file has no header.");
        return results.Values.OrderBy(x => x.Index).ToArray();
    }

    private static double Numeric(JsonElement el, string name)
    {
        double value = el.GetProperty(name).GetDouble();
        if (!double.IsFinite(value)) throw new InvalidDataException("Invalid saved numeric value: " + name);
        return value;
    }
}
