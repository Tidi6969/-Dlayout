// V63 result collection rebuilt directly from V60. This is a DISPLAY archive,
// not a pitch solver. V64 may refine its best finalists, but every
// such trial still passes V60 full-period clearance verification.
namespace DCAD.Dlayout;

internal sealed class SolutionArchive
{
    private readonly List<Solution> candidates = new();
    private readonly double positionTolerance;
    public int Capacity { get; }
    public Solution? Best => candidates.Count == 0 ? null : candidates[0];
    public int Count => candidates.Count;

    public SolutionArchive(int maxResults, double characteristic)
    {
        Capacity = maxResults is >= 1 and <= 500 ? maxResults :
            throw new ArgumentOutOfRangeException(nameof(maxResults), "Result limit must be from 1 to 500.");
        // Only eliminate near-identical GEOMETRIC placements, not layouts
        // simply sharing the same pitch/efficiency. A normalized comparison
        // ignores global translation but retains each part's rotation and XY.
        positionTolerance = Math.Max(0.01, Math.Abs(characteristic) * 0.01);
    }

    public bool Offer(Solution solution)
    {
        if (!double.IsFinite(solution.Score) || !double.IsFinite(solution.Pitch) ||
            !double.IsFinite(solution.StripWidth) || solution.Pitch <= 0 ||
            solution.StripWidth <= 0 || solution.Places.Count == 0)
            return false;

        for (int i = 0; i < candidates.Count; i++)
        {
            if (!SameLayout(candidates[i], solution)) continue;
            // Always keep the better P/area evaluation of an effectively
            // identical layout. Do not fill the list with numerical noise.
            if (Rank(solution, candidates[i]) >= 0) return false;
            candidates.RemoveAt(i);
            InsertSorted(solution);
            return true;
        }
        if (candidates.Count == Capacity && Rank(solution, candidates[^1]) >= 0)
            return false;
        InsertSorted(solution);
        if (candidates.Count > Capacity) candidates.RemoveAt(candidates.Count - 1);
        return true;
    }

    // A copy is critical: progress notifications are queued on the UI thread.
    // No queued callback may observe a later mutation of the same List object.
    public IReadOnlyList<Solution> Snapshot() => candidates.ToArray();

    private void InsertSorted(Solution solution)
    {
        int index = candidates.BinarySearch(solution, SolutionRankComparer.Instance);
        if (index < 0) index = ~index;
        candidates.Insert(index, solution);
    }

    private bool SameLayout(Solution a, Solution b)
    {
        if (a.Places.Count != b.Places.Count) return false;
        Pt a0 = a.Places[0].Center;
        Pt b0 = b.Places[0].Center;
        double dist2 = positionTolerance * positionTolerance;
        for (int i = 0; i < a.Places.Count; i++)
        {
            var x = a.Places[i]; var y = b.Places[i];
            if (x.Shape.Handle != y.Shape.Handle) return false;
            // Modulo 360: +359.9 and -0.1 are the same rotation.
            double angle = Math.Abs(Math.IEEERemainder(x.AngleDeg - y.AngleDeg, 360.0));
            if (angle > 1.0) return false;
            if (((x.Center - a0) - (y.Center - b0)).Dist2(new Pt(0, 0)) > dist2)
                return false;
        }
        return true;
    }

    private static int Rank(Solution a, Solution b) => SolutionRankComparer.Instance.Compare(a, b);

    private sealed class SolutionRankComparer : IComparer<Solution>
    {
        public static readonly SolutionRankComparer Instance = new();
        public int Compare(Solution? a, Solution? b)
        {
            if (ReferenceEquals(a, b)) return 0;
            if (a == null) return 1;
            if (b == null) return -1;
            int score = a.Score.CompareTo(b.Score);
            if (score != 0) return score;
            int pitch = a.Pitch.CompareTo(b.Pitch);
            if (pitch != 0) return pitch;
            return a.StripWidth.CompareTo(b.StripWidth);
        }
    }
}
