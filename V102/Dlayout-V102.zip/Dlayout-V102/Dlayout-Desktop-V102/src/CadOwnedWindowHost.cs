using System.Runtime.InteropServices;

namespace DCAD.Dlayout;

/// <summary>
/// Show the CAD-launched Desktop as an ordinary WinForms window owned by CAD.
/// The CAD command's modal gate controls the initial handoff. No polling,
/// forced foreground switching or repetitive Z-order manipulation is performed.
/// </summary>
internal static class CadOwnedWindowHost
{
    private sealed class HwndOwner : IWin32Window
    {
        public HwndOwner(IntPtr handle) => Handle = handle;
        public IntPtr Handle { get; }
    }

    private sealed class OwnedContext : ApplicationContext
    {
        public OwnedContext(Form form, IntPtr cadOwner)
        {
            if (form == null) throw new ArgumentNullException(nameof(form));
            MainForm = form;
            // CAD-hosted EXE should not have a separate taskbar icon.
            form.ShowInTaskbar = false;
            if (cadOwner != IntPtr.Zero && IsWindow(cadOwner))
                form.Show(new HwndOwner(cadOwner));
            else
                form.Show();
            // WinForms handles the initial activation. Do NOT run a focus timer:
            // it races CAD's Dynamic Input/tooltips and steals focus on CAD picks.
        }
    }

    public static void Run(Form form, IntPtr cadOwnerHwnd)
    {
        using OwnedContext context = new(form, cadOwnerHwnd);
        Application.Run(context);
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWindow(IntPtr hWnd);
}
