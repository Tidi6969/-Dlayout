// V64 cooperative optimisation of ALL members of one periodic stamping step.
// This is a second, independently validated search layer on top of V60/V63:
// it neither changes the pitch solver nor relaxes any CAD clearance check.
// Each accepted candidate is validated as a FULL cluster C + k*(P,0).
namespace DCAD.Dlayout;

internal static class CollectiveRefiner
{
    internal sealed record State(Pt[] Centers, double[] Rotations, Solution Layout);

    // The evaluation callback MUST use PeriodicPitchSolver.Find for the entire
    // step (or a fixed-P periodic verifier in a focused regression test).
    internal static State Improve(State starting, double characteristic,
        int maximumEvaluations, CancellationToken cancel,
        Func<Pt[], double[], State?> evaluate)
    {
        if (starting.Centers.Length < 3 || maximumEvaluations <= 0)
            return starting;

        State best = starting;
        int used = 0;
        // Scales from coarse changes down to a precision-sized final adjustment.
        // No shape 0 motion: it is the gauge origin, not a physically fixed part.
        double[] scales = [.20, .10, .05, .025, .0125, .00625];
        foreach (double factor in scales)
        {
            if (used >= maximumEvaluations) break;
            cancel.ThrowIfCancellationRequested();
            double shift = Math.Max(.015, characteristic * factor);
            State roundBest = best;

            void Try(Action<Pt[], double[]> action)
            {
                if (used >= maximumEvaluations) return;
                used++;
                if ((used & 15) == 0) cancel.ThrowIfCancellationRequested();
                Pt[] c = (Pt[])best.Centers.Clone();
                double[] a = (double[])best.Rotations.Clone();
                action(c, a);
                c[0] = new Pt(0, 0);
                a[0] = starting.Rotations[0];
                State? checkedState = evaluate(c, a);
                // Always use the full-period objective, not tightness of RED
                // alone. Do not accept temporary invalid or partial layouts.
                if (checkedState != null &&
                    checkedState.Layout.Score < roundBest.Layout.Score - 1e-8)
                    roundBest = checkedState;
            }

            // Try improving the outermost pieces first: a single unconstrained
            // top/bottom part can often reduce W with P completely unchanged.
            var order = Enumerable.Range(1, best.Centers.Length - 1)
                .OrderByDescending(i => best.Layout.Places[i].Bounds.MaxY)
                .ToArray();
            foreach (int i in order)
            {
                // Coordinate-descent proposals apply to each part independently
                // but evaluate the PERIODIC layout of ALL other parts each time.
                Try((c, a) => c[i] += new Pt(0, -shift));
                Try((c, a) => c[i] += new Pt(0, shift));
                Try((c, a) => c[i] += new Pt(-shift, 0));
                Try((c, a) => c[i] += new Pt(shift, 0));
                if (used >= maximumEvaluations) break;
            }
            if (used >= maximumEvaluations) { best = roundBest; break; }

            // A step with three or more blanks can require changing two blanks
            // together; single-item moves may be impossible due to their Gap.
            // Limit pair proposals per scale so deep DXF files remain responsive.
            int pairs = 0;
            foreach (int i in order)
            foreach (int j in order)
            {
                if (j <= i || pairs++ >= 8 || used >= maximumEvaluations) continue;
                Try((c, a) => { c[i] += new Pt(0, -shift); c[j] += new Pt(0, -shift); });
                Try((c, a) => { c[i] += new Pt(0, shift); c[j] += new Pt(0, shift); });
                Try((c, a) => { c[i] += new Pt(-shift, 0); c[j] += new Pt(-shift, 0); });
                Try((c, a) => { c[i] += new Pt(shift, 0); c[j] += new Pt(shift, 0); });
                Try((c, a) => { c[i] += new Pt(0, -shift); c[j] += new Pt(0, shift); });
                Try((c, a) => { c[i] += new Pt(0, shift); c[j] += new Pt(0, -shift); });
            }
            if (used >= maximumEvaluations) { best = roundBest; break; }

            // Compress whole cluster relationships, not the geometry itself.
            // This generates genuinely collective changes which ordinary V60
            // one-part mutations are unable to reach in a single iteration.
            Try((c, a) => { for (int i = 1; i < c.Length; i++) c[i] = new Pt(c[i].X, c[i].Y * .95); });
            Try((c, a) => { for (int i = 1; i < c.Length; i++) c[i] = new Pt(c[i].X * .95, c[i].Y); });
            Try((c, a) => { for (int i = 1; i < c.Length; i++) c[i] = c[i] * .95; });

            // Change two independent orientations at once. A rotating subset
            // keeps the shapes rigid and lets P be recomputed for the cluster.
            if (order.Length >= 2 && used < maximumEvaluations)
            {
                int i = order[0], j = order[1];
                double delta = Math.Max(1, 15 * factor);
                Try((c, a) => { a[i] += delta; a[j] -= delta; });
                Try((c, a) => { a[i] -= delta; a[j] += delta; });
                Try((c, a) => (c[i], c[j]) = (c[j], c[i]));
            }
            best = roundBest;
        }
        return best;
    }
}
