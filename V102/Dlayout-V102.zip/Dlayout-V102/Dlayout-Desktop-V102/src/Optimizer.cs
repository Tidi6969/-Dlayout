// Dlayout periodic strip optimizer. A step is a freely optimised cluster C;
// all other steps are rigid translations C + k*(P,0). Optimisation NEVER ranks
// candidates by how compact the red step alone appears.
//
// Search strategy: multiple starts, NFP/Minkowski-inspired contact placements,
// randomized guided local search, elite archive and non-monotone P solver.
// Contact seeds are HEURISTIC, not an exact No-Fit-Polygon implementation.
namespace DCAD.Dlayout;

internal sealed class OptimizationSettings
{
    public int Level { get; init; } = 1;
    public double CustomAngleStep { get; init; } = 5;
    public int ResultLimit { get; init; } = 50;
    public int Copies { get; init; } = 2;
    public double Gap { get; init; } = 5;
    public double Top { get; init; } = 5;
    public double Bottom { get; init; } = 5;
    public double MaxWidth { get; init; }
    public bool ByMaterialArea { get; init; } = true;
}
internal sealed class Solution
{
    public required List<ShapePlace> Places { get; init; }
    public double Pitch { get; init; }
    public double StripWidth { get; init; }
    public double Efficiency { get; init; }
    public double Score { get; init; }
    public double RelativeAngle { get; init; }
}
internal sealed record OptimizeProgress(
    int Done, int Total, double Angle, Solution? Best, IReadOnlyList<Solution> Leaders,
    Solution? CurrentAngleBest = null, bool UpdateAnglePreview = false,
    bool CurrentAngleCompleted = false);
// Independent per-angle results. Never filtered by the global 10..500 result limit.
// Complete=false marks a cancelled/unfinished angular sweep; it cannot be presented as a finished optimum.
internal sealed record AngleOutcome(int Index, double Angle, Solution? Best, bool Complete, long ElapsedMilliseconds);

internal static class Optimizer
{
    private sealed record SearchBudget(double StepDegrees, int Seeds, int Mutations, int PitchSamples, int RefinePasses);
    private static SearchBudget Budget(int level, double customAngle) => level switch
    {
        0 => new(15, 4, 12, 18, 2),
        1 => new(10, 6, 26, 24, 3),
        2 => new(5, 8, 60, 36, 4),
        3 => new(3, 10, 100, 42, 5),
        4 => new(1, 12, 140, 48, 6),
        5 when double.IsFinite(customAngle) && customAngle > 0 && customAngle < 90 =>
            new(customAngle, 8, 60, 36, 4), // Custom changes the angular sweep only; deep is baseline.
        _ => throw new ArgumentOutOfRangeException(nameof(level), "Unknown computation level or custom angle outside (0,90).")
    };
    internal static int AngleCount(int level, double customAngle) =>
        checked((int)Math.Ceiling(360.0 / Budget(level, customAngle).StepDegrees - 1e-10));
    private sealed record Candidate(Pt[] Centers, double[] Rotations, Solution Layout);

    public static Solution? Run(Job job, OptimizationSettings settings, CancellationToken cancel,
        Action<OptimizeProgress> report, Action<AngleOutcome>? reportAngle = null)
    {
        if (job.Shapes.Count is < 1 or > StepSchedule.MaxPerStep)
            throw new ArgumentException("Select 1 to 12 contours in one stamping step.");
        if (settings.Gap < 0 || settings.Top < 0 || settings.Bottom < 0 || settings.MaxWidth < 0)
            throw new ArgumentException("Clearances and maximum width must not be negative.");
        if (settings.ResultLimit < 1 || settings.ResultLimit > 500)
            throw new ArgumentOutOfRangeException(nameof(settings.ResultLimit), "Result limit must be 1..500.");
        var budget = Budget(settings.Level, settings.CustomAngleStep);
        double characteristic = Math.Max(0.1, job.Shapes.Max(p =>
            Math.Max(BBox.From(p.LocalPoints).Width, BBox.From(p.LocalPoints).Height)) + settings.Gap);
        // V60 per-angle seeds and original mutation loop remain intact.
        // The archive also provides a few valid finalists for the NEW V64
        // cooperative pass; none bypasses the original pitch or Gap checks.
        var archive = new SolutionArchive(settings.ResultLimit, characteristic);
        Candidate? warm = null;
        int total = AngleCount(settings.Level, settings.CustomAngleStep);

        // Cancellation must publish the live validated archive before returning
        // to the caller: Stop means preserve computed solutions, not discard them.
        int lastPass = 0;
        double lastAngle = 0;
        Solution? unfinishedAngleRecordBest = null;
        bool currentAngleFinished = true;
        static bool BetterForRecord(Solution candidate, Solution? existing)
        {
            if (existing == null) return true;
            int compare = candidate.Score.CompareTo(existing.Score);
            if (compare != 0) return compare < 0;
            compare = candidate.Pitch.CompareTo(existing.Pitch);
            return compare != 0 ? compare < 0 : candidate.StripWidth < existing.StripWidth;
        }
        var angleWatch = System.Diagnostics.Stopwatch.StartNew();
        var completedAngles = new Dictionary<int, AngleOutcome>();
        void PublishAngle(AngleOutcome outcome)
        {
            completedAngles[outcome.Index] = outcome;
            reportAngle?.Invoke(outcome);
        }
        try
        {
        for (int pass = 0; pass < total; pass++)
        {
            lastPass = pass;
            lastAngle = pass * budget.StepDegrees;
            cancel.ThrowIfCancellationRequested();
            currentAngleFinished = false;
            unfinishedAngleRecordBest = null;
            angleWatch.Restart();
            double angle = lastAngle;
            long lastLivePreviewReportMs = 0;
            // Tell the UI immediately that the angular sweep has moved. This
            // clears the previous angle's geometry so it cannot masquerade as
            // the result of the angle currently being tested.
            report(new OptimizeProgress(pass, total, angle, archive.Best, archive.Snapshot(),
                CurrentAngleBest: null, UpdateAnglePreview: true));
            // Integer presets preserve their V64 random seeds exactly.
            int seedAngle = (int)Math.Round(angle * (settings.Level == 5 ? 1000 : 1));
            var random = new Random(unchecked(4109 + seedAngle * 1357 + job.Shapes.Count * 1069 + settings.Level * 7901));
            var elite = new List<Candidate>();
            var attemptCount = 0;
            Candidate? bestThisPass = null;

            Candidate? Test(Pt[] center, double[] rotation)
            {
                if ((++attemptCount & 7) == 0) cancel.ThrowIfCancellationRequested();
                center[0] = new Pt(0, 0); // remove global-translation degree of freedom
                if (job.Shapes.Count == 1) rotation[0] = angle;
                else rotation[0] = angle; // other parts have FREE independent orientations
                Solution? layout = Evaluate(job, settings, center, rotation, angle, budget, cancel);
                if (layout == null) return null;
                Candidate current = new(center, rotation, layout);
                // Collect every VALID layout; an otherwise good V60 result
                // must not vanish just because it did not beat this angle's record.
                // Offer() cannot alter the elite search or Candidate decisions.
                archive.Offer(layout);
                // Observation only: separate from elite/warm-seed search choices.
                // Retain the actual best at this angle using global rank tie-breaks.
                bool angleRecordImproved = BetterForRecord(layout, unfinishedAngleRecordBest);
                bool firstAngleCandidate = unfinishedAngleRecordBest == null;
                if (angleRecordImproved)
                    unfinishedAngleRecordBest = layout;
                long elapsedMs = angleWatch.ElapsedMilliseconds;
                bool publishLivePreview = angleRecordImproved &&
                    (firstAngleCandidate || elapsedMs - lastLivePreviewReportMs >= 120);
                if (publishLivePreview)
                {
                    // Progress is intentionally throttled, not the optimizer:
                    // show the first valid candidate immediately and then at
                    // most about 8 live-preview refreshes per second per angle.
                    report(new OptimizeProgress(pass, total, angle, archive.Best, archive.Snapshot(),
                        CurrentAngleBest: unfinishedAngleRecordBest, UpdateAnglePreview: true));
                    lastLivePreviewReportMs = elapsedMs;
                }
                bool passBestImproved = bestThisPass == null ||
                    layout.Score < bestThisPass.Layout.Score - 1e-8;
                if (passBestImproved)
                {
                    bestThisPass = current;
                    if (!publishLivePreview && attemptCount % 5 == 1)
                        report(new OptimizeProgress(pass, total, angle, archive.Best, archive.Snapshot(),
                            CurrentAngleBest: unfinishedAngleRecordBest));
                }
                // Different placements with a similar P remain eligible for
                // improvement, rather than losing all but the first layout.
                if (elite.Any(x => Similar(x.Layout, layout))) return current;
                elite.Add(current);
                elite.Sort((x, y) => x.Layout.Score.CompareTo(y.Layout.Score));
                if (elite.Count > 6) elite.RemoveAt(elite.Count - 1);
                return current;
            }

            // Reuse an already-designed RED base cluster as a warm seed.
            // The DXF reference strip may be a GOOD feasible layout and must
            // not be discarded merely because generic random seeds differ.
            // Rotate the whole imported cluster and then allow EACH part to
            // move/rotate independently during refinement.
            if (job.Shapes.Count > 1)
            {
                Pt basePoint = job.Shapes[0].OriginalCenter;
                double radians = angle * Math.PI / 180.0;
                var referenceCenters = job.Shapes.Select(x =>
                    (x.OriginalCenter - basePoint).Rotate(radians)).ToArray();
                if (referenceCenters.Skip(1).Any(c => c.Dist2(new Pt(0, 0)) > 1e-8))
                {
                    var referenceRotations = Enumerable.Repeat((double)angle, job.Shapes.Count).ToArray();
                    Test(referenceCenters, referenceRotations);
                }
            }
            for (int seed = 0; seed < budget.Seeds; seed++)
            {
                Seed(job, settings, characteristic, angle, seed, random, out var centers, out var rotations);
                Test(centers, rotations);
            }
            if (warm != null && job.Shapes.Count > 1)
            {
                var rotations = (double[])warm.Rotations.Clone();
                rotations[0] = angle;
                Test((Pt[])warm.Centers.Clone(), rotations);
            }

            // A local contact-aware walk. Every accepted improvement must
            // re-optimise the shared P, including long-range periodic overlap.
            for (int iteration = 0; iteration < budget.Mutations && elite.Count > 0; iteration++)
            {
                cancel.ThrowIfCancellationRequested();
                Candidate parent = elite[random.Next(Math.Min(elite.Count, 4))];
                var centers = (Pt[])parent.Centers.Clone();
                var rotations = (double[])parent.Rotations.Clone();
                int index = job.Shapes.Count == 1 ? 0 : random.Next(1, job.Shapes.Count);
                double temperature = Math.Max(0.06, 1 - (double)iteration / budget.Mutations);
                double move = characteristic * (0.43 * temperature + 0.025);
                int mode = random.Next(6);
                if (mode == 0 || (mode == 1 && index == 0))
                {
                    rotations[index] += (random.Next(2) == 0 ? -1 : 1) *
                        (random.NextDouble() < 0.20 ? 180 : 45 * temperature);
                }
                else if (mode == 1 && job.Shapes.Count > 1)
                {
                    // Rotate and relocate the same part, avoiding a rigid
                    // two-part orbital constraint as in the V55/V58 solver.
                    rotations[index] += (random.NextDouble() - .5) * 95 * temperature;
                    centers[index] += new Pt((random.NextDouble() * 2 - 1) * move,
                                             (random.NextDouble() * 2 - 1) * move);
                }
                else if (mode == 2 && job.Shapes.Count > 1)
                {
                    // Sample a boundary contact from a configuration-space
                    // (Minkowski difference) interpretation: A-edge contact B-vertex.
                    int other = random.Next(job.Shapes.Count - 1);
                    if (other >= index) other++;
                    centers[index] = ContactCenter(job.Shapes[index], rotations[index],
                        job.Shapes[other].At(centers[other], rotations[other]), settings.Gap, random);
                }
                else if (mode == 3 && job.Shapes.Count > 1)
                {
                    centers[index] += new Pt((random.NextDouble() * 2 - 1) * move, 0);
                }
                else if (mode == 4 && job.Shapes.Count > 1)
                {
                    centers[index] += new Pt(0, (random.NextDouble() * 2 - 1) * move);
                }
                else if (job.Shapes.Count > 1)
                {
                    centers[index] += new Pt((random.NextDouble() * 2 - 1) * move * 2,
                                             (random.NextDouble() * 2 - 1) * move * 2);
                }
                Test(centers, rotations);
                if (iteration % 12 == 11 && bestThisPass != null && job.Shapes.Count > 1)
                {
                    var parentBest = bestThisPass;
                    int k = 1 + random.Next(job.Shapes.Count - 1);
                    foreach (Pt shift in new[] { new Pt(-move * .25, 0), new Pt(move * .25, 0),
                                                 new Pt(0, -move * .25), new Pt(0, move * .25) })
                    {
                        var cc = (Pt[])parentBest.Centers.Clone();
                        cc[k] += shift;
                        Test(cc, (double[])parentBest.Rotations.Clone());
                    }
                }
            }
            // V64: improve the RELATIVE configuration of three or more parts.
            // Keep the proven V60/V63 search and periodic geometry intact. A
            // cooperative pass is performed at a bounded number of reference
            // angles; each proposal is evaluated with the ORIGINAL P solver
            // and full-pair clearance, so a worse layout cannot replace best.
            int interval = Math.Max(1, (int)Math.Ceiling(45.0 / budget.StepDegrees));
            if (job.Shapes.Count >= 3 && bestThisPass != null && pass % interval == 0)
            {
                var initial = bestThisPass;
                var start = new CollectiveRefiner.State(initial.Centers,
                    initial.Rotations, initial.Layout);
                int attempts = settings.Level switch { 0 => 45, 1 => 95, _ => 160 };
                CollectiveRefiner.Improve(start, characteristic, attempts, cancel,
                    (centers, rotations) =>
                    {
                        Candidate? candidate = Test(centers, rotations);
                        return candidate == null ? null :
                            new CollectiveRefiner.State(candidate.Centers,
                                candidate.Rotations, candidate.Layout);
                    });
            }
            if (bestThisPass != null) warm = bestThisPass;
            // Save even when there is no valid solution at this angle.
            // Write only once the angle's regular and cooperative search is complete.
            PublishAngle(new AngleOutcome(pass, angle, unfinishedAngleRecordBest, true,
                angleWatch.ElapsedMilliseconds));
            currentAngleFinished = true;
            report(new OptimizeProgress(pass + 1, total, angle, archive.Best, archive.Snapshot(),
                CurrentAngleBest: unfinishedAngleRecordBest, UpdateAnglePreview: true,
                CurrentAngleCompleted: true));
        }
        // V64 final cooperative pass: the winning angle is not necessarily a
        // multiple of 45 degrees. Refine the actual best distinct layouts as
        // well, so the third (or fourth...) member is never left untouched just
        // because its angle did not receive an earlier cooperative pass.
        if (job.Shapes.Count >= 3)
        {
            int finalists = settings.Level switch { 0 => 2, 1 => 3, _ => 5 };
            int attempts = settings.Level switch { 0 => 55, 1 => 100, _ => 170 };
            // Snapshot: archive.Offer below is allowed to insert better layouts.
            foreach (Solution previous in archive.Snapshot().Take(finalists))
            {
                cancel.ThrowIfCancellationRequested();
                Pt origin = previous.Places[0].Center;
                Pt[] centers = previous.Places.Select(x => x.Center - origin).ToArray();
                double[] rotations = previous.Places.Select(x => x.AngleDeg).ToArray();
                var state = new CollectiveRefiner.State(centers, rotations, previous);
                CollectiveRefiner.Improve(state, characteristic, attempts, cancel,
                    (cc, rr) =>
                    {
                        var candidate = Evaluate(job, settings, cc, rr,
                            previous.RelativeAngle, budget, cancel);
                        if (candidate == null) return null;
                        archive.Offer(candidate);
                        // The V64 finalist pass can improve an angle already saved.
                        // Update that angle's best, not just the global leaderboard.
                        foreach (var pair in completedAngles.ToArray())
                        {
                            if (Math.Abs(pair.Value.Angle - previous.RelativeAngle) > 1e-8) continue;
                            if (BetterForRecord(candidate, pair.Value.Best))
                                PublishAngle(pair.Value with { Best = candidate });
                            break;
                        }
                        return new CollectiveRefiner.State(cc, rr, candidate);
                    });
            }
            report(new OptimizeProgress(total, total, 360, archive.Best, archive.Snapshot()));
        }
        }
        catch (OperationCanceledException)
        {
            // A partially searched angle can still have a feasible layout;
            // preserve it as PARTIAL, never as a completed per-angle optimum.
            if (!currentAngleFinished && lastPass < total)
                PublishAngle(new AngleOutcome(lastPass, lastAngle,
                    unfinishedAngleRecordBest, false, angleWatch.ElapsedMilliseconds));
            // Snapshot includes candidates found in the unfinished angle, even
            // if normal progress notifications have not yet reached the UI.
            if (archive.Count > 0)
                report(new OptimizeProgress(lastPass, total, lastAngle,
                    archive.Best, archive.Snapshot(), CurrentAngleBest: unfinishedAngleRecordBest,
                    UpdateAnglePreview: true));
            throw;
        }
        return archive.Best;
    }

    private static Pt ContactCenter(Shape moving, double degrees, ShapePlace fixedShape,
        double gap, Random random)
    {
        Pt[] fixedPoints = fixedShape.Points;
        Pt[] local = moving.LocalPoints;
        int edge = random.Next(fixedPoints.Length);
        Pt u = fixedPoints[edge], v = fixedPoints[(edge + 1) % fixedPoints.Length];
        Pt delta = v - u;
        double length = Math.Sqrt(delta.Dist2(new Pt(0, 0)));
        // All imported outer silhouettes are CCW; outward edge normal points right.
        Pt outward = length > 1e-10 ? new Pt(delta.Y / length, -delta.X / length) : new Pt(1, 0);
        double t = random.NextDouble();
        Pt contact = u + delta * t + outward * (gap + 0.035);
        Pt movingVertex = local[random.Next(local.Length)].Rotate(degrees * Math.PI / 180);
        return contact - movingVertex;
    }

    private static void Seed(Job job, OptimizationSettings opt, double scale, double angle,
        int seed, Random random, out Pt[] centers, out double[] rotations)
    {
        int count = job.Shapes.Count;
        centers = new Pt[count];
        rotations = new double[count];
        rotations[0] = angle;
        for (int i = 0; i < count; i++)
        {
            if (i > 0)
                rotations[i] = seed switch
                {
                    0 => angle,
                    1 => angle + 180,
                    2 => 180 * (i % 2),
                    3 => 90 * (i % 4),
                    _ => random.Next(0, 8) * 45
                };
            if (i == 0) continue;
            var preceding = job.Shapes[i - 1].At(centers[i - 1], rotations[i - 1]).Bounds;
            var current = job.Shapes[i].At(new Pt(0, 0), rotations[i]).Bounds;
            switch (seed % 5)
            {
                case 0: // Guaranteed non-overlapping vertical BBox seed.
                    centers[i] = new Pt(preceding.MinX - current.MinX,
                        preceding.MaxY + opt.Gap + .08 - current.MinY);
                    break;
                case 1: // Guaranteed non-overlapping horizontal BBox seed.
                    centers[i] = new Pt(preceding.MaxX + opt.Gap + .08 - current.MinX,
                        preceding.MinY - current.MinY);
                    break;
                case 2: centers[i] = new Pt(i * scale * 1.4, (i % 2) * scale * 1.4); break;
                case 3: centers[i] = new Pt((i % 2) * scale * 1.4, (i / 2) * scale * 1.4); break;
                default: centers[i] = new Pt(i * scale * 1.25, i * scale * .75); break;
            }
        }
    }

    private static Solution? Evaluate(Job job, OptimizationSettings settings,
        Pt[] centers, double[] rotations, double angle, SearchBudget budget, CancellationToken cancel)
    {
        var places = new List<ShapePlace>(job.Shapes.Count);
        for (int i = 0; i < job.Shapes.Count; i++)
            places.Add(job.Shapes[i].At(centers[i], rotations[i]));
        var pitch = PeriodicPitchSolver.Find(job, places, settings, budget.PitchSamples,
            budget.RefinePasses, cancel);
        if (!pitch.HasValue) return null;
        var solved = pitch.Value;
        return new Solution { Places = places, Pitch = solved.Pitch, StripWidth = solved.StripWidth,
            Efficiency = solved.Efficiency,
            Score = settings.ByMaterialArea ? solved.Pitch * solved.StripWidth : solved.Pitch,
            RelativeAngle = angle };
    }

    private static bool Similar(Solution a, Solution b)
    {
        if (Math.Abs(a.Pitch - b.Pitch) > .0005 * Math.Max(1, a.Pitch) ||
            Math.Abs(a.StripWidth - b.StripWidth) > .0005 * Math.Max(1, a.StripWidth)) return false;
        return a.Places.Count == b.Places.Count && a.Places.Zip(b.Places).All(pair =>
            Math.Abs(Math.IEEERemainder(pair.First.AngleDeg - pair.Second.AngleDeg, 360)) < .05 &&
            pair.First.Center.Dist2(pair.Second.Center) < 0.0001);
    }

}
