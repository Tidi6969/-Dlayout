namespace DCAD.Dlayout;
internal static class SelfTest
{
    public static int Run(string[]? samplePaths = null)
    {
        string logfile = Path.Combine(AppContext.BaseDirectory, "Dlayout-SelfTest.log");
        try
        {
            Shape Rectangle(string id, double w, double h) => new()
            {
                Handle = id, OriginalCenter = new Pt(0, 0), Area = w * h,
                LocalPoints = [new Pt(0, 0), new Pt(w, 0), new Pt(w, h), new Pt(0, h)]
            };
            var a = Rectangle("A", 10, 10).At(new Pt(0, 0), 0);
            var b = Rectangle("B", 10, 10).At(new Pt(12, 0), 0);
            Check(!Geometry.TooClose(a, b, 1), "Two boxes with 2 units clearance");
            Check(Geometry.TooClose(a, b, 3), "Gap violation detected");
            Check(!Geometry.ValidPeriod([a, b], 1, 22), "Adjacent cycles collide/touch");
            Check(Geometry.ValidPeriod([a, b], 1, 24), "Valid adjacent cycles");
            var far = Rectangle("C", 10, 10).At(new Pt(35, 0), 0);
            Check(!Geometry.ValidPeriod([a, far], 1, 15), "Second-next period collision");
            Check(Geometry.ValidPeriod([a, far], 1, 50), "Non-overlapping distant periods");
            var rotated = Rectangle("R", 4, 12).At(new Pt(0, 0), 90);
            Check(Math.Abs(rotated.Bounds.Width - 12) < 1e-8, "Rigid rotation without distortion");
            var stagger = Rectangle("T", 10, 10).At(new Pt(0, 13), 0);
            Check(Geometry.ValidPeriod([a, stagger], 1, 11.1), "Common K with vertically staggered parts");
            Check(!Geometry.ValidPeriod([a, stagger], 1, 10.1), "Individual part also needs K clearance");

            Job single = new() { Id = "test-1", Shapes = [Rectangle("S", 10, 10)], Gap = 1, Top = 0, Bottom = 0 };
            int count1 = 0;
            var liveProgress = new List<OptimizeProgress>();
            var solution1 = Optimizer.Run(single,
                new OptimizationSettings { Gap = 1, Top = 0, Bottom = 0, Level = 0, ByMaterialArea = false },
                CancellationToken.None, progress =>
                {
                    count1 = Math.Max(count1, progress.Done);
                    liveProgress.Add(progress);
                });
            Check(solution1 != null && solution1.Pitch >= 11 && solution1.Pitch < 11.1, "Single shape finds periodic K");
            Check(count1 == 24, "All single-contour angles visited");
            var liveAngleCandidates = liveProgress.Where(p => p.UpdateAnglePreview &&
                p.CurrentAngleBest != null && !p.CurrentAngleCompleted && p.Done < p.Total).ToList();
            Check(liveAngleCandidates.Select(p => Math.Round(p.Angle, 6)).Distinct().Count() == 24,
                "Live preview receives a valid candidate during every angle, before angle completion");
            Check(liveAngleCandidates.All(p => Math.Abs(p.CurrentAngleBest!.RelativeAngle - p.Angle) < 1e-8),
                "Live preview candidate always belongs to the angle currently being tested");
            Check(Geometry.ValidPeriod(solution1!.Places, 1, solution1.Pitch), "Single shape revalidated");
            // A multi-contour job must use the same engine; every result returns
            // exactly two placements and a common repeated translation K.
            Job multi = new() { Id = "test-2", Shapes = [Rectangle("A", 10, 10), Rectangle("B", 10, 10)], Gap = 1, Top = 1, Bottom = 1 };
            int count2 = 0;
            var solution2 = Optimizer.Run(multi,
                new OptimizationSettings { Gap = 1, Top = 1, Bottom = 1, Level = 0, ByMaterialArea = true },
                CancellationToken.None, progress => count2 = Math.Max(count2, progress.Done));
            Check(solution2 != null && solution2.Places.Count == 2 && solution2.Pitch > 0, "Multi-shape periodic solution");
            Check(count2 == 24, "Every multi-contour orbit angle was evaluated");
            Check(Geometry.ValidPeriod(solution2!.Places, 1, solution2.Pitch), "Multi-shape revalidated");
            // Stop during a search: retain the valid archive for CAD transfer.
            using (var stopSource = new CancellationTokenSource())
            {
                OptimizeProgress? partial = null;
                bool cancelled = false;
                try
                {
                    Optimizer.Run(single,
                        new OptimizationSettings { Gap = 1, Top = 0, Bottom = 0,
                            Level = 0, ResultLimit = 10, ByMaterialArea = false },
                        stopSource.Token, p =>
                        {
                            if (p.Leaders.Count > 0)
                            {
                                partial = p;
                                stopSource.Cancel();
                            }
                        });
                }
                catch (OperationCanceledException) { cancelled = true; }
                Check(cancelled && partial != null && partial.Leaders.Count > 0 &&
                    partial.Leaders.All(s => Geometry.ValidPeriod(s.Places, 1, s.Pitch)),
                    "Stop preserves already computed valid CAD solutions");
            }
            // One type with factor 2 is TWO independently optimisable shapes
            // in EACH period; therefore TWO periods must contain FOUR shapes.
            Job repeated = StepSchedule.Expand(single, new[] { true }, new[] { 2 }, 1, 0, 0);
            Check(repeated.Shapes.Count == 2, "One contour x2 gives two placements per P");
            Check(repeated.Shapes[0].Handle != repeated.Shapes[1].Handle, "Unique identities per copy");
            Check(Math.Abs(repeated.Shapes.Sum(p => p.Area) - 200) < 1e-7, "Area counts per-step multiplicity");
            var repeatedSolution = Optimizer.Run(repeated,
                new OptimizationSettings { Gap = 1, Top = 0, Bottom = 0, Level = 0, ByMaterialArea = false },
                CancellationToken.None, _ => { });
            Check(repeatedSolution != null && repeatedSolution.Places.Count == 2 && repeatedSolution.Pitch > 0,
                "Hybrid periodic solver handles A x2");
            Check(Geometry.ValidPeriod(repeatedSolution!.Places, 1, repeatedSolution.Pitch),
                "A x2 verified with ALL overlapping periods");
            // Regression: a checkbox toggle must never add/remove contour TYPES
            // or alter the saved coefficient; only per-P expansion may add copies.
            var chosen = new ContourSelectionState(2);
            Check(chosen.TypeCount == 2 && chosen.PartsPerPitch == 2, "Two DXF outer contours create exactly two stable rows");
            chosen.Set(0, true, 2);
            chosen.Set(1, false, 3);
            Check(chosen.TypeCount == 2 && chosen.SelectedTypes == 1 && chosen.PartsPerPitch == 2,
                "Disabling B keeps B x3 but excludes it from the current P");
            var selectedFirst = chosen.Snapshot();
            Job onlyA = StepSchedule.Expand(multi, selectedFirst.Enabled, selectedFirst.Factors, 1, 0, 0);
            Check(onlyA.Shapes.Count == 2 && chosen.TypeCount == 2,
                "A x2 expansion does not add rows to the source list");
            chosen.Set(1, true, chosen[1].Factor);
            Check(chosen.SelectedTypes == 2 && chosen.PartsPerPitch == 5 && chosen[1].Factor == 3,
                "Re-enabling B preserves x3, A x2 + B x3 gives five per P");
            var selectedAgain = chosen.Snapshot();
            Job both = StepSchedule.Expand(multi, selectedAgain.Enabled, selectedAgain.Factors, 1, 0, 0);
            Check(both.Shapes.Count == 5 && chosen.TypeCount == 2,
                "Repeated toggle does not create phantom contours");
            chosen.Set(1, false, 3);
            chosen.Set(1, true, 3);
            chosen.Set(1, false, 3);
            Check(chosen.TypeCount == 2 && chosen[1].Factor == 3 && chosen.PartsPerPitch == 2,
                "Repeatedly toggling B is idempotent");
            var fresh = new ContourSelectionState(2);
            Check(fresh.SelectedTypes == 2 && fresh.PartsPerPitch == 2,
                "DXF selections are session-only; no persistent selection file");
            // Standalone DXF input/output path, including an internal hole.
            // The external silhouette alone is used for the P objective.
            string samplePath = Path.Combine(AppContext.BaseDirectory, "Dlayout-SelfTest-input.dxf");
            string resultPath = Path.Combine(AppContext.BaseDirectory, "Dlayout-SelfTest-output.dxf");
            try
            {
                static string Box(double x, double y) => $"0\nLWPOLYLINE\n8\nPARTS\n90\n4\n70\n1\n10\n{x}\n20\n{y}\n10\n{x+10}\n20\n{y}\n10\n{x+10}\n20\n{y+10}\n10\n{x}\n20\n{y+10}\n";
                const string hole = "0\nCIRCLE\n8\nPARTS\n10\n5\n20\n5\n40\n2\n";
                File.WriteAllText(samplePath, "0\nSECTION\n2\nENTITIES\n" + Box(0,0) + hole + Box(35,0) + "0\nENDSEC\n0\nEOF\n");
                Job dxf = Job.LoadDxfFiles(new[] { samplePath });
                Check(dxf.Shapes.Count == 2, "DXF importer reads two external silhouettes and ignores the inner circle");
                Check(Math.Abs(dxf.Shapes[0].Area - 100) < 1e-6, "DXF outer silhouette area counts no holes");
                // Independent multipliers per type, all types share ONE P.
                Job scheduled = StepSchedule.Expand(dxf, new[] { true, true }, new[] { 2, 1 }, 1, 1, 1);
                Check(scheduled.Shapes.Count == 3, "A x2 plus B x1 = three parts per P");
                var arranged = scheduled.Shapes.Select((part, i) => part.At(new Pt(0, i * 15), 0)).ToList();
                Check(Geometry.ValidPeriod(arranged, 1, 15), "Three parts repeat at P=15 without collision");
                var sampleResult = new Solution { Places = arranged, Pitch = 15, StripWidth = 42,
                    Efficiency = 300.0 / (15 * 42) * 100, Score = 15 * 42, RelativeAngle = 0 };
                DxfExporter.Save(resultPath, sampleResult, 2, 1, 1, 1);
                Job exported = Job.LoadDxfFiles(new[] { resultPath });
                Check(exported.Shapes.Count == 3, "Reimport of RED/YELLOW output identifies only the base step");
                Check(CountInstances(resultPath, "DLAYOUT_STEP_RED") == 3 &&
                    CountInstances(resultPath, "DLAYOUT_STEP_YELLOW") == 3,
                    "Export contains three red and three yellow DXF contours");
                // Check DXF as group-code/value pairs, NOT raw newline-delimited
                // substrings. StreamWriter.WriteLine uses CRLF on Windows, while
                // the previous test expected LF only and falsely failed.
                string[] dxfLines = File.ReadAllLines(resultPath);
                Check(dxfLines.Length % 2 == 0 &&
                      HasDxfPair(dxfLines, "1", "AC1009") &&
                      HasDxfPair(dxfLines, "2", "TABLES") &&
                      HasDxfPair(dxfLines, "2", "LAYER") &&
                      HasDxfPair(dxfLines, "0", "POLYLINE") &&
                      HasDxfPair(dxfLines, "0", "VERTEX") &&
                      HasDxfPair(dxfLines, "0", "SEQEND") &&
                      HasDxfPair(dxfLines, "0", "EOF"),
                    "Compatible DXF R12 sections, declared tables and classic POLYLINE");
                Check(dxfLines.Any(line => line.Contains("DLAYOUT P=15")), "DXF label uses P not K");
                DxfExporter.Save(resultPath, repeatedSolution!, 2, 0, 0, 1);
                Job repeatedExport = Job.LoadDxfFiles(new[] { resultPath });
                Check(repeatedExport.Shapes.Count == 2, "Reimport of A x2 result retains two red originals");
                Check(CountInstances(resultPath, "DLAYOUT_STEP_RED") == 2 &&
                    CountInstances(resultPath, "DLAYOUT_STEP_YELLOW") == 2,
                    "A x2 exports two red and two yellow contours");
            }
            finally
            {
                try { File.Delete(samplePath); } catch { }
                try { File.Delete(resultPath); } catch { }
            }
            // Two real progressive-die strip layouts: red originals plus yellow
            // rigid copies at the measured P. Input must identify RED only.
            if (samplePaths != null)
            {
                for (int i = 0; i < Math.Min(2, samplePaths.Length); i++)
                {
                    string path = samplePaths[i];
                    Check(File.Exists(path), "Benchmark DXF exists: " + path);
                    Job benchmark = Job.LoadDxfFiles(new[] { path });
                    Check(benchmark.Shapes.Count == 2,
                        "Verified red/yellow DXF imports exactly TWO red originals: " + path);
                    double referenceP = i == 0 ? 59.71762368039 : 65.20226251158;
                    var original = benchmark.Shapes.Select(sh => sh.At(sh.OriginalCenter, 0)).ToList();
                    Check(Geometry.ValidPeriod(original, 3, referenceP),
                        "Measured reference P is periodic and valid at 3mm gap: " + path);
                }
            }
            TestCadBridge();
            TestSolutionArchive();
            TestV82CadArchive();
            TestStepPhaseRebase();
            TestV65Controls();
            TestEveryAngleArchive();
            if (samplePaths != null && samplePaths.Length >= 3)
                TestThreePartCooperation(samplePaths[2]);
            File.WriteAllText(logfile, "DLAYOUT V102 SELFTEST PASS: live per-angle preview, result sorting and nearest search, V60 compatibility, three-part collective improvement, gap and far-period validation, and DXF benchmarks\n");
            return 0;
        }
        catch (Exception e)
        {
            try { File.WriteAllText(logfile, "DLAYOUT V102 SELFTEST FAILED:\n" + e); } catch { }
            return 2;
        }
    }
    // End-to-end contract, independent of AutoCAD: parse source CAD shape
    // identities, respect per-step coefficients, serialize chosen placements.
    private static void TestEveryAngleArchive()
    {
        Shape rect = new Shape { Handle = "A#1", OriginalCenter = new Pt(0, 0),
            LocalPoints = [new Pt(0, 0), new Pt(10, 0), new Pt(10, 10), new Pt(0, 10)], Area = 100 };
        Job job = new Job { Id = "angle-test", Shapes = [rect], Gap = 1, Top = 0, Bottom = 0 };
        var settings = new OptimizationSettings { Level = 0, Gap = 1, Top = 0, Bottom = 0,
            ByMaterialArea = false, ResultLimit = 10 };
        var observed = new List<AngleOutcome>();
        var result = Optimizer.Run(job, settings, CancellationToken.None, _ => { }, a => observed.Add(a));
        Check(result != null && observed.Count == 24, "All 24 tested angles produce independent records");
        Check(observed.Select(x => x.Index).Distinct().Count() == 24 &&
            observed.All(x => x.Complete), "No angle is silently dropped by global limit of 10");
        Check(observed.All(x => x.Best != null &&
            Math.Abs(x.Best.RelativeAngle - x.Angle) < 1e-8), "Every recorded winner belongs to its tested angle");
        string temp = Path.Combine(Path.GetTempPath(), "DlayoutV102ArchiveTest_" + Guid.NewGuid().ToString("N"));
        string duser = Path.Combine(temp, "DUser");
        Directory.CreateDirectory(duser);
        try
        {
            var journal = AngleResultJournal.Begin(duser, job, settings);
            foreach (var a in observed) journal.Append(a);
            // Include NO_SOLUTION and PARTIAL in journal round-trip checks.
            journal.Append(new AngleOutcome(3, 45, null, true, 123));
            journal.Append(observed[3]);
            journal.Finish("COMPLETED");
            var loaded = AngleResultJournal.Load(journal.PathName, job, settings);
            Check(loaded.Count == 24 && loaded[3].Best != null && loaded[3].Complete,
                "Latest per-angle update survives saved file round-trip");
            Check(loaded.All(x => x.Best != null && x.Best.Places.Count == 1 &&
                Geometry.ValidPeriod(x.Best.Places, 1, x.Best.Pitch)),
                "Saved placements reconstruct and retain clearance validation");
            bool differentGeometryRejected = false;
            try
            {
                Shape other = new Shape { Handle = "WRONG#1", OriginalCenter = rect.OriginalCenter,
                    LocalPoints = rect.LocalPoints, Area = rect.Area };
                AngleResultJournal.Load(journal.PathName,
                    new Job { Id = "angle-test", Shapes = [other], Gap = 1, Top = 0, Bottom = 0 }, settings);
            }
            catch (InvalidDataException) { differentGeometryRejected = true; }
            Check(differentGeometryRejected, "Saved results cannot be applied to a different geometry");
            bool differentSettingsRejected = false;
            try
            {
                AngleResultJournal.Load(journal.PathName, job, new OptimizationSettings {
                    Level = 0, Gap = 2, Top = 0, Bottom = 0, ByMaterialArea = false, ResultLimit = 10 });
            }
            catch (InvalidDataException) { differentSettingsRejected = true; }
            Check(differentSettingsRejected, "Saved results cannot be applied to different clearances");
            var interrupted = AngleResultJournal.Begin(duser, job, settings);
            interrupted.Append(new AngleOutcome(0, 0, null, true, 1));
            interrupted.Append(new AngleOutcome(1, 15, observed[1].Best, false, 3));
            interrupted.Finish("CANCELLED");
            var incomplete = AngleResultJournal.Load(interrupted.PathName, job, settings);
            Check(incomplete.Count == 2 && incomplete[0].Best == null &&
                incomplete[0].Complete && !incomplete[1].Complete && incomplete[1].Best != null,
                "NO_SOLUTION and cancelled PARTIAL angle states survive reload");
        }
        finally { try { Directory.Delete(temp, true); } catch { } }
    }

    private static void TestCadBridge()
    {
        string dir = Path.Combine(Path.GetTempPath(), "DlayoutV82SelfTest_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            string input = Path.Combine(dir, "job.xml");
            var id = "1234567890abcdef1234567890abcdef";
            var el = new System.Xml.Linq.XElement("dlayoutJob",
                new System.Xml.Linq.XAttribute("protocol", "2"),
                new System.Xml.Linq.XAttribute("version", "98"),
                new System.Xml.Linq.XAttribute("id", id),
                new System.Xml.Linq.XAttribute("gap", "1"),
                new System.Xml.Linq.XAttribute("top", "0"),
                new System.Xml.Linq.XAttribute("bottom", "0"),
                new System.Xml.Linq.XElement("parts", new System.Xml.Linq.XElement("part",
                    new System.Xml.Linq.XAttribute("handle", "AB12"),
                    new System.Xml.Linq.XAttribute("cx", "5"),
                    new System.Xml.Linq.XAttribute("cy", "5"),
                    new System.Xml.Linq.XAttribute("netArea", "87.4336293856"),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "0"), new System.Xml.Linq.XAttribute("y", "0")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "10"), new System.Xml.Linq.XAttribute("y", "0")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "10"), new System.Xml.Linq.XAttribute("y", "10")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "0"), new System.Xml.Linq.XAttribute("y", "10")))));
            new System.Xml.Linq.XDocument(el).Save(input);
            CadJobRequest loaded = CadJobBridge.Load(input);
            Check(loaded.Id == id && loaded.Input.Shapes.Count == 1, "CAD V70 job imports one original silhouette");
            Check(Math.Abs(loaded.Input.Shapes[0].Area - 87.4336293856) < 1e-6,
                "CAD netArea excludes an internal circle before optimization");
            Job scheduled = StepSchedule.Expand(loaded.Input, [true], [2], 1, 0, 0);
            Check(Math.Abs(scheduled.Shapes.Sum(sh => sh.Area) - 2 * 87.4336293856) < 1e-5,
                "Net area propagates through part per-P coefficients");
            var arranged = scheduled.Shapes.Select((sh, i) => sh.At(new Pt(5, 5 + 15*i), 0)).ToList();
            Check(Geometry.ValidPeriod(arranged, 1, 12), "CAD shape copies repeat with period clearance");
            var result = new Solution { Places = arranged, Pitch = 12,
                StripWidth = 25, Score = 12*25, Efficiency = 200.0/(12*25)*100, RelativeAngle = 0 };
            string output = CadJobBridge.SaveResult(loaded, scheduled, result, 1, 0, 0, 0);
            var xml = System.Xml.Linq.XDocument.Load(output).Root!;
            Check((string?)xml.Attribute("protocol") == "2" && (string?)xml.Attribute("id") == id &&
                xml.Element("placements")?.Elements("part").Count() == 2,
                "CAD V70 result maps A#1 and A#2 to one source handle");
            Check(Math.Abs(double.Parse((string)xml.Attribute("relativeAngle")!,
                System.Globalization.CultureInfo.InvariantCulture) - result.RelativeAngle) < 1e-9,
                "CAD root fallback carries the global tested angle");
            Check(Math.Abs(double.Parse((string)xml.Element("solutions")!.Element("solution")!.Attribute("relativeAngle")!,
                System.Globalization.CultureInfo.InvariantCulture) - result.RelativeAngle) < 1e-9,
                "CAD solution archive carries the global tested angle");
            Check(xml.Element("placements")?.Elements("part").Select(x => (string?)x.Attribute("handle"))
                .SequenceEqual(["AB12#1", "AB12#2"]) == true, "CAD V70 unique per-P identities");
            Check(Math.Abs(double.Parse((string)xml.Attribute("pitch")!, System.Globalization.CultureInfo.InvariantCulture)-12)<1e-7,
                "CAD V70 P value round trip");
            // Full CAD protocol regression: a part six periods away must be
            // transmitted near the first period, without changing P or its Y.
            var farPlaces = scheduled.Shapes.Select((sh, i) =>
                sh.At(new Pt(5 + (i == 1 ? 6 * 12 : 0), 5 + 15 * i), 0)).ToList();
            Check(Geometry.ValidPeriod(farPlaces, 1, 12), "Far-phase layout is valid before export");
            var farSolution = new Solution { Places = farPlaces, Pitch = 12,
                StripWidth = 25, Score = 300, Efficiency = 200.0/300, RelativeAngle = 0 };
            string phaseOutput = CadJobBridge.SaveResult(loaded, scheduled, farSolution, 1, 0, 0, 0);
            var phaseRoot = System.Xml.Linq.XDocument.Load(phaseOutput).Root!;
            var phasePart = phaseRoot.Element("placements")!.Elements("part").Last();
            double phaseX = double.Parse((string)phasePart.Attribute("x")!, System.Globalization.CultureInfo.InvariantCulture);
            double phaseY = double.Parse((string)phasePart.Attribute("y")!, System.Globalization.CultureInfo.InvariantCulture);
            Check(phaseX >= 5 - 1e-9 && phaseX < 17 + 1e-9 && Math.Abs(phaseY - 20) < 1e-9,
                "CAD protocol removes six-period offset and preserves Y and original Pitch");
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    // Real-world regression from the user's 3-red + 3-yellow V63 DXF.
    // The third red outline can move closer to the second outline without
    // changing Pitch; the original solution wasted strip width. The test
    // ensures cooperative refining actually tries to improve this layout,
    // and EVERY candidate passes the original full periodic verifier.
    private static void TestThreePartCooperation(string sourceDxf)
    {
        Check(File.Exists(sourceDxf), "Three-part regression DXF exists");
        Job job = Job.LoadDxfFiles([sourceDxf]);
        Check(job.Shapes.Count == 3, "Three RED original contours; YELLOW copies are not extra parts");
        const double pitch = 32.2903;
        const double gap = 1.0;
        Pt anchor = job.Shapes[0].OriginalCenter;
        Pt[] originalCenters = job.Shapes.Select(s => s.OriginalCenter - anchor).ToArray();
        double[] angles = new double[job.Shapes.Count];

        CollectiveRefiner.State? EvaluateFixedPeriod(Pt[] centers, double[] rotations)
        {
            var placed = job.Shapes.Select((s, i) => s.At(centers[i], rotations[i])).ToList();
            if (!Geometry.ValidPeriod(placed, gap, pitch)) return null;
            var bounds = Geometry.Bounds(placed);
            double stripWidth = bounds.Height + 2.0;
            double area = job.Shapes.Sum(s => s.Area);
            var solution = new Solution
            {
                Places = placed, Pitch = pitch, StripWidth = stripWidth,
                Efficiency = area / (pitch * stripWidth) * 100.0,
                Score = pitch * stripWidth, RelativeAngle = 0
            };
            return new CollectiveRefiner.State(centers, rotations, solution);
        }

        var initial = EvaluateFixedPeriod(originalCenters, angles);
        Check(initial != null && Math.Abs(initial.Layout.StripWidth - 111.7719) < .02,
            "Reference 3-part V63 layout: W approximately 111.772");
        double characteristic = job.Shapes.Max(s =>
            Math.Max(BBox.From(s.LocalPoints).Width, BBox.From(s.LocalPoints).Height)) + gap;
        var improved = CollectiveRefiner.Improve(initial!, characteristic, 150,
            CancellationToken.None, EvaluateFixedPeriod);
        Check(improved.Layout.StripWidth < initial!.Layout.StripWidth - 1.0,
            "Cooperative search tightens the REAL third-part gap and reduces W");
        Check(improved.Layout.Places.Count == 3 &&
            Geometry.ValidPeriod(improved.Layout.Places, gap, pitch),
            "Refined 3-part layout keeps ALL intra-step and multi-step gaps");
        Check(improved.Layout.Score < initial!.Layout.Score - 1.0 &&
            Math.Abs(improved.Layout.Pitch - pitch) < 1e-8,
            "Reduced P*W at identical Pitch (not isolated RED tightness)");
    }

    // A physically identical periodic layout must not require manually
    // moving one silhouette forward/backward five or six stations in CAD.
    private static void TestStepPhaseRebase()
    {
        var a = new Shape { Handle = "A", OriginalCenter = new Pt(0,0),
            LocalPoints = new[] { new Pt(0,0), new Pt(9,0), new Pt(9,7), new Pt(0,7) }, Area = 63 };
        var b = new Shape { Handle = "B", OriginalCenter = new Pt(0,0),
            LocalPoints = new[] { new Pt(0,0), new Pt(8,0), new Pt(8,7), new Pt(0,7) }, Area = 56 };
        const double pitch = 20;
        var raw = new List<ShapePlace> { a.At(new Pt(0,0),0), b.At(new Pt(6*pitch+3, 10),0) };
        var normalized = StepPhase.Rebase(raw, pitch);
        Check(Math.Abs(normalized[0].Bounds.MinX - raw[0].Bounds.MinX) < 1e-9,
            "Step phase keeps the leftmost reference part fixed");
        Check(normalized.All(p => p.Bounds.MinX >= raw[0].Bounds.MinX - 1e-9 &&
            p.Bounds.MinX < raw[0].Bounds.MinX + pitch + 1e-9),
            "All contours begin within the first station interval");
        for (int i = 0; i < raw.Count; i++)
        {
            double delta = (raw[i].Center.X - normalized[i].Center.X) / pitch;
            Check(Math.Abs(delta - Math.Round(delta)) < 1e-8,
                "Periodic rebase moves part by a whole number of pitch units");
            Check(raw[i].Points.Length == normalized[i].Points.Length &&
                Math.Abs(raw[i].Shape.Area - normalized[i].Shape.Area) < 1e-9,
                "Rebase preserves source contours and area");
            Check(raw[i].AngleDeg == normalized[i].AngleDeg, "Rebase preserves original rotation");
        }
        Check(Geometry.ValidPeriod(raw, 0, pitch) == Geometry.ValidPeriod(normalized, 0, pitch),
            "Periodic occupancy invariant after phase rebase");
        var again = StepPhase.Rebase(normalized, pitch);
        Check(again.Zip(normalized).All(z => z.First.Center.Dist2(z.Second.Center) < 1e-12),
            "Station normalization is idempotent");
    }

    private static void TestV82CadArchive()
    {
        string dir = Path.Combine(Path.GetTempPath(), "DlayoutV82Solutions_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            string file = Path.Combine(dir, "job.xml");
            string id = "1234567890abcdef1234567890abcdef";
            var xml = new System.Xml.Linq.XElement("dlayoutJob",
                new System.Xml.Linq.XAttribute("protocol", "2"),
                new System.Xml.Linq.XAttribute("version", "98"), new System.Xml.Linq.XAttribute("id", id),
                new System.Xml.Linq.XAttribute("gap", "0"), new System.Xml.Linq.XAttribute("top", "0"),
                new System.Xml.Linq.XAttribute("bottom", "0"),
                new System.Xml.Linq.XElement("parts", new System.Xml.Linq.XElement("part",
                    new System.Xml.Linq.XAttribute("handle", "A1"),
                    new System.Xml.Linq.XAttribute("cx", "0"),
                    new System.Xml.Linq.XAttribute("cy", "0"),
                    new System.Xml.Linq.XAttribute("netArea", "100"),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "0"), new System.Xml.Linq.XAttribute("y", "0")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "10"), new System.Xml.Linq.XAttribute("y", "0")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "10"), new System.Xml.Linq.XAttribute("y", "10")),
                    new System.Xml.Linq.XElement("p", new System.Xml.Linq.XAttribute("x", "0"), new System.Xml.Linq.XAttribute("y", "10")))));
            new System.Xml.Linq.XDocument(xml).Save(file);
            var req = CadJobBridge.Load(file);
            var expanded = StepSchedule.Expand(req.Input, new[] { true }, new[] { 1 }, 0, 0, 0);
            var archive = new List<Solution>();
            for (int i = 0; i < 500; i++)
            {
                var p = expanded.Shapes[0].At(new Pt(i * 1.5, 0), 0);
                archive.Add(new Solution { Places = new List<ShapePlace> { p }, Pitch = 20 + i,
                    StripWidth = 10, Score = 200 + 10 * i, Efficiency = 100.0 / ((20 + i) * 10) * 100,
                    RelativeAngle = i * 0.25 });
            }
            string output = CadJobBridge.SaveResult(req, expanded, archive, archive[200], 0, 0, 0, 0);
            var doc = System.Xml.Linq.XDocument.Load(output).Root!;
            var nodes = doc.Element("solutions")!;
            Check(nodes.Elements("solution").Count() == 500 && (string?)nodes.Attribute("selected") == "200",
                "V82 CAD transfers 500 archived entries and selected index");
            Check(Math.Abs(double.Parse((string)nodes.Elements("solution").Last().Attribute("pitch")!, System.Globalization.CultureInfo.InvariantCulture) - 519) < 1e-8,
                "CAD solution archive retains each independent pitch");
            Check(Math.Abs(double.Parse((string)nodes.Elements("solution").ElementAt(200).Attribute("relativeAngle")!,
                System.Globalization.CultureInfo.InvariantCulture) - 50) < 1e-8,
                "CAD solution archive retains each global tested angle");
            Check(Math.Abs(double.Parse((string)doc.Attribute("relativeAngle")!,
                System.Globalization.CultureInfo.InvariantCulture) - 50) < 1e-8,
                "CAD selected-result fallback retains the global tested angle");
            Check(doc.Element("placements")!.Elements("part").Count() == 1,
                "CAD v2 fallback still contains selected placements");
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    private static void TestV65Controls()
    {
        Check(Optimizer.AngleCount(0, 5) == 24, "Fast preset preserves V64 angle count");
        Check(Optimizer.AngleCount(1, 5) == 36, "Balanced preset preserves V64 angle count");
        Check(Optimizer.AngleCount(2, 5) == 72, "Deep preset preserves V64 angle count");
        Check(Optimizer.AngleCount(3, 5) == 120, "Very deep 3 degree sweep");
        Check(Optimizer.AngleCount(4, 5) == 360, "Maximum 1 degree sweep");
        Check(Optimizer.AngleCount(5, .5) == 720, "Custom angle .5 degrees");
        Check(Optimizer.AngleCount(5, 7) == 52, "Custom non-divisor of 360");
        foreach (double illegal in new[] { -2.0, 0, 90, 120, double.NaN })
        {
            try { Optimizer.AngleCount(5, illegal); Check(false, "Rejected custom angle " + illegal); }
            catch (ArgumentOutOfRangeException) { }
        }
        var arranged = new List<Solution>();
        Shape shape = new() { Handle = "T", OriginalCenter = new Pt(0, 0), Area = 1,
            LocalPoints = [new Pt(0, 0), new Pt(1, 0), new Pt(1, 1), new Pt(0, 1)] };
        arranged.Add(new Solution { Places = [shape.At(new Pt(25, 0), 0)],
            Pitch = 25, StripWidth = 70, Score = 3, Efficiency = 40, RelativeAngle = 45 });
        arranged.Add(new Solution { Places = [shape.At(new Pt(55, 0), 0)],
            Pitch = 55, StripWidth = 30, Score = 1, Efficiency = 70, RelativeAngle = 15 });
        arranged.Add(new Solution { Places = [shape.At(new Pt(85, 0), 0)],
            Pitch = 85, StripWidth = 50, Score = 2, Efficiency = 20, RelativeAngle = 75 });
        Check(ResultOrdering.BestIndex(arranged) == 1,
            "Best objective remains identifiable before and after display sorting");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Angle,
            (int)ResultDirection.Ascending)[0].RelativeAngle == 15, "Angle ascending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Angle,
            (int)ResultDirection.Descending)[0].RelativeAngle == 75, "Angle descending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Efficiency,
            (int)ResultDirection.Ascending)[0].Efficiency == 20, "Efficiency ascending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Efficiency,
            (int)ResultDirection.Descending)[0].Efficiency == 70, "Efficiency descending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Pitch,
            (int)ResultDirection.Ascending)[0].Pitch == 25, "Pitch ascending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Pitch,
            (int)ResultDirection.Descending)[0].Pitch == 85, "Pitch descending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Height,
            (int)ResultDirection.Ascending)[0].StripWidth == 30, "Height ascending");
        Check(ResultOrdering.Order(arranged, (int)ResultMetric.Height,
            (int)ResultDirection.Descending)[0].StripWidth == 70, "Height descending");
        Check(ResultOrdering.OrderNearest(arranged, (int)ResultMetric.Angle, 44)[0].RelativeAngle == 45,
            "Nearest angle search");
        Check(ResultOrdering.OrderNearest(arranged, (int)ResultMetric.Efficiency, 51)[0].Efficiency == 40,
            "Nearest efficiency search");
        Check(ResultOrdering.OrderNearest(arranged, (int)ResultMetric.Pitch, 60)[0].Pitch == 55,
            "Nearest pitch search");
        Check(ResultOrdering.OrderNearest(arranged, (int)ResultMetric.Height, 52)[0].StripWidth == 50,
            "Nearest height search");
        var angleRows = new List<AngleOutcome> {
            new(0, 10, null, true, 0),
            new(1, 30, arranged[1], true, 0),
            new(2, 20, arranged[2], true, 0)
        };
        Check(ResultOrdering.OrderAngles(angleRows, (int)ResultMetric.Efficiency,
            (int)ResultDirection.Ascending)[0].Best == arranged[2] &&
            ResultOrdering.OrderAngles(angleRows, (int)ResultMetric.Efficiency,
                (int)ResultDirection.Ascending)[^1].Best == null,
            "Per-angle sort keeps no-solution entries at the end for solution metrics");
        Check(ResultOrdering.OrderAnglesNearest(angleRows, (int)ResultMetric.Angle, 11)[0].Best == null,
            "Per-angle nearest-angle search retains no-solution angle records");
        Check(ResultOrdering.OrderAnglesNearest(angleRows, (int)ResultMetric.Efficiency, 65)[0].Best == arranged[1],
            "Per-angle nearest search ranks available metric values");
    }

    private static void TestSolutionArchive()
    {
        // Exercise 10/20/50 results without changing the V60 optimiser's
        // test schedule, random seeds, elite choices, geometry or P scan.
        foreach (int limit in new[] { 10, 25, 50, 100, 200, 500 })
        {
            var archive = new SolutionArchive(limit, 12);
            Shape shape = new()
            {
                Handle = "A", OriginalCenter = new Pt(0, 0), Area = 100,
                LocalPoints = [new Pt(0, 0), new Pt(10, 0), new Pt(10, 10), new Pt(0, 10)]
            };
            Shape shapeB = new()
            {
                Handle = "B", OriginalCenter = new Pt(0, 0), Area = 100,
                LocalPoints = [new Pt(0, 0), new Pt(10, 0), new Pt(10, 10), new Pt(0, 10)]
            };
            // 540 genuinely DIFFERENT arrangements: B moves relative to A.
            // A single isolated shape cannot have 500 unique whole-turn rotations.
            for (int i = 539; i >= 0; i--)
            {
                double pitch = 20 + i * .01;
                List<ShapePlace> placed = [shape.At(new Pt(0, 0), 0),
                    shapeB.At(new Pt(0, 22 + i * .2), 0)];
                Check(Geometry.ValidPeriod(placed, 1, pitch), "Archive seed geometries are valid periodic steps");
                var candidate = new Solution
                {
                    Places = placed, Pitch = pitch, StripWidth = 150,
                    Score = pitch * 150, Efficiency = 20000 / (pitch * 150), RelativeAngle = 0
                };
                archive.Offer(candidate);
            }
            Check(archive.Count == limit, "Archive capacity " + limit);
            Check(archive.Best != null && Math.Abs(archive.Best.Pitch - 20) < 1e-8,
                "V60 best remains first in archive");
            var snapshot = archive.Snapshot();
            Check(snapshot.Select(x => x.Score).SequenceEqual(snapshot.Select(x => x.Score).Order()),
                "Results sorted by original V60 objective");
            var duplicate = new Solution
            {
                Places = [shape.At(new Pt(300, 25), 0), shapeB.At(new Pt(300, 47), 0)],
                Pitch = 19.5, StripWidth = 150,
                Score = 19.5 * 150, Efficiency = 20000 / (19.5 * 150), RelativeAngle = 0
            };
            Check(archive.Offer(duplicate), "Better shifted duplicate replaces inferior candidate");
            Check(archive.Count == limit && Math.Abs(archive.Best!.Pitch - 19.5) < 1e-8,
                "Normalized translation and quality ranking");
            Check(!archive.Offer(new Solution
            {
                Places = [shape.At(new Pt(600, 55), 0), shapeB.At(new Pt(600, 77), 0)],
                Pitch = 21, StripWidth = 150,
                Score = 21 * 150, Efficiency = 20000 / (21 * 150), RelativeAngle = 0
            }), "Worse equivalent position does not duplicate archive entry");
            Check(snapshot.Count == limit && Math.Abs(snapshot[0].Pitch - 20) < 1e-8,
                "Progress snapshot never mutates after archive updates");
        }
    }

    // DXF group codes and values occupy pairs of lines regardless of whether
    // the file uses Windows CRLF, Unix LF, or another valid line ending.
    private static bool HasDxfPair(string[] lines, string groupCode, string value)
    {
        for (int i = 0; i + 1 < lines.Length; i += 2)
        {
            if (lines[i].Trim() == groupCode && lines[i + 1].Trim() == value)
                return true;
        }
        return false;
    }

    private static int CountInstances(string path, string layer)
    {
        // Count only POLYLINE/LWPOLYLINE entity headers. R12 VERTEX and SEQEND
        // also have a group 8 (layer), and must never count as extra shapes.
        string[] lines = File.ReadAllLines(path);
        int count = 0;
        for (int i = 0; i + 1 < lines.Length; i += 2)
        {
            if (lines[i].Trim() != "0") continue;
            string entity = lines[i + 1].Trim();
            if (entity != "POLYLINE" && entity != "LWPOLYLINE") continue;
            for (int k = i + 2; k + 1 < lines.Length && lines[k].Trim() != "0"; k += 2)
            {
                if (lines[k].Trim() == "8" && lines[k + 1].Trim() == layer)
                { count++; break; }
            }
        }
        return count;
    }
    private static void Check(bool good, string name)
    {
        if (!good) throw new InvalidOperationException("Failed: " + name);
    }
}
