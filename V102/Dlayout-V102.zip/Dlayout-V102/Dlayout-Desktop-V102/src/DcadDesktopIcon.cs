using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace DCAD.Dlayout;

internal static class DcadDesktopIcon
{
    internal static void Attach(Form form)
    {
        // Same DcadLogo ICO as DPrint, embedded for portable single-file EXE.
        using Stream? stream = typeof(DcadDesktopIcon).Assembly
            .GetManifestResourceStream("Dlayout.icon.DcadLogo.ico");
        if (stream == null) { form.ShowIcon = false; return; }
        using var source = new Icon(stream);
        form.Icon = (Icon)source.Clone();
        form.ShowIcon = true;
    }
}
