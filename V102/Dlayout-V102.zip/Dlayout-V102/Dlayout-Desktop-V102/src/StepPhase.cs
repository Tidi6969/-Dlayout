using System;
using System.Collections.Generic;
using System.Linq;

namespace DCAD.Dlayout;

// Presentation-only canonical representative of an infinite periodic strip.
// An individual placement can be 5-6 P away in an optimiser solution, even
// though shifting it by an integer P produces precisely the same infinite
// stamped pattern. Never change angles, P, W, gap or the optimiser itself.
internal static class StepPhase
{
    internal static List<ShapePlace> Rebase(IReadOnlyList<ShapePlace> placements, double pitch)
    {
        if (placements == null || placements.Count == 0 || !double.IsFinite(pitch) || pitch <= 0)
            throw new ArgumentException("Invalid step phase input.");
        double first = placements.Min(p => p.Bounds.MinX);
        var canonical = new List<ShapePlace>(placements.Count);
        foreach (var p in placements)
        {
            double periods = Math.Floor((p.Bounds.MinX - first) / pitch);
            double shift = periods * pitch;
            if (!double.IsFinite(shift)) throw new InvalidDataException("Invalid periodic phase.");
            // Same physical shape and orientation. Only its chosen period changes.
            canonical.Add(shift == 0 ? p : p.Shape.At(new Pt(p.Center.X - shift, p.Center.Y), p.AngleDeg));
        }
        return canonical;
    }
    internal static Solution Rebase(Solution solution)
    {
        return new Solution {
            Places = Rebase(solution.Places, solution.Pitch),
            Pitch = solution.Pitch, StripWidth = solution.StripWidth,
            Efficiency = solution.Efficiency, Score = solution.Score,
            RelativeAngle = solution.RelativeAngle
        };
    }
}
