using System.Globalization;
using System.Text;
using System.Xml.Linq;

namespace DCAD.Dlayout;

// The single long-lived settings file. CAD supplies its authoritative DUser,
// standalone desktop requires --duser or asks once each launch. No AppData paths.
internal static class DlayoutSettingsStore
{
    private static string? directory;
    internal static string DirectoryPath => directory ?? throw new InvalidOperationException(
        "DUser has not been selected. Configure DUser before opening Dlayout.");
    internal static string FilePath => Path.Combine(DirectoryPath, "Dlayout_settings.ini");

    internal static void Configure(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new InvalidDataException("DUser path is missing.");
        string path = Path.GetFullPath(value.Trim());
        if (!string.Equals(Path.GetFileName(Path.TrimEndingDirectorySeparator(path)), "DUser", StringComparison.OrdinalIgnoreCase)
            || !Directory.Exists(path))
            throw new DirectoryNotFoundException("Dlayout requires an existing DIRECT DUser directory: " + path);
        directory = path;
    }
    internal static void ConfigureFromJob(string jobFile)
    {
        var doc = XDocument.Load(Path.GetFullPath(jobFile));
        var root = doc.Root;
        if (root?.Name != "dlayoutJob" || (string?)root.Attribute("protocol") != "2" ||
            (string?)root.Attribute("version") != "98")
            throw new InvalidDataException("Invalid CAD job before reading DUser.");
        Configure((string?)root.Attribute("duser") ?? "");
    }
    internal static Dictionary<string, string> Read()
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        string path = FilePath;
        if (!File.Exists(path)) return values;
        string group = "";
        int row = 0;
        foreach (string input in File.ReadAllLines(path, Encoding.UTF8))
        {
            row++;
            string line = input.Trim();
            if (line.Length == 0 || line.StartsWith('#') || line.StartsWith(';')) continue;
            if (line.StartsWith('[') && line.EndsWith(']'))
            { group = line[1..^1].Trim(); continue; }
            int split = line.IndexOf('=');
            if (split < 1) throw new InvalidDataException($"Dlayout_settings.ini line {row}: expected key=value.");
            string key = group + "." + line[..split].Trim();
            if (!values.TryAdd(key, line[(split + 1)..].Trim()))
                throw new InvalidDataException("Duplicate Dlayout setting: " + key);
        }
        return values;
    }
    internal static int Int(Dictionary<string, string> values, string key, int fallback, int min, int max)
    {
        if (!values.TryGetValue(key, out string? raw)) return fallback;
        if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value) || value < min || value > max)
            throw new InvalidDataException("Dlayout_settings.ini: invalid " + key + "=" + raw);
        return value;
    }
    internal static double Number(Dictionary<string, string> values, string key, double fallback, double min, double max)
    {
        if (!values.TryGetValue(key, out string? raw)) return fallback;
        if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out double value) ||
            !double.IsFinite(value) || value < min || value > max)
            throw new InvalidDataException("Dlayout_settings.ini: invalid " + key + "=" + raw);
        return value;
    }
    internal static void SaveSections(Dictionary<string, Dictionary<string, string>> updates)
    {
        using var mutex = new Mutex(false, @"Local\DCAD_Dlayout_Settings");
        bool acquired = false;
        try
        {
            try { acquired = mutex.WaitOne(TimeSpan.FromSeconds(10)); }
            catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) throw new IOException("Dlayout settings locked by another process.");
            var data = Read();
            foreach (var section in updates)
                foreach (var pair in section.Value)
                    data[section.Key + "." + pair.Key] = pair.Value;
            var output = new StringBuilder("# DCAD Dlayout settings V1\r\n");
            string? previous = null;
            foreach (var pair in data.OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase))
            {
                int dot = pair.Key.IndexOf('.');
                if (dot <= 0) throw new InvalidDataException("Invalid INI key: " + pair.Key);
                string group = pair.Key[..dot];
                if (!string.Equals(previous, group, StringComparison.OrdinalIgnoreCase))
                { output.Append("\r\n[").Append(group).Append("]\r\n"); previous = group; }
                output.Append(pair.Key[(dot + 1)..]).Append('=').Append(pair.Value).Append("\r\n");
            }
            string path = FilePath;
            string tmp = Path.Combine(DirectoryPath, ".Dlayout_settings." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                { writer.Write(output.ToString()); writer.Flush(); stream.Flush(true); }
                if (File.Exists(path)) File.Replace(tmp, path, null, true);
                else File.Move(tmp, path);
            }
            finally { if (File.Exists(tmp)) File.Delete(tmp); }
        }
        finally { if (acquired) mutex.ReleaseMutex(); }
    }
}
