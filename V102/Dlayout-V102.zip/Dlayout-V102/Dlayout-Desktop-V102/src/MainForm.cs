using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace DCAD.Dlayout;

internal sealed class MainForm : Form
{
    private string[] sourceFiles = Array.Empty<string>();
    private CadJobRequest? cadRequest;
    private Job? allContours;
    private Job? job;
    private ContourSelectionState? choices;
    private string selectionKey = "";
    private bool fillingGrid;
    private bool optimizing;
    private bool stoppedWithSolutions;
    private int generation;
    private CancellationTokenSource? cancellation;
    private OptimizationSettings? lastSettings;
    private List<Solution> leaders = new();
    private List<Solution> archiveResults = new();
    private List<Solution?> visibleSolutions = new();
    private readonly Dictionary<int, AngleOutcome> angleResults = new();
    private string? angleFile;
    private bool restoringAngleResults;
    private bool nearestSearchActive;
    private double nearestSearchTarget;

    private readonly DataGridView contours = new()
    {
        Width = 257, Height = 165, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        AllowUserToResizeRows = false, MultiSelect = false, RowHeadersVisible = false,
        ReadOnly = false, BorderStyle = BorderStyle.FixedSingle,
        BackgroundColor = Color.White, SelectionMode = DataGridViewSelectionMode.CellSelect,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
        EditMode = DataGridViewEditMode.EditOnEnter, ColumnHeadersHeight = 33,
        ScrollBars = ScrollBars.Vertical, ShowCellErrors = true
    };
    private readonly Label countLabel = new() { Width = 258, Height = 34 };
    private readonly ComboBox language = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Dictionary<Label, string> boundLabels = new();
    private Label? heading, countHelp, solutionHeading, previewHelp;
    private bool changingLanguage;
    private readonly Button openDxf = new() { Height = 35, Width = 257 };
    private readonly ComboBox level = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox objective = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox resultLimit = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox resultSortField = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox resultSortDirection = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox searchField = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox searchValue = new() { Text = "0" };
    private readonly Button searchButton = new() { Height = 29, Width = 57 };
    private readonly Button clearSearchButton = new() { Height = 29, Width = 53 };
    private readonly ComboBox resultView = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly Button openAngles = new() { Height = 33, Width = 257 };
    private readonly ToolTip savedAnglePath = new();
    private readonly TextBox customAngle = new() { Text = "5", Width = 110 };
    private Panel? customAngleRow;
    private readonly NumericUpDown gap = new() { DecimalPlaces = 3, Increment = .1m, Minimum = 0, Maximum = 100000, Width = 110 };
    private readonly NumericUpDown top = new() { DecimalPlaces = 3, Increment = .1m, Minimum = 0, Maximum = 100000, Width = 110 };
    private readonly NumericUpDown bottom = new() { DecimalPlaces = 3, Increment = .1m, Minimum = 0, Maximum = 100000, Width = 110 };
    private readonly NumericUpDown width = new() { DecimalPlaces = 2, Minimum = 0, Maximum = 1000000, Width = 110 };
    private readonly ListBox items = new() { IntegralHeight = false };
    private readonly Label status = new() { AutoSize = false, Height = 55 };
    private readonly Button run = new() { Height = 35 };
    private readonly Button stop = new() { Height = 35 };
    private readonly Button apply = new() { Height = 35 };
    private readonly ProgressBar progress = new() { Maximum = 1000 };
    // Lightweight UI-only heartbeat: long CAD contours can take time to optimize,
    // but the user must see that Calculate has actually started.
    private readonly System.Windows.Forms.Timer computeHeartbeat = new() { Interval = 1000 };
    private readonly System.Diagnostics.Stopwatch computeClock = new();
    private readonly Preview preview = new();

    public MainForm(string? source, string? cadJob = null)
    {
        // Language is initialized by Program / the CAD preload session.
        Text = "Dlayout Desktop V102";
        DcadDesktopIcon.Attach(this);
        FormClosing += (_, _) =>
        {
            if (cadRequest != null && DialogResult != DialogResult.OK)
                CadRunTrace.Write("USER_CLOSED");
        };
        TopMost = false;
        MinimumSize = new Size(1050, 690);
        Size = new Size(1270, 810);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(244, 247, 250);
        Font = new Font("Segoe UI", 9.5f);

        var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(8) };
        var left = new Panel { Dock = DockStyle.Left, Width = 300,
            BackColor = Color.FromArgb(238, 242, 247), Padding = new Padding(12), AutoScroll = true };
        Controls.Add(right);
        Controls.Add(left);
        preview.Dock = DockStyle.Fill;
        right.Controls.Add(preview);
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, WrapContents = false,
            FlowDirection = FlowDirection.TopDown, Padding = new Padding(3) };
        left.Controls.Add(flow);
        Panel Row(string label, Control control)
        {
            var line = new Panel { Height = 38, Width = 257 };
            var caption = new Label { Text = label, TextAlign = ContentAlignment.MiddleLeft,
                Left = 2, Top = 4, Height = 28, Width = 139 };
            string binding = control == language ? "DeskLanguage" :
                control == level ? "DeskQuality" : control == customAngle ? "DeskCustomAngle" :
                control == resultLimit ? "DeskResultLimit" : control == objective ? "DeskObjective" :
                control == gap ? "DeskGap" : control == top ? "DeskTop" :
                control == bottom ? "DeskBottom" : control == width ? "DeskWidth" :
                control == resultSortField ? "DeskSortLabel" :
                control == resultSortDirection ? "DeskSortDirection" :
                control == searchField ? "DeskSearchField" :
                control == resultView ? "DeskResultView" : "";
            if (binding.Length > 0) boundLabels[caption] = binding;
            if (control == resultView)
            {
                caption.Width = 94; control.Left = 100; control.Width = 154;
                if (control is ComboBox resultCombo) resultCombo.DropDownWidth = 240;
            }
            else
            {
                control.Left = 146; control.Width = 108;
                if (control is ComboBox choice) choice.DropDownWidth = 190;
            }
            control.Top = 4;
            line.Controls.Add(caption); line.Controls.Add(control); flow.Controls.Add(line);
            return line;
        }

        heading = new Label { Text = Strings.T("DeskTitle"),
            Font = new Font(Font.FontFamily, 14, FontStyle.Bold), Width = 261, Height = 42 };
        flow.Controls.Add(heading);
        language.Items.AddRange(new object[] { "English", "Tiếng Việt", "简体中文", "日本語", "한국어", "ไทย" });
        language.SelectedIndex = Strings.CurrentLanguage;
        Row(Strings.T("DeskLanguage"), language);
        language.SelectedIndexChanged += (_, _) =>
        {
            if (changingLanguage || language.SelectedIndex < 0) return;
            Strings.Load(language.SelectedIndex);
            if (cadJob == null)
            {
                try { PreferenceStore.SaveLanguage(language.SelectedIndex); }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Dlayout - DUser", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            }
            LocalizeUi();
        };
        openDxf.Text = Strings.T("DeskOpenDxf");
        openDxf.Click += (_, _) => ChooseDxf();
        flow.Controls.Add(openDxf);
        countLabel.Text = Strings.F("DeskCount", 0, 0, 0);
        flow.Controls.Add(countLabel);

        var enabledCol = new DataGridViewCheckBoxColumn
        {
            Name = "Enabled", HeaderText = Strings.T("DeskSelect"), Width = 45,
            ThreeState = false, TrueValue = true, FalseValue = false,
            SortMode = DataGridViewColumnSortMode.NotSortable
        };
        var nameCol = new DataGridViewTextBoxColumn
        {
            Name = "Contour", HeaderText = Strings.T("DeskContour"), Width = 105,
            ReadOnly = true, SortMode = DataGridViewColumnSortMode.NotSortable
        };
        var factorCol = new DataGridViewTextBoxColumn
        {
            Name = "Factor", HeaderText = Strings.T("DeskFactor"), Width = 76,
            ValueType = typeof(int), SortMode = DataGridViewColumnSortMode.NotSortable
        };
        factorCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        enabledCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        contours.Columns.AddRange(enabledCol, nameCol, factorCol);
        contours.ColumnHeadersDefaultCellStyle.Font = new Font(Font, FontStyle.Bold);
        contours.CurrentCellDirtyStateChanged += (_, _) =>
        {
            if (!fillingGrid && contours.IsCurrentCellDirty && contours.CurrentCell?.ColumnIndex == 0)
                contours.CommitEdit(DataGridViewDataErrorContexts.Commit);
        };
        contours.CellValidating += (_, e) =>
        {
            if (fillingGrid || e.ColumnIndex != 2 || e.RowIndex < 0) return;
            if (!int.TryParse(Convert.ToString(e.FormattedValue), out int factor) ||
                factor < 1 || factor > StepSchedule.MaxPerStep)
            {
                e.Cancel = true;
                contours.Rows[e.RowIndex].ErrorText = Strings.T("DeskFactorInvalid");
            }
            else contours.Rows[e.RowIndex].ErrorText = "";
        };
        contours.CellValueChanged += (_, e) =>
        {
            if (fillingGrid || optimizing || choices == null || e.RowIndex < 0 ||
                e.RowIndex >= choices.TypeCount || (e.ColumnIndex != 0 && e.ColumnIndex != 2)) return;
            try
            {
                var row = contours.Rows[e.RowIndex];
                bool enabled = Convert.ToBoolean(row.Cells[0].Value ?? false);
                int factor = Convert.ToInt32(row.Cells[2].Value ?? 1);
                choices.Set(e.RowIndex, enabled, factor);
                // Session-only DXF choices; do not persist an extra XML file.
                ResetSolutions();
            }
            catch (Exception ex)
            {
                status.Text = Strings.T("DeskFactorChangeError") + ": " + ex.Message;
            }
        };
        contours.DataError += (_, e) =>
        {
            e.ThrowException = false;
            CadRunTrace.Write("INPUT_INVALID: factor/grid");
            status.Text = Strings.T("DeskFactorInvalid");
        };
        flow.Controls.Add(contours);
        countHelp = new Label { Width = 258, Height = 47,
            ForeColor = Color.FromArgb(58, 75, 98) };
        flow.Controls.Add(countHelp);

        level.Items.AddRange([Strings.T("DeskFast"), Strings.T("DeskBalanced"), Strings.T("DeskDeep"),
            Strings.T("DeskVeryDeep"), Strings.T("DeskMaximum"), Strings.T("DeskCustom")]);
        level.SelectedIndex = 1;
        objective.Items.AddRange([Strings.T("DeskMinPitch"), Strings.T("DeskMinArea")]);
        objective.SelectedIndex = 1;
        resultLimit.Items.AddRange(["10", "25", "50", "100", "200", "500"]);
        resultLimit.SelectedIndex = 2;
        resultSortField.Items.AddRange([Strings.T("DeskMetricAngle"), Strings.T("DeskMetricEfficiency"),
            Strings.T("DeskMetricPitch"), Strings.T("DeskMetricHeight")]);
        resultSortField.SelectedIndex = (int)ResultMetric.Efficiency;
        resultSortDirection.Items.AddRange([Strings.T("DeskDirectionAsc"), Strings.T("DeskDirectionDesc")]);
        resultSortDirection.SelectedIndex = (int)ResultDirection.Descending;
        searchField.Items.AddRange([Strings.T("DeskMetricAngle"), Strings.T("DeskMetricEfficiency"),
            Strings.T("DeskMetricPitch"), Strings.T("DeskMetricHeight")]);
        searchField.SelectedIndex = (int)ResultMetric.Efficiency;
        Row(Strings.T("DeskQuality"), level);
        customAngleRow = Row(Strings.T("DeskCustomAngle"), customAngle);
        Row(Strings.T("DeskResultLimit"), resultLimit);
        Row(Strings.T("DeskObjective"), objective);
        Row(Strings.T("DeskGap"), gap); Row(Strings.T("DeskTop"), top);
        Row(Strings.T("DeskBottom"), bottom); Row(Strings.T("DeskWidth"), width);

        var prefs = PreferenceStore.Load();
        level.SelectedIndex = prefs.Quality;
        objective.SelectedIndex = prefs.Objective;
        width.Value = prefs.MaxWidth;
        int resultIndex = resultLimit.Items.IndexOf(prefs.ResultLimit.ToString(CultureInfo.InvariantCulture));
        resultLimit.SelectedIndex = resultIndex >= 0 ? resultIndex : 2;
        resultSortField.SelectedIndex = prefs.ResultSortField;
        resultSortDirection.SelectedIndex = prefs.ResultSortDirection;
        customAngle.Text = prefs.CustomAngleStep.ToString("G", CultureInfo.CurrentCulture);
        customAngleRow.Visible = level.SelectedIndex == 5;

        run.Text = Strings.T("DeskOptimize"); run.Width = 257;
        computeHeartbeat.Tick += (_, _) =>
        {
            if (optimizing && !IsDisposed)
                run.Text = Strings.T("DeskOptimizing") +
                    " (" + ((int)computeClock.Elapsed.TotalSeconds).ToString(CultureInfo.InvariantCulture) + "s)";
        };
        run.Click += (_, _) => StartSearch(); flow.Controls.Add(run);
        stop.Text = Strings.T("DeskCancel"); stop.Width = 257; stop.Enabled = false;
        stop.Click += (_, _) =>
        {
            if (cancellation != null && !cancellation.IsCancellationRequested)
            {
                stop.Enabled = false;
                status.Text = Strings.T("DeskStopping");
                cancellation.Cancel();
            }
        }; flow.Controls.Add(stop);
        progress.Width = 257; progress.Height = 14; flow.Controls.Add(progress);
        status.Width = 258; status.Text = Strings.T("DeskReady"); flow.Controls.Add(status);
        solutionHeading = new Label { Text = Strings.T("DeskSolutions"),
            Font = new Font(Font, FontStyle.Bold), Height = 25, Width = 260 };
        flow.Controls.Add(solutionHeading);
        resultView.Items.AddRange([Strings.T("DeskGlobalResults"), Strings.T("DeskPerAngleResults")]);
        resultView.SelectedIndex = 0;
        Row(Strings.T("DeskResultView"), resultView);
        resultView.SelectedIndexChanged += (_, _) => RefreshResults(true);
        Row(Strings.T("DeskSortLabel"), resultSortField);
        Row(Strings.T("DeskSortDirection"), resultSortDirection);
        Row(Strings.T("DeskSearchField"), searchField);
        var searchTargetRow = new Panel { Height = 38, Width = 257 };
        var searchTargetLabel = new Label { Text = Strings.T("DeskSearchTarget"),
            TextAlign = ContentAlignment.MiddleLeft, Left = 2, Top = 4, Height = 28, Width = 64 };
        boundLabels[searchTargetLabel] = "DeskSearchTarget";
        searchValue.SetBounds(68, 4, 68, 28);
        searchButton.SetBounds(140, 4, 57, 29);
        clearSearchButton.SetBounds(201, 4, 53, 29);
        searchTargetRow.Controls.Add(searchTargetLabel);
        searchTargetRow.Controls.Add(searchValue);
        searchTargetRow.Controls.Add(searchButton);
        searchTargetRow.Controls.Add(clearSearchButton);
        flow.Controls.Add(searchTargetRow);
        searchButton.Text = Strings.T("DeskFindNearest");
        clearSearchButton.Text = Strings.T("DeskClearSearch");
        searchButton.Click += (_, _) => ApplyNearestSearch();
        clearSearchButton.Click += (_, _) => ClearNearestSearch();
        searchValue.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; ApplyNearestSearch(); }
        };
        openAngles.Text = Strings.T("DeskOpenAngleResults");
        openAngles.Click += (_, _) => OpenSavedAngleResults();
        flow.Controls.Add(openAngles);
        items.Width = 257; items.Height = 165;
        items.SelectedIndexChanged += (_, _) =>
        {
            // While optimization is running, the preview is owned by the
            // live angular search. Rebuilding the results list must not
            // replace the active angle's geometry with the global Top-N pick.
            if (optimizing) return;
            Solution? selected = SelectedSolution;
            if (selected != null)
                preview.ShowSolution(selected, 2, (double)top.Value, (double)bottom.Value);
            else if (items.SelectedIndex >= 0)
                preview.ShowArrangement(new List<ShapePlace>(), 0, (double)top.Value, (double)bottom.Value);
            apply.Enabled = !optimizing && selected != null && lastSettings != null;
        };
        flow.Controls.Add(items);
        apply.Text = Strings.T(cadJob == null ? "DeskExport" : "DeskApplyCad"); apply.Width = 257; apply.Enabled = false;
        apply.Click += (_, _) => Apply(); flow.Controls.Add(apply);
        previewHelp = new Label { Width = 258, Height = 96,
            ForeColor = Color.FromArgb(75, 86, 99) };
        flow.Controls.Add(previewHelp);
        level.SelectedIndexChanged += (_, _) =>
        {
            if (customAngleRow != null) customAngleRow.Visible = level.SelectedIndex == 5;
            if (!changingLanguage) ResetSolutions();
        };
        customAngle.TextChanged += (_, _) =>
        {
            if (level.SelectedIndex == 5) ResetSolutions();
        };
        resultLimit.SelectedIndexChanged += (_, _) => ResetSolutions();
        resultSortField.SelectedIndexChanged += (_, _) =>
        {
            if (!changingLanguage && !nearestSearchActive) RefreshResults(true);
        };
        resultSortDirection.SelectedIndexChanged += (_, _) =>
        {
            if (!changingLanguage && !nearestSearchActive) RefreshResults(true);
        };
        searchField.SelectedIndexChanged += (_, _) =>
        {
            if (!changingLanguage && nearestSearchActive) RefreshResults(true);
        };
        objective.SelectedIndexChanged += (_, _) => { if (!changingLanguage) ResetSolutions(); };
        foreach (var field in new[] { gap, top, bottom, width })
            field.ValueChanged += (_, _) => ResetSolutions();
        apply.Tag = cadJob == null ? "standalone" : "cad";
        UpdateSearchControls();
        LocalizeUi();
        FormClosing += (_, _) => cancellation?.Cancel();
        FormClosed += (_, _) => { computeHeartbeat.Stop(); computeClock.Stop(); };
        if (!string.IsNullOrWhiteSpace(cadJob))
        {
            openDxf.Enabled = false;
            Shown += (_, _) => LoadCadJob(cadJob);
        }
        else if (!string.IsNullOrWhiteSpace(source)) Shown += (_, _) => LoadDxf([source]);
    }

    private void LocalizeUi()
    {
        Text = "Dlayout V102 — " + Strings.T("DeskTitle");
        if (heading != null) heading.Text = Strings.T("DeskTitle");
        foreach (var pair in boundLabels) pair.Key.Text = Strings.T(pair.Value);
        openDxf.Text = Strings.T("DeskOpenDxf");
        run.Text = Strings.T("DeskOptimize");
        stop.Text = Strings.T("DeskCancel");
        apply.Text = Strings.T(cadRequest == null && apply.Tag as string != "cad" ?
            "DeskExport" : "DeskApplyCad");
        if (countHelp != null) countHelp.Text = Strings.T("DeskFactorHelp");
        if (solutionHeading != null) solutionHeading.Text = Strings.T("DeskSolutions");
        openAngles.Text = Strings.T("DeskOpenAngleResults");
        searchButton.Text = Strings.T("DeskFindNearest");
        clearSearchButton.Text = Strings.T("DeskClearSearch");
        if (previewHelp != null) previewHelp.Text = Strings.T(cadRequest == null &&
            apply.Tag as string != "cad" ? "DeskPreviewDxf" : "DeskPreviewCad");
        if (contours.Columns.Count >= 3)
        {
            contours.Columns[0].HeaderText = Strings.T("DeskSelect");
            contours.Columns[1].HeaderText = Strings.T("DeskContour");
            contours.Columns[2].HeaderText = Strings.T("DeskFactor");
        }
        changingLanguage = true;
        try
        {
        UpdateComboText(level, ["DeskFast", "DeskBalanced", "DeskDeep", "DeskVeryDeep", "DeskMaximum", "DeskCustom"]);
        UpdateComboText(objective, ["DeskMinPitch", "DeskMinArea"]);
        UpdateComboText(resultSortField, ["DeskMetricAngle", "DeskMetricEfficiency", "DeskMetricPitch", "DeskMetricHeight"]);
        UpdateComboText(resultSortDirection, ["DeskDirectionAsc", "DeskDirectionDesc"]);
        UpdateComboText(searchField, ["DeskMetricAngle", "DeskMetricEfficiency", "DeskMetricPitch", "DeskMetricHeight"]);
        UpdateComboText(resultView, ["DeskGlobalResults", "DeskPerAngleResults"]);
        }
        finally { changingLanguage = false; }
        if (allContours == null || choices == null) countLabel.Text = Strings.F("DeskCount", 0, 0, 0);
        else countLabel.Text = Strings.F("DeskCount", choices.SelectedTypes, choices.TypeCount, choices.PartsPerPitch);
        if (!optimizing)
        {
            if (stoppedWithSolutions && leaders.Count > 0)
                status.Text = Strings.F("DeskStoppedWithSolutions", leaders.Count);
            else if (leaders.Count > 0 && job != null)
            {
                int bestIndex = ResultOrdering.BestIndex(archiveResults);
                Solution best = bestIndex >= 0 ? archiveResults[bestIndex] : leaders[0];
                status.Text = Strings.F("DeskFinishedDetails", best.Pitch, job.Shapes.Count);
            }
            else if (job != null)
                status.Text = Strings.T(cadRequest == null ? "DeskOpened" : "DeskCadReady");
            else status.Text = Strings.T("DeskReady");
        }
    }

    private static void UpdateComboText(ComboBox combo, string[] keys)
    {
        int selection = combo.SelectedIndex;
        for (int i = 0; i < keys.Length && i < combo.Items.Count; i++)
            combo.Items[i] = Strings.T(keys[i]);
        if (combo.SelectedIndex != selection && selection >= 0) combo.SelectedIndex = selection;
    }

    private void ChooseDxf()
    {
        if (optimizing) { MessageBox.Show(Strings.T("DeskStopFirst"), Text); return; }
        using var picker = new OpenFileDialog { Filter = "AutoCAD DXF (*.dxf)|*.dxf",
            Multiselect = true, Title = Strings.T("DeskDxfPicker") };
        if (picker.ShowDialog(this) == DialogResult.OK) LoadDxf(picker.FileNames);
    }

    private void LoadDxf(string[] paths)
    {
        if (optimizing) return;
        try
        {
            // All potentially failing steps are done before replacing the UI model.
            string[] resolved = paths.Select(Path.GetFullPath).ToArray();
            var loaded = Job.LoadDxfFiles(resolved);
            // DXF choices live only in this editing session; do not hash and
            // persist a per-file profile outside DUser.
            BindLoadedJob(loaded, new ContourSelectionState(loaded.Shapes.Count), resolved, "");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, Strings.T("DeskImportError"), MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadCadJob(string path)
    {
        try
        {
            CadRunTrace.Write("LOAD_JOB");
            CadJobRequest req = CadJobBridge.Load(path);
            cadRequest = req;
            BindLoadedJob(req.Input, new ContourSelectionState(req.Input.Shapes.Count),
                Array.Empty<string>(), "");
            status.Text = Strings.T("DeskCadReady");
            CadRunTrace.Write("JOB_VALIDATED shapes=" + req.Input.Shapes.Count);
        }
        catch (Exception ex)
        {
            CadRunTrace.Write("ERROR: LOAD_JOB " + ex);
            cadRequest = null;
            MessageBox.Show(ex.Message, Strings.T("DeskCadJobError"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            Close();
        }
    }

    private void BindLoadedJob(Job loaded, ContourSelectionState selection, string[] resolved, string fingerprint)
    {
            fillingGrid = true;
            try
            {
                contours.Rows.Clear();
                for (int index = 0; index < loaded.Shapes.Count; index++)
                    contours.Rows.Add(selection[index].Enabled,
                        $"{(char)('A' + index)} · {loaded.Shapes[index].Handle}", selection[index].Factor);
                contours.ClearSelection();
                contours.CurrentCell = null;
            }
            finally { fillingGrid = false; }

            sourceFiles = resolved;
            allContours = loaded;
            choices = selection;
            selectionKey = fingerprint;
            job = null;
            gap.Value = Math.Clamp((decimal)loaded.Gap, gap.Minimum, gap.Maximum);
            top.Value = Math.Clamp((decimal)loaded.Top, top.Minimum, top.Maximum);
            bottom.Value = Math.Clamp((decimal)loaded.Bottom, bottom.Minimum, bottom.Maximum);
            ResetSolutions();
            status.Text = resolved.Length == 0 ? Strings.T("DeskCadReceived") :
                Strings.T("DeskOpened") + ": " + string.Join(", ", resolved.Select(Path.GetFileName));
    }

    private (bool[] Enabled, int[] Factor) ReadSelection()
    {
        if (choices == null) return (Array.Empty<bool>(), Array.Empty<int>());
        // The grid is ONLY a view. The canonical model contains one row per
        // DXF outer silhouette and is never replaced with expanded copies.
        return choices.Snapshot();
    }

    private void ResetSolutions()
    {
        if (optimizing) return;
        if (restoringAngleResults) return;
        leaders.Clear();
        archiveResults.Clear();
        angleResults.Clear();
        angleFile = null;
        visibleSolutions.Clear();
        items.Items.Clear();
        apply.Enabled = false;
        stoppedWithSolutions = false;
        progress.Value = 0;
        lastSettings = null;
        if (allContours == null || choices == null)
        {
            countLabel.Text = Strings.F("DeskCount", 0, 0, 0);
            preview.ShowArrangement(new List<ShapePlace>(), 0, (double)top.Value, (double)bottom.Value);
            return;
        }
        countLabel.Text = Strings.F("DeskCount", choices.SelectedTypes, choices.TypeCount, choices.PartsPerPitch);
        var source = allContours.Shapes.Where((_, index) => choices[index].Enabled).ToList();
        if (source.Count == 0)
        {
            preview.ShowArrangement(new List<ShapePlace>(), 0, (double)top.Value, (double)bottom.Value);
            status.Text = Strings.T("DeskSelectOne");
            return;
        }
        Pt anchor = source[0].OriginalCenter;
        preview.ShowArrangement(source.Select(x => x.At(x.OriginalCenter - anchor, 0)).ToList(),
            0, (double)top.Value, (double)bottom.Value);
    }

    private Solution? SelectedSolution => items.SelectedIndex >= 0 &&
        items.SelectedIndex < visibleSolutions.Count ? visibleSolutions[items.SelectedIndex] : null;

    private void DisplayLeaders(IReadOnlyList<Solution> incoming, bool preserveSelection, bool forceBest = false)
    {
        archiveResults = incoming.ToList();
        RefreshResults(preserveSelection, forceBest);
    }

    // The two views are independent: top-N global leaders and ONE best per
    // tested angle. Even unsuccessful angles remain visible in the latter.
    private void RefreshResults(bool preserveSelection, bool forceBest = false)
    {
        Solution? selected = preserveSelection ? SelectedSolution : null;
        int metric = nearestSearchActive ? searchField.SelectedIndex : resultSortField.SelectedIndex;
        leaders = nearestSearchActive
            ? ResultOrdering.OrderNearest(archiveResults, metric, nearestSearchTarget)
            : ResultOrdering.Order(archiveResults, metric, resultSortDirection.SelectedIndex);
        var view = new List<(Solution? Value, string Text)>();
        if (resultView.SelectedIndex == 1)
        {
            IEnumerable<AngleOutcome> angles = nearestSearchActive
                ? ResultOrdering.OrderAnglesNearest(angleResults.Values, metric, nearestSearchTarget)
                : ResultOrdering.OrderAngles(angleResults.Values, metric, resultSortDirection.SelectedIndex);
            foreach (AngleOutcome a in angles)
            {
                string angleText = $"φ={a.Angle:0.######}°";
                string note = a.Complete ? Strings.T("DeskAngleNoSolution") : Strings.T("DeskAnglePartial");
                view.Add((a.Best, a.Best == null ? angleText + "  " + note :
                    $"{angleText}  P={a.Best.Pitch:0.###}  W={a.Best.StripWidth:0.###}  {a.Best.Efficiency:0.#}%" +
                    (a.Complete ? "" : "  " + note)));
            }
        }
        else
        {
            foreach (Solution item in leaders)
                view.Add((item, $"P={item.Pitch:0.###}  W={item.StripWidth:0.###}  {item.Efficiency:0.#}%  φ={item.RelativeAngle:0.###}°"));
        }
        items.BeginUpdate();
        try
        {
            items.Items.Clear();
            visibleSolutions = view.Select(x => x.Value).ToList();
            foreach (var x in view) items.Items.Add(x.Text);
        }
        finally { items.EndUpdate(); }
        int index = selected == null || forceBest ? -1 :
            visibleSolutions.FindIndex(x => ReferenceEquals(x, selected));
        if (index < 0 && view.Count > 0)
        {
            double bestScore = double.PositiveInfinity;
            for (int i = 0; i < visibleSolutions.Count; i++)
                if (visibleSolutions[i] != null && visibleSolutions[i]!.Score < bestScore)
                { bestScore = visibleSolutions[i]!.Score; index = i; }
        }
        items.SelectedIndex = index;
        apply.Enabled = !optimizing && SelectedSolution != null && lastSettings != null;
    }

    private static bool TryParseSearchValue(string raw, out double value)
    {
        return (double.TryParse(raw, NumberStyles.Float, CultureInfo.CurrentCulture, out value) ||
            double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) &&
            double.IsFinite(value);
    }

    private void ApplyNearestSearch()
    {
        if (searchField.SelectedIndex < 0) return;
        if (!TryParseSearchValue(searchValue.Text, out double target))
        {
            MessageBox.Show(this, Strings.T("DeskSearchInvalid"), Text,
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            searchValue.Focus(); searchValue.SelectAll();
            return;
        }
        nearestSearchTarget = target;
        nearestSearchActive = true;
        UpdateSearchControls();
        RefreshResults(false);
        if (items.Items.Count > 0)
        {
            items.SelectedIndex = -1;
            items.SelectedIndex = 0;
        }
    }

    private void ClearNearestSearch()
    {
        nearestSearchActive = false;
        UpdateSearchControls();
        RefreshResults(true);
    }

    private void UpdateSearchControls()
    {
        resultSortField.Enabled = !nearestSearchActive;
        resultSortDirection.Enabled = !nearestSearchActive;
        clearSearchButton.Enabled = nearestSearchActive;
    }

    private void OpenSavedAngleResults()
    {
        if (optimizing) return;
        if (allContours == null)
        {
            MessageBox.Show(this, Strings.T("DeskSelectOne"), Text,
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        try
        {
            var input = ReadSelection();
            Job candidate = StepSchedule.Expand(allContours, input.Enabled, input.Factor,
                (double)gap.Value, (double)top.Value, (double)bottom.Value);
            double custom = 5;
            if (level.SelectedIndex == 5 && !TryParseCustomAngle(customAngle.Text, out custom))
                throw new InvalidDataException(Strings.T("DeskAngleInvalid"));
            OptimizationSettings settings = CurrentOptimizationSettings(custom);
            using var dialog = new OpenFileDialog
            {
                Filter = "Dlayout per-angle results (*.jsonl)|*.jsonl",
                InitialDirectory = Path.Combine(DlayoutSettingsStore.DirectoryPath, "Dlayout_results"),
                CheckFileExists = true
            };
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            var loaded = AngleResultJournal.Load(dialog.FileName, candidate, settings);
            restoringAngleResults = true;
            try
            {
                job = candidate;
                lastSettings = settings;
                angleResults.Clear();
                foreach (var item in loaded) angleResults[item.Index] = item;
                angleFile = dialog.FileName;
                // Saved angle winners may exceed 500. Global view remains
                // a bounded summary, not a replacement for per-angle storage.
                archiveResults = loaded.Where(x => x.Best != null).Select(x => x.Best!)
                    .OrderBy(x => x.Score).Take(settings.ResultLimit).ToList();
                resultView.SelectedIndex = 1;
            }
            finally { restoringAngleResults = false; }
            RefreshResults(false);
            status.Text = Strings.F("DeskAngleLoaded", angleResults.Count);
            savedAnglePath.SetToolTip(openAngles, angleFile);
            CadRunTrace.Write("ANGLES_RESTORED path=" + angleFile + " count=" + angleResults.Count);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, Strings.T("DeskAngleMismatch") + "\n" + ex.Message,
                Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private OptimizationSettings CurrentOptimizationSettings(double stepAngle) => new()
    {
        Level = level.SelectedIndex, CustomAngleStep = stepAngle,
        ResultLimit = int.Parse((string)resultLimit.SelectedItem!, CultureInfo.InvariantCulture),
        Copies = 2, Gap = (double)gap.Value, Top = (double)top.Value,
        Bottom = (double)bottom.Value, MaxWidth = (double)width.Value,
        ByMaterialArea = objective.SelectedIndex == 1
    };

    internal static bool TryParseCustomAngle(string text, out double angle)
    {
        bool parsed = double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out angle)
            || double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out angle);
        return parsed && double.IsFinite(angle) && angle > 0 && angle < 90;
    }

    private async void StartSearch()
    {
        CadRunTrace.Write("CALCULATE_CLICK");
        if (optimizing) return;
        if (allContours == null) { CadRunTrace.Write("INPUT_INVALID: no shapes"); ChooseDxf(); return; }
        if (!contours.EndEdit() || !ValidateChildren())
        {
            status.Text = Strings.T("DeskFactorInvalid");
            MessageBox.Show(this, Strings.T("DeskFactorInvalid"),
                Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        var selection = ReadSelection();
        Job target;
        try
        {
            target = StepSchedule.Expand(allContours, selection.Enabled, selection.Factor,
                (double)gap.Value, (double)top.Value, (double)bottom.Value);
        }
        catch (Exception ex)
        {
            CadRunTrace.Write("INPUT_INVALID: " + ex);
            MessageBox.Show(this, ex.Message, Strings.T("DeskFactor"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        job = target;
        double stepAngle = 5;
        if (level.SelectedIndex == 5 && !TryParseCustomAngle(customAngle.Text, out stepAngle))
        {
            MessageBox.Show(this, Strings.T("DeskAngleInvalid"),
                "Dlayout - Custom angle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            customAngle.Focus(); return;
        }
        // Very small legal angles can take hours/days. Warn, do not silently clamp.
        int sweepCount;
        try { sweepCount = Optimizer.AngleCount(level.SelectedIndex, stepAngle); }
        catch (OverflowException)
        {
            MessageBox.Show(this, Strings.T("DeskAngleOverflow"), Text);
            return;
        }
        if (sweepCount > 10000 && MessageBox.Show(this, Strings.F("DeskLargeSweep", sweepCount),
            "Dlayout - Large sweep", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            return;
        var opt = CurrentOptimizationSettings(stepAngle);
        lastSettings = opt;
        stoppedWithSolutions = false;
        try { PreferenceStore.Save(opt, resultSortField.SelectedIndex, resultSortDirection.SelectedIndex); }
        catch (Exception ex)
        {
            CadRunTrace.Write("ERROR: SAVE_SETTINGS " + ex);
            MessageBox.Show(this, "Cannot save DUser\\Dlayout_settings.ini: " + ex.Message,
                "Dlayout - Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        AngleResultJournal journal;
        try { journal = AngleResultJournal.Begin(DlayoutSettingsStore.DirectoryPath, target, opt); }
        catch (Exception ex)
        {
            CadRunTrace.Write("ERROR: ANGLE_JOURNAL_CREATE " + ex);
            MessageBox.Show(this, ex.Message, Strings.T("DeskAngleSaveError"),
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        angleFile = journal.PathName;
        savedAnglePath.SetToolTip(openAngles, angleFile);
        CadRunTrace.Write("ANGLE_RESULTS_FILE " + angleFile);
        angleResults.Clear();
        int request = ++generation;
        var workerAngles = new System.Collections.Concurrent.ConcurrentDictionary<int, AngleOutcome>();
        var angleUpdates = new Progress<AngleOutcome>(a =>
        {
            if (IsDisposed || request != generation) return;
            angleResults[a.Index] = a;
            if (resultView.SelectedIndex == 1) RefreshResults(true);
        });
        // Created before the worker starts, so the file is never silently
        // absent even if an angle produces NO_SOLUTION.
        var cts = new CancellationTokenSource();
        cancellation = cts;
        optimizing = true;
        computeClock.Restart(); computeHeartbeat.Start();
        CadRunTrace.Write("OPTIMIZER_START quality=" + opt.Level + " parts=" + target.Shapes.Count +
            " gap=" + opt.Gap + " top=" + opt.Top + " bottom=" + opt.Bottom +
            " width=" + opt.MaxWidth + " limit=" + opt.ResultLimit);
        run.Enabled = false; run.Text = Strings.T("DeskOptimizing");
        stop.Enabled = true; openDxf.Enabled = false;
        contours.Enabled = false; apply.Enabled = false;
        level.Enabled = false; objective.Enabled = false;
        customAngle.Enabled = false; resultLimit.Enabled = false;
        gap.Enabled = false; top.Enabled = false; bottom.Enabled = false; width.Enabled = false;
        leaders.Clear(); archiveResults.Clear(); visibleSolutions.Clear();
        items.Items.Clear(); progress.Value = 0;
        preview.BeginLiveSearch((double)top.Value, (double)bottom.Value);
        resultView.Enabled = true; openAngles.Enabled = false;
        status.Text = Strings.T("DeskOptimizing");

        // Last reported archive is owned by this run, not by the UI queue. In
        // particular it is used on completion even when Post() callbacks arrive
        // AFTER Task.Run has finished on the UI synchronization context.
        OptimizeProgress? latest = null;
        var updates = new Progress<OptimizeProgress>(p =>
        {
            if (IsDisposed || !optimizing || request != generation) return;
            progress.Value = Math.Clamp(p.Done * 1000 / Math.Max(1, p.Total), 0, 1000);
            Solution? statusBest = p.UpdateAnglePreview ? p.CurrentAngleBest :
                (p.CurrentAngleBest ?? p.Best);
            string statusDetail = statusBest != null
                ? $"P={statusBest.Pitch:0.###}   W={statusBest.StripWidth:0.###}   η={statusBest.Efficiency:0.##}%"
                : p.CurrentAngleCompleted ? Strings.T("DeskAngleNoSolution") : Strings.T("DeskSearching");
            status.Text = $"{Strings.T("DeskAngle")}: {p.Angle:0.######}°   {p.Done}/{p.Total}\n" + statusDetail;
            if (p.UpdateAnglePreview)
            {
                if (p.CurrentAngleBest != null)
                    preview.ShowLiveSolution(p.CurrentAngleBest, 2, (double)top.Value, (double)bottom.Value);
                else
                {
                    string detail = p.CurrentAngleCompleted
                        ? Strings.T("DeskAngleNoSolution") : Strings.T("DeskSearching");
                    preview.ShowLiveMessage($"{Strings.T("DeskAngle")}: {p.Angle:0.######}°\n{detail}",
                        (double)top.Value, (double)bottom.Value);
                }
            }
            if (p.Leaders.Count > 0) DisplayLeaders(p.Leaders, true);
        });
        try
        {
            var found = await Task.Run(() => Optimizer.Run(target, opt, cts.Token,
                p => { latest = p; ((IProgress<OptimizeProgress>)updates).Report(p); },
                a =>
                {
                    journal.Append(a);  // Persist each completed angle BEFORE next angle.
                    workerAngles[a.Index] = a;
                    ((IProgress<AngleOutcome>)angleUpdates).Report(a);
                }), cts.Token);
            journal.Finish("COMPLETED");
            if (request != generation || IsDisposed) return;
            foreach (var a in workerAngles) angleResults[a.Key] = a.Value;
            if (latest != null && latest.Leaders.Count > 0)
                DisplayLeaders(latest.Leaders, false, forceBest: true);
            else if (found != null) DisplayLeaders(new[] { found }, false, forceBest: true);
            RefreshResults(false, forceBest: true);
            progress.Value = 1000;
            if (found == null)
            {
                CadRunTrace.Write("NO_SOLUTION elapsedMs=" + computeClock.ElapsedMilliseconds);
                status.Text = Strings.T("DeskNoSolution");
            }
            else
            {
                CadRunTrace.Write("OPTIMIZER_DONE elapsedMs=" + computeClock.ElapsedMilliseconds +
                    " solutions=" + leaders.Count);
                status.Text = Strings.F("DeskFinishedDetails", found.Pitch, target.Shapes.Count) +
                    "\n" + Strings.F("DeskAngleSaved", angleResults.Count);
                apply.Enabled = SelectedSolution != null;
            }
        }
        catch (OperationCanceledException)
        {
            try { journal.Finish("CANCELLED"); }
            catch (Exception saveEx) { CadRunTrace.Write("ERROR: ANGLE_JOURNAL " + saveEx); }
            CadRunTrace.Write("OPTIMIZER_CANCELLED");
            foreach (var a in workerAngles) angleResults[a.Key] = a.Value;
            if (!IsDisposed && request == generation)
            {
                // Solver publishes the final valid archive when cancellation is
                // observed; do not lose it just because UI progress is asynchronous.
                if (latest != null && latest.Leaders.Count > 0)
                    DisplayLeaders(latest.Leaders, false, forceBest: true);
                RefreshResults(false, forceBest: true);
                if (SelectedSolution != null)
                {
                    stoppedWithSolutions = true;
                    apply.Enabled = true;
                    status.Text = Strings.F("DeskStoppedWithSolutions", visibleSolutions.Count(x => x != null));
                }
                else status.Text = Strings.T("DeskCancelledNoSolution");
            }
        }
        catch (Exception ex)
        {
            try { journal.Finish("FAILED"); }
            catch (Exception saveEx) { CadRunTrace.Write("ERROR: ANGLE_JOURNAL " + saveEx); }
            foreach (var a in workerAngles) angleResults[a.Key] = a.Value;
            RefreshResults(false);
            CadRunTrace.Write("ERROR: OPTIMIZER " + ex);
            if (!IsDisposed && request == generation)
            {
                status.Text = Strings.T("DeskError") + ": " + ex.Message;
                MessageBox.Show(this, ex.Message, Strings.T("DeskError"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        finally
        {
            computeHeartbeat.Stop(); computeClock.Stop();
            if (request == generation)
            {
                generation++; // Discard delayed progress from this run, forever.
                optimizing = false;
                if (!IsDisposed)
                {
                    RestorePreviewAfterSearch();
                    run.Enabled = true; run.Text = Strings.T("DeskOptimize");
                    stop.Enabled = false; openDxf.Enabled = cadRequest == null;
                    openAngles.Enabled = true;
                    contours.Enabled = true;
                    level.Enabled = true; objective.Enabled = true;
                    customAngle.Enabled = true; resultLimit.Enabled = true;
                    gap.Enabled = true; top.Enabled = true; bottom.Enabled = true; width.Enabled = true;
                }
            }
            if (ReferenceEquals(cancellation, cts)) cancellation = null;
            cts.Dispose();
        }
    }

    private void RestorePreviewAfterSearch()
    {
        Solution? selected = SelectedSolution;
        if (selected != null)
        {
            preview.ShowSolution(selected, 2, (double)top.Value, (double)bottom.Value);
            return;
        }
        if (job != null && job.Shapes.Count > 0)
        {
            Pt anchor = job.Shapes[0].OriginalCenter;
            preview.ShowArrangement(job.Shapes.Select(x => x.At(x.OriginalCenter - anchor, 0)).ToList(),
                0, (double)top.Value, (double)bottom.Value);
            return;
        }
        preview.ShowArrangement(new List<ShapePlace>(), 0, (double)top.Value, (double)bottom.Value);
    }

    private bool SelectionStillMatchesSolution()
    {
        if (allContours == null || job == null) return false;
        try
        {
            var input = ReadSelection();
            var test = StepSchedule.Expand(allContours, input.Enabled, input.Factor,
                (double)gap.Value, (double)top.Value, (double)bottom.Value);
            return test.Shapes.Select(s => s.Handle).SequenceEqual(job.Shapes.Select(s => s.Handle));
        }
        catch { return false; }
    }

    private void Apply()
    {
        if (optimizing) { MessageBox.Show(Strings.T("DeskStopFirst"), Text); return; }
        if (job == null || SelectedSolution == null)
        { MessageBox.Show(Strings.T("DeskSelectSolution"), Text); return; }
        if (lastSettings == null || lastSettings.Level != level.SelectedIndex ||
            (lastSettings.Level == 5 &&
             (!TryParseCustomAngle(customAngle.Text, out double currentAngle) ||
              lastSettings.CustomAngleStep != currentAngle)) ||
            lastSettings.Gap != (double)gap.Value || lastSettings.Top != (double)top.Value ||
            lastSettings.Bottom != (double)bottom.Value || lastSettings.MaxWidth != (double)width.Value ||
            lastSettings.ByMaterialArea != (objective.SelectedIndex == 1) || !SelectionStillMatchesSolution())
        { MessageBox.Show(Strings.T("DeskReoptimize"), Text); return; }
        var solution = SelectedSolution!;
        if (!Geometry.ValidPeriod(solution.Places, (double)gap.Value, solution.Pitch) ||
            ((double)width.Value > 0 && solution.StripWidth > (double)width.Value + 1e-6))
        { MessageBox.Show(Strings.T("DeskInvalidClearance"), Text); return; }
        if (cadRequest != null)
        {
            try
            {
                CadRunTrace.Write("SAVE_RESULT_BEGIN");
                // In per-angle view the CAD picker receives EVERY winning angle
                // when <=500. Above that protocol-2 limit, the selected winner
                // is transferred while the full set remains in DUser.
                List<Solution> transfer = resultView.SelectedIndex == 1
                    ? angleResults.Values.OrderBy(x => x.Index)
                        .Where(x => x.Best != null).Select(x => x.Best!).ToList()
                    : archiveResults.ToList();
                if (transfer.Count > 500) transfer = new List<Solution> { solution };
                if (!transfer.Any(s => ReferenceEquals(s, solution))) transfer.Add(solution);
                CadJobBridge.SaveResult(cadRequest, job, transfer, solution,
                    (double)gap.Value, (double)top.Value, (double)bottom.Value, (double)width.Value);
                CadRunTrace.Write("RESULT_WRITTEN solutions=" + transfer.Count +
                    " angleFile=" + angleFile);
                status.Text = Strings.F("DeskTransferCount", transfer.Count);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                CadRunTrace.Write("ERROR: RESULT " + ex);
                MessageBox.Show(ex.Message, Strings.T("DeskTransferError"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Filter = "AutoCAD DXF (*.dxf)|*.dxf", DefaultExt = "dxf",
            FileName = sourceFiles.Length == 1
                ? Path.GetFileNameWithoutExtension(sourceFiles[0]) + "_Dlayout.dxf"
                : "Dlayout_optimized.dxf",
            InitialDirectory = sourceFiles.Length > 0 ? Path.GetDirectoryName(sourceFiles[0]) : null
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            DxfExporter.Save(dialog.FileName, solution, 2,
                (double)top.Value, (double)bottom.Value, (double)gap.Value);
            status.Text = Strings.F("DeskSaved", dialog.FileName);
            MessageBox.Show(Strings.F("DeskSavedDetails", solution.Pitch, solution.StripWidth, dialog.FileName),
                "Dlayout", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, Strings.T("DeskExportError"), MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}

internal sealed class Preview : Control
{
    private List<ShapePlace> places = new();
    private double pitch;
    private double upper, lower;
    private int copies = 2;
    private double zoom = 1.0;
    private Point pan = Point.Empty;
    private Point? dragStart;
    private string? emptyMessage;
    private readonly Color[] colors = [Color.FromArgb(39, 123, 201), Color.FromArgb(220, 146, 43),
        Color.FromArgb(35, 158, 113), Color.FromArgb(169, 95, 187), Color.FromArgb(190, 71, 86), Color.FromArgb(47, 161, 177)];
    public Preview()
    {
        DoubleBuffered = true; BackColor = Color.White;
        MouseWheel += (_, e) => { zoom = Math.Clamp(zoom * (e.Delta > 0 ? 1.15 : 1 / 1.15), .2, 6); Invalidate(); };
        MouseDown += (_, e) => { if (e.Button == MouseButtons.Left) dragStart = e.Location; };
        MouseMove += (_, e) => { if (dragStart.HasValue) { pan.Offset(e.X - dragStart.Value.X, e.Y - dragStart.Value.Y); dragStart = e.Location; Invalidate(); } };
        MouseUp += (_, _) => dragStart = null;
        Resize += (_, _) => Invalidate();
    }
    public void ShowArrangement(List<ShapePlace> parts, double k, double t, double b)
    { places = parts; pitch = k; upper = t; lower = b; emptyMessage = null; zoom = 1; pan = Point.Empty; Invalidate(); }
    public void ShowSolution(Solution solution, int count, double t, double b)
    { places = StepPhase.Rebase(solution.Places, solution.Pitch); pitch = solution.Pitch; copies = 2; upper = t; lower = b; emptyMessage = null; zoom = 1; pan = Point.Empty; Invalidate(); }
    public void BeginLiveSearch(double t, double b)
    { places = new List<ShapePlace>(); pitch = 0; upper = t; lower = b; emptyMessage = null; zoom = 1; pan = Point.Empty; Invalidate(); }
    public void ShowLiveMessage(string message, double t, double b)
    { places = new List<ShapePlace>(); pitch = 0; upper = t; lower = b; emptyMessage = message; Invalidate(); }
    public void ShowLiveSolution(Solution solution, int count, double t, double b)
    { places = StepPhase.Rebase(solution.Places, solution.Pitch); pitch = solution.Pitch; copies = 2; upper = t; lower = b; emptyMessage = null; Invalidate(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics; g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        g.Clear(Color.White);
        if (places.Count == 0)
        {
            if (!string.IsNullOrWhiteSpace(emptyMessage))
            {
                using var messageFont = new Font("Segoe UI", 13, FontStyle.Regular);
                TextRenderer.DrawText(g, emptyMessage, messageFont, ClientRectangle,
                    Color.FromArgb(90, 104, 120),
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
            }
            return;
        }
        BBox box = Geometry.Bounds(places);
        int repeat = pitch > 0 ? Math.Max(2, copies) : 1;
        double minX = box.MinX, maxX = box.MaxX + Math.Max(0, repeat - 1) * pitch;
        double minY = box.MinY - lower, maxY = box.MaxY + upper;
        double w = Math.Max(1, maxX - minX), h = Math.Max(1, maxY - minY);
        double scale = Math.Min((ClientSize.Width - 65) / w, (ClientSize.Height - 110) / h) * zoom;
        scale = Math.Clamp(scale, .0005, 1000);
        double cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
        PointF Map(Pt p) => new((float)((p.X - cx) * scale + ClientSize.Width * .5 + pan.X),
            (float)((cy - p.Y) * scale + ClientSize.Height * .5 + pan.Y));
        var p1 = Map(new Pt(minX, maxY));
        var p2 = Map(new Pt(maxX, minY));
        using (var bg = new SolidBrush(Color.FromArgb(246, 248, 251)))
            g.FillRectangle(bg, Math.Min(p1.X, p2.X), Math.Min(p1.Y, p2.Y), Math.Abs(p2.X - p1.X), Math.Abs(p2.Y - p1.Y));
        using (var stripLine = new Pen(Color.FromArgb(70, 86, 108), 1.3f))
        {
            g.DrawLine(stripLine, Map(new Pt(minX, maxY)), Map(new Pt(maxX, maxY)));
            g.DrawLine(stripLine, Map(new Pt(minX, minY)), Map(new Pt(maxX, minY)));
        }
        for (int s = 0; s < repeat; s++)
        for (int i = 0; i < places.Count; i++)
        {
            var polygon = places[i].Points.Select(p => Map(p + new Pt(s * pitch, 0))).ToArray();
            if (polygon.Length < 3) continue;
            Color c = s == 0 ? Color.FromArgb(205, 52, 52) : Color.FromArgb(225, 177, 24);
            using (var brush = new SolidBrush(Color.FromArgb(75, c))) g.FillPolygon(brush, polygon);
            using (var pen = new Pen(c, 1.6f)) g.DrawPolygon(pen, polygon);
            var label = Map(places[i].Center + new Pt(s * pitch, 0));
            using var font = new Font("Segoe UI", 10, FontStyle.Bold);
            using var textBrush = new SolidBrush(Color.FromArgb(43, 54, 68));
            g.DrawString($"{places[i].Shape.Handle} / {s + 1}", font, textBrush, label);
        }
        if (pitch > 0)
        {
            var y = maxY + Math.Max(1, h * .04);
            using var pen = new Pen(Color.FromArgb(27, 109, 183), 1.6f) { EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor };
            var a = Map(new Pt(box.MinX, y)); var b = Map(new Pt(box.MinX + pitch, y));
            g.DrawLine(pen, a, b);
            using var font = new Font("Segoe UI", 10, FontStyle.Bold);
            g.DrawString($"P = {pitch:0.###}", font, Brushes.DarkBlue, (a.X + b.X) / 2, Math.Max(0, a.Y - 26));
        }
        using var tipFont = new Font("Segoe UI", 9);
        g.DrawString("Wheel: zoom     Drag: pan", tipFont, Brushes.Gray, 15, ClientSize.Height - 29);
    }
}
