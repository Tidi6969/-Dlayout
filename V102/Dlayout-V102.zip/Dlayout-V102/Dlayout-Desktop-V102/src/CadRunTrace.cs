﻿using System.Text;

namespace DCAD.Dlayout;
internal static class CadRunTrace
{
    private static string? logPath;
    internal static void Start(string jobFile)
    {
        logPath = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(jobFile))!, "session.log");
        Write("JOB_RECEIVED " + Path.GetFullPath(jobFile));
        Write("VERSION 98");
        Write("DUSER " + DlayoutSettingsStore.DirectoryPath);
    }
    internal static void Write(string message)
    {
        if (logPath == null) return;
        try { File.AppendAllText(logPath,
            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + message.Replace("\r", " ").Replace("\n", " ") + Environment.NewLine,
            new UTF8Encoding(false)); }
        catch { /* Diagnostic I/O failure must not corrupt CAD geometry. */ }
    }
}
