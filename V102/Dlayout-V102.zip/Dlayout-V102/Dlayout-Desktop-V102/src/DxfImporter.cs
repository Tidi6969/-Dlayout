using System.Globalization;

namespace DCAD.Dlayout;

internal static class DxfImporter
{
    private readonly record struct DxfPair(int Code, string Value);

    private sealed class PolySegment
    {
        public List<Pt> Points { get; }
        public PolySegment(IEnumerable<Pt> points) => Points = new List<Pt>(points);
    }

    public static List<Shape> Load(string filePath)
    {
        if (!File.Exists(filePath)) throw new FileNotFoundException("DXF file not found", filePath);

        List<DxfPair> pairs = ReadPairs(filePath);
        List<List<Pt>> closedLoops = new();
        List<int?> loopColors = new();
        List<PolySegment> openSegments = new();

        bool inEntities = false;
        int i = 0;
        while (i < pairs.Count)
        {
            if (pairs[i].Code == 0 && EqualsText(pairs[i].Value, "SECTION"))
            {
                if (i + 1 < pairs.Count && pairs[i + 1].Code == 2 && EqualsText(pairs[i + 1].Value, "ENTITIES"))
                    inEntities = true;
                i++;
                continue;
            }

            if (inEntities && pairs[i].Code == 0 && EqualsText(pairs[i].Value, "ENDSEC"))
            {
                inEntities = false;
                i++;
                continue;
            }

            if (!inEntities || pairs[i].Code != 0)
            {
                i++;
                continue;
            }

            string type = pairs[i].Value.ToUpperInvariant();
            if (type == "POLYLINE")
            {
                int before = closedLoops.Count;
                i = ParseClassicPolyline(pairs, i, closedLoops, out string polyLayer, out int? polyColor);
                if (polyLayer.Equals("DLAYOUT_STRIP", StringComparison.OrdinalIgnoreCase))
                {
                    if (closedLoops.Count > before) closedLoops.RemoveRange(before, closedLoops.Count - before);
                }
                else
                {
                    while (loopColors.Count < closedLoops.Count) loopColors.Add(polyColor);
                }
                continue;
            }

            int start = i + 1;
            int end = start;
            while (end < pairs.Count && pairs[end].Code != 0) end++;
            List<DxfPair> data = pairs.GetRange(start, end - start);
            // Do not treat the strip rectangle of an exported solution as a new part.
            if (data.Any(p => p.Code == 8 && p.Value.Equals("DLAYOUT_STRIP", StringComparison.OrdinalIgnoreCase)))
            { i = end; continue; }

            if (type is "INSERT" or "SPLINE" or "ELLIPSE" or "REGION" or "HATCH")
                throw new InvalidDataException($"DXF entity {type} is not supported as a contour. Explode/convert to closed 2D polylines first.");
            if (type is "LWPOLYLINE" or "CIRCLE" or "LINE" or "ARC")
                RejectNonPlanar(data);
            switch (type)
            {
                case "LWPOLYLINE":
                    {
                        List<Pt> loop = ParseLwPolyline(data);
                        if (loop.Count >= 3) { closedLoops.Add(loop); loopColors.Add(EntityColor(data)); }
                        break;
                    }
                case "CIRCLE":
                    {
                        double cx = Value(data, 10);
                        double cy = Value(data, 20);
                        double radius = Value(data, 40);
                        if (radius > 0.0) { closedLoops.Add(SampleCircle(cx, cy, radius)); loopColors.Add(EntityColor(data)); }
                        break;
                    }
                case "LINE":
                    {
                        Pt a = new(Value(data, 10), Value(data, 20));
                        Pt b = new(Value(data, 11), Value(data, 21));
                        if (Geometry.Distance(a, b) > 1e-9) openSegments.Add(new PolySegment(new[] { a, b }));
                        break;
                    }
                case "ARC":
                    {
                        double cx = Value(data, 10);
                        double cy = Value(data, 20);
                        double radius = Value(data, 40);
                        double startDeg = Value(data, 50);
                        double endDeg = Value(data, 51);
                        if (radius > 0.0) openSegments.Add(new PolySegment(SampleArc(cx, cy, radius, startDeg, endDeg)));
                        break;
                    }
            }

            i = end;
        }

        var joined = JoinOpenSegments(openSegments);
        closedLoops.AddRange(joined);
        loopColors.AddRange(Enumerable.Repeat<int?>(null, joined.Count));
        var cleaned = closedLoops.Select((loop, idx) => (Points: CleanLoop(loop), Color: loopColors[idx]))
            .Where(x => x.Points.Count >= 3 && Math.Abs(Geometry.Area(x.Points.ToArray())) > 1e-7)
            .ToList();
        closedLoops = cleaned.Select(x => x.Points).ToList();
        loopColors = cleaned.Select(x => x.Color).ToList();

        if (closedLoops.Count == 0)
            throw new InvalidDataException("No supported closed contours found in DXF (ENTITIES section).");

        // V58: exactly like the DNesting outer-silhouette policy requested by
        // the user. Internal holes, annotation outlines and nested islands do
        // not contribute to the pitch optimisation or exported contours.
        List<List<Pt>> outerLoops = SelectOuterLoops(closedLoops);
        // CAD strip-layout benchmark drawings carry red base outlines (ACI 1)
        // and identical yellow copies (ACI 2), all shifted by one common P.
        // Import only the red BASE when (and only when) the entire matched
        // red/yellow translation is verified. Other colored drawings are kept.
        outerLoops = SelectVerifiedBaseStep(outerLoops, closedLoops, loopColors);
        if (outerLoops.Count > 12)
            throw new InvalidDataException("Too many contours. Select up to 12 closed outlines in a DXF file.");
        List<Shape> result = new();
        for (int n = 0; n < outerLoops.Count; n++)
        {
            List<Pt> loop = EnsureCounterClockwise(outerLoops[n]);
            var arr = loop.ToArray();
            if (loop.Count > 2000)
                throw new InvalidDataException("Contour has over 2000 sampled vertices. Simplify DXF before optimizing.");
            if (Geometry.HasSelfIntersection(arr))
                throw new InvalidDataException("Self-intersecting contour in DXF. Repair the outline before optimizing.");
            BBox bounds = BBox.From(arr);
            Pt center = new((bounds.MinX + bounds.MaxX) * 0.5, (bounds.MinY + bounds.MaxY) * 0.5);
            result.Add(new Shape
            {
                Handle = $"{Path.GetFileNameWithoutExtension(filePath)}_{n + 1}",
                OriginalCenter = center,
                LocalPoints = loop.Select(p => p - center).ToArray(),
                Area = Math.Abs(Geometry.Area(arr))
            });
        }
        return result;
    }

    private static List<DxfPair> ReadPairs(string filePath)
    {
        string[] lines = File.ReadAllLines(filePath);
        List<DxfPair> pairs = new(lines.Length / 2);
        for (int i = 0; i + 1 < lines.Length; i += 2)
        {
            if (int.TryParse(lines[i].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out int code))
                pairs.Add(new DxfPair(code, lines[i + 1].Trim()));
        }
        return pairs;
    }

    private static int ParseClassicPolyline(List<DxfPair> pairs, int polylineIndex,
        List<List<Pt>> output, out string layer, out int? color)
    {
        int i = polylineIndex + 1;
        List<DxfPair> header = new();
        while (i < pairs.Count && pairs[i].Code != 0)
        {
            header.Add(pairs[i]);
            i++;
        }

        layer = header.FirstOrDefault(p => p.Code == 8).Value ?? "0";
        color = EntityColor(header);
        int flags = IntValue(header, 70);
        bool closed = (flags & 1) != 0;
        if ((flags & 8) != 0 || (flags & 16) != 0 || (flags & 64) != 0)
            throw new InvalidDataException("3D/polyface POLYLINE not supported. Flatten outlines to XY.");
        List<Pt> points = new();
        List<double> bulges = new();

        while (i < pairs.Count && pairs[i].Code == 0 && EqualsText(pairs[i].Value, "VERTEX"))
        {
            i++;
            List<DxfPair> vertex = new();
            while (i < pairs.Count && pairs[i].Code != 0)
            {
                vertex.Add(pairs[i]);
                i++;
            }
            RejectNonPlanar(vertex);
            points.Add(new Pt(Value(vertex, 10), Value(vertex, 20)));
            bulges.Add(Value(vertex, 42));
        }

        if (i < pairs.Count && pairs[i].Code == 0 && EqualsText(pairs[i].Value, "SEQEND"))
        {
            i++;
            while (i < pairs.Count && pairs[i].Code != 0) i++;
        }

        if (closed && points.Count >= 2)
            output.Add(ExpandBulges(points, bulges));

        return i;
    }

    private static List<Pt> ParseLwPolyline(List<DxfPair> data)
    {
        int flags = IntValue(data, 70);
        bool closed = (flags & 1) != 0;

        List<Pt> points = new();
        List<double> bulges = new();
        bool hasX = false;
        bool hasY = false;
        double currentX = 0.0;
        double currentY = 0.0;
        double currentBulge = 0.0;

        void Commit()
        {
            if (hasX && hasY)
            {
                points.Add(new Pt(currentX, currentY));
                bulges.Add(currentBulge);
            }
            hasX = false;
            hasY = false;
            currentX = 0.0;
            currentY = 0.0;
            currentBulge = 0.0;
        }

        foreach (DxfPair pair in data)
        {
            if (pair.Code == 10)
            {
                Commit();
                currentX = ParseDouble(pair.Value);
                hasX = true;
            }
            else if (pair.Code == 20)
            {
                currentY = ParseDouble(pair.Value);
                hasY = true;
            }
            else if (pair.Code == 42)
            {
                currentBulge = ParseDouble(pair.Value);
            }
        }
        Commit();

        if (!closed && points.Count >= 3 && Geometry.Distance(points[0], points[^1]) <= 1e-7)
        {
            closed = true;
            points.RemoveAt(points.Count - 1);
            if (bulges.Count > points.Count) bulges.RemoveAt(bulges.Count - 1);
        }

        return closed && points.Count >= 2 ? ExpandBulges(points, bulges) : new List<Pt>();
    }

    private static List<Pt> ExpandBulges(IReadOnlyList<Pt> points, IReadOnlyList<double> bulges)
    {
        List<Pt> output = new();
        for (int i = 0; i < points.Count; i++)
        {
            Pt a = points[i];
            Pt b = points[(i + 1) % points.Count];
            double bulge = i < bulges.Count ? bulges[i] : 0.0;
            output.Add(a);

            if (Math.Abs(bulge) < 1e-12) continue;

            double chord = Geometry.Distance(a, b);
            if (chord <= 1e-12) continue;

            double theta = 4.0 * Math.Atan(bulge);
            double midX = (a.X + b.X) * 0.5;
            double midY = (a.Y + b.Y) * 0.5;
            double ux = (b.X - a.X) / chord;
            double uy = (b.Y - a.Y) / chord;
            double centerOffset = chord * (1.0 - bulge * bulge) / (4.0 * bulge);
            double cx = midX - uy * centerOffset;
            double cy = midY + ux * centerOffset;
            double radius = Geometry.Distance(a, new Pt(cx, cy));
            double start = Math.Atan2(a.Y - cy, a.X - cx);
            int segments = ArcSegments(radius, Math.Abs(theta));

            for (int j = 1; j < segments; j++)
            {
                double angle = start + theta * j / segments;
                output.Add(new Pt(cx + radius * Math.Cos(angle), cy + radius * Math.Sin(angle)));
            }
        }
        return output;
    }

    private static int ArcSegments(double radius, double angle)
    {
        // Maximum 0.004 drawing units sagitta, plus a 5 degree angular bound.
        // The periodic verifier uses 0.01001 extra clearance for tessellation.
        double step = radius <= 0.004 ? Math.PI / 90 :
            2 * Math.Acos(Math.Clamp(1 - 0.004 / radius, -1, 1));
        step = Math.Min(step, Math.PI / 36);
        int count = Math.Max(2, (int)Math.Ceiling(angle / step));
        if (count > 1800) throw new InvalidDataException("DXF arc too large for the configured sampling tolerance.");
        return count;
    }

    private static List<Pt> SampleCircle(double cx, double cy, double radius)
    {
        int segments = ArcSegments(radius, 2.0 * Math.PI);
        List<Pt> points = new(segments);
        for (int i = 0; i < segments; i++)
        {
            double angle = 2.0 * Math.PI * i / segments;
            points.Add(new Pt(cx + radius * Math.Cos(angle), cy + radius * Math.Sin(angle)));
        }
        return points;
    }

    private static List<Pt> SampleArc(double cx, double cy, double radius, double startDeg, double endDeg)
    {
        while (endDeg < startDeg) endDeg += 360.0;
        double span = endDeg - startDeg;
        int segments = ArcSegments(radius, span * Math.PI / 180.0);
        List<Pt> points = new(segments + 1);
        for (int i = 0; i <= segments; i++)
        {
            double degrees = startDeg + span * i / segments;
            double radians = degrees * Math.PI / 180.0;
            points.Add(new Pt(cx + radius * Math.Cos(radians), cy + radius * Math.Sin(radians)));
        }
        return points;
    }

    private static List<List<Pt>> JoinOpenSegments(List<PolySegment> source)
    {
        const double tolerance = 1e-5;
        List<List<Pt>> remaining = source.Select(s => new List<Pt>(s.Points)).ToList();
        List<List<Pt>> loops = new();

        while (remaining.Count > 0)
        {
            List<Pt> chain = remaining[0];
            remaining.RemoveAt(0);
            bool changed = true;

            while (changed && remaining.Count > 0)
            {
                changed = false;
                for (int i = 0; i < remaining.Count; i++)
                {
                    List<Pt> segment = remaining[i];
                    Pt chainStart = chain[0];
                    Pt chainEnd = chain[^1];
                    Pt segStart = segment[0];
                    Pt segEnd = segment[^1];

                    if (Geometry.Distance(chainEnd, segStart) <= tolerance)
                    {
                        chain.AddRange(segment.Skip(1));
                    }
                    else if (Geometry.Distance(chainEnd, segEnd) <= tolerance)
                    {
                        segment.Reverse();
                        chain.AddRange(segment.Skip(1));
                    }
                    else if (Geometry.Distance(chainStart, segEnd) <= tolerance)
                    {
                        List<Pt> prefix = segment.Take(segment.Count - 1).ToList();
                        prefix.AddRange(chain);
                        chain = prefix;
                    }
                    else if (Geometry.Distance(chainStart, segStart) <= tolerance)
                    {
                        segment.Reverse();
                        List<Pt> prefix = segment.Take(segment.Count - 1).ToList();
                        prefix.AddRange(chain);
                        chain = prefix;
                    }
                    else
                    {
                        continue;
                    }

                    remaining.RemoveAt(i);
                    changed = true;
                    break;
                }
            }

            if (chain.Count >= 3 && Geometry.Distance(chain[0], chain[^1]) <= tolerance)
            {
                chain.RemoveAt(chain.Count - 1);
                loops.Add(chain);
            }
        }

        return loops;
    }

    private static List<Pt> CleanLoop(List<Pt> loop)
    {
        const double tolerance = 1e-9;
        List<Pt> cleaned = new();
        foreach (Pt point in loop)
        {
            if (cleaned.Count == 0 || Geometry.Distance(cleaned[^1], point) > tolerance)
                cleaned.Add(point);
        }
        if (cleaned.Count > 1 && Geometry.Distance(cleaned[0], cleaned[^1]) <= tolerance)
            cleaned.RemoveAt(cleaned.Count - 1);
        return cleaned;
    }

    private static List<List<Pt>> SelectOuterLoops(List<List<Pt>> loops)
    {
        List<List<Pt>> outer = new();
        for (int i = 0; i < loops.Count; i++)
        {
            List<Pt> candidate = loops[i];
            double candidateArea = Math.Abs(Geometry.Area(candidate.ToArray()));
            Pt probe = candidate[0];
            int depth = 0;

            for (int j = 0; j < loops.Count; j++)
            {
                if (i == j) continue;
                List<Pt> other = loops[j];
                if (Math.Abs(Geometry.Area(other.ToArray())) <= candidateArea) continue;
                if (Geometry.PointInPolygon(probe, other)) depth++;
            }

            if (depth == 0) outer.Add(candidate);
        }
        return outer;
    }

    private static int? EntityColor(List<DxfPair> data)
    {
        foreach (var pair in data)
            if (pair.Code == 62 && int.TryParse(pair.Value, NumberStyles.Integer,
                CultureInfo.InvariantCulture, out int color)) return Math.Abs(color);
        return null;
    }

    private static List<List<Pt>> SelectVerifiedBaseStep(List<List<Pt>> outer,
        List<List<Pt>> allLoops, List<int?> colors)
    {
        if (!outer.Any(x => colors[allLoops.IndexOf(x)] == 1) ||
            !outer.Any(x => colors[allLoops.IndexOf(x)] == 2)) return outer;
        var reds = outer.Where(x => colors[allLoops.IndexOf(x)] == 1).ToList();
        var yellows = outer.Where(x => colors[allLoops.IndexOf(x)] == 2).ToList();
        if (reds.Count != yellows.Count || reds.Count * 2 != outer.Count) return outer;
        var unused = new List<List<Pt>>(yellows);
        double? pitch = null;
        foreach (var red in reds)
        {
            int matchIndex = -1;
            double matchPitch = 0;
            for (int index = 0; index < unused.Count; index++)
            {
                var yellow = unused[index];
                if (red.Count != yellow.Count) continue;
                BBox a = BBox.From(red), b = BBox.From(yellow);
                double dx = b.MinX - a.MinX;
                if (dx <= 1e-5 || Math.Abs(b.MinY - a.MinY) > 1e-4 ||
                    Math.Abs(a.Width - b.Width) > 1e-4 ||
                    Math.Abs(a.Height - b.Height) > 1e-4 ||
                    (pitch.HasValue && Math.Abs(pitch.Value - dx) > 1e-3)) continue;
                // Identical ordered polygons, potentially with a different
                // start vertex. No reflection, rotation, or unverified pairing.
                bool identical = false;
                for (int start = 0; start < yellow.Count && !identical; start++)
                {
                    identical = true;
                    for (int k = 0; k < red.Count; k++)
                    {
                        Pt expected = red[k] + new Pt(dx, 0);
                        if (expected.Dist2(yellow[(start + k) % yellow.Count]) > 1e-8)
                        { identical = false; break; }
                    }
                }
                if (!identical) continue;
                matchIndex = index;
                matchPitch = dx;
                break;
            }
            if (matchIndex < 0) return outer;
            pitch ??= matchPitch;
            unused.RemoveAt(matchIndex);
        }
        return unused.Count == 0 ? reds : outer;
    }

    private static List<Pt> EnsureCounterClockwise(List<Pt> loop)
    {
        List<Pt> copy = new(loop);
        if (Geometry.Area(copy.ToArray()) < 0.0) copy.Reverse();
        return copy;
    }

    private static void RejectNonPlanar(List<DxfPair> data)
    {
        // A periodic 2D DXF cannot be computed safely from an OCS normal,
        // 3D elevation, or a non-XY extrusion without transforming coordinates.
        if (Math.Abs(Value(data, 30)) > 1e-8 || Math.Abs(Value(data, 31)) > 1e-8 ||
            Math.Abs(Value(data, 38)) > 1e-8)
            throw new InvalidDataException("3D elevation or Z coordinate found. Flatten this DXF to XY before importing.");
        bool hasNormal = data.Any(p => p.Code is 210 or 220 or 230);
        if (hasNormal && (Math.Abs(Value(data, 210)) > 1e-8 ||
            Math.Abs(Value(data, 220)) > 1e-8 || Math.Abs(Value(data, 230) - 1) > 1e-8))
            throw new InvalidDataException("Non-XY extrusion detected in DXF. Flatten to world XY first.");
    }

    private static double Value(List<DxfPair> data, int code)
    {
        foreach (DxfPair pair in data)
            if (pair.Code == code) return ParseDouble(pair.Value);
        return 0.0;
    }

    private static int IntValue(List<DxfPair> data, int code)
    {
        foreach (DxfPair pair in data)
            if (pair.Code == code && int.TryParse(pair.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value))
                return value;
        return 0;
    }

    private static double ParseDouble(string text) =>
        double.Parse(text, NumberStyles.Float, CultureInfo.InvariantCulture);

    private static bool EqualsText(string a, string b) =>
        string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
}
