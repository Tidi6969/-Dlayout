// A selected contour is a PART TYPE. Its quantity is the number of instances
// stamped at EACH material advance P, not a finite nesting order quantity.
namespace DCAD.Dlayout;
internal static class StepSchedule
{
    public const int MaxPerStep = 12; // Keep the original V55 optimiser's verified complexity limit.
    public static Job Expand(Job source, IReadOnlyList<bool> enabled, IReadOnlyList<int> quantities,
        double gap, double top, double bottom)
    {
        if (enabled.Count != source.Shapes.Count || quantities.Count != source.Shapes.Count)
            throw new ArgumentException("Each contour must have a selection and a per-step quantity.");
        var parts = new List<Shape>();
        for (int i = 0; i < source.Shapes.Count; i++)
        {
            if (!enabled[i]) continue;
            int quantity = quantities[i];
            if (quantity < 1 || quantity > MaxPerStep)
                throw new ArgumentOutOfRangeException(nameof(quantities), "Per-step coefficient must be between 1 and 12.");
            Shape original = source.Shapes[i];
            for (int unit = 1; unit <= quantity; unit++)
            {
                parts.Add(new Shape
                {
                    Handle = $"{original.Handle}#{unit}",
                    OriginalCenter = original.OriginalCenter,
                    LocalPoints = original.LocalPoints,
                    Area = original.Area
                });
                if (parts.Count > MaxPerStep)
                    throw new InvalidDataException("Dlayout V60 periodic optimiser supports at most 12 contours per step (P). Reduce the sum of selected coefficients.");
            }
        }
        if (parts.Count == 0) throw new InvalidDataException("Select at least one contour.");
        if (gap < 0 || top < 0 || bottom < 0) throw new InvalidDataException("Clearances cannot be negative.");
        return new Job { Id = source.Id, Shapes = parts, Gap = gap, Top = top, Bottom = bottom };
    }
}
