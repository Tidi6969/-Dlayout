using System.IO.Pipes;
using System.Text;

namespace DCAD.Dlayout;

// Based on DNest V38: the pipe is created before CAD selection finishes,
// and the same Desktop process is used for the entire CAD session.
internal static class DlayoutPreloadServer
{
    private const string PipePrefix = "DCAD_Dlayout_";

    internal static int Run(string sessionId, int languageIndex, IntPtr cadOwnerHwnd)
    {
        if (!Guid.TryParseExact(sessionId, "N", out _))
            throw new InvalidDataException("Invalid Dlayout CAD session ID.");
        Strings.Load(languageIndex);
        using var server = new NamedPipeServerStream(
            PipePrefix + sessionId,
            PipeDirection.In, 1, PipeTransmissionMode.Byte, PipeOptions.None);

        // Do not warm MainForm before the CAD job supplies its DIRECT DUser.
        // Loading settings from an unknown local profile caused cross-machine drift.

        server.WaitForConnection();
        using var reader = new StreamReader(server, new UTF8Encoding(false), false, 4096, leaveOpen: true);
        string? cmd = reader.ReadLine();
        if (string.IsNullOrWhiteSpace(cmd) || cmd == "CANCEL") return 0;
        if (!cmd.StartsWith("JOB ", StringComparison.Ordinal))
            throw new InvalidDataException("Unknown Dlayout Desktop preload command.");

        string path = Encoding.UTF8.GetString(Convert.FromBase64String(cmd[4..].Trim()));
        path = Path.GetFullPath(path);
        // Check before opening UI; the request itself is validated by MainForm.LoadCadJob.
        if (!File.Exists(path)) throw new FileNotFoundException("CAD Job not found.", path);
        DlayoutSettingsStore.ConfigureFromJob(path);
        CadRunTrace.Start(path);
        CadOwnedWindowHost.Run(new MainForm(null, path), cadOwnerHwnd);
        return 0;
    }
}
