namespace DCAD.Dlayout;

// One entry per ORIGINAL DXF outer silhouette, never per StepSchedule copy or
// per exported red/yellow cycle. Disabling an entry does not lose its factor.
internal readonly record struct ContourChoice(bool Enabled, int Factor);
internal sealed class ContourSelectionState
{
    private readonly ContourChoice[] entries;
    public int TypeCount => entries.Length;
    public int SelectedTypes => entries.Count(x => x.Enabled);
    public int PartsPerPitch => entries.Where(x => x.Enabled).Sum(x => x.Factor);
    public ContourChoice this[int index] => entries[index];
    public ContourSelectionState(int count)
    {
        if (count < 1 || count > 12) throw new ArgumentOutOfRangeException(nameof(count));
        entries = Enumerable.Repeat(new ContourChoice(true, 1), count).ToArray();
    }
    public void Set(int index, bool enabled, int factor)
    {
        if (index < 0 || index >= entries.Length) throw new ArgumentOutOfRangeException(nameof(index));
        if (factor < 1 || factor > StepSchedule.MaxPerStep)
            throw new ArgumentOutOfRangeException(nameof(factor), "Coefficient must be from 1 to 12.");
        entries[index] = new ContourChoice(enabled, factor);
    }
    public (bool[] Enabled, int[] Factors) Snapshot() =>
        (entries.Select(x => x.Enabled).ToArray(), entries.Select(x => x.Factor).ToArray());
}

