﻿$ErrorActionPreference='Stop'
$root = Split-Path -Parent $PSScriptRoot
$path = Join-Path $PSScriptRoot 'lang.dat'
if (-not (Test-Path -LiteralPath $path)) { throw 'LANGUAGE QA FAIL: Buildtime\lang.dat missing.' }
$bytes = [IO.File]::ReadAllBytes($path)
if ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) { throw 'LANGUAGE QA FAIL: UTF-8 BOM.' }
$utf8 = New-Object Text.UTF8Encoding($false, $true)
$text = $utf8.GetString($bytes).Replace("`r`n","`n").Replace("`r","`n")
$blocks = @{}; $current = $null
foreach($line in $text.Split("`n")) {
  $item=$line.Trim()
  if ($item.Length -eq 0 -or $item.StartsWith('#')) { continue }
  if($item -eq '-') { $current=$null;continue }
  $m=[regex]::Match($item,'^Lang_(\d+)\(([^_()]+)_([^_()]+)\)$')
  if($m.Success) {
    $id=[int]$m.Groups[1].Value
    if ($blocks.ContainsKey($id)) { throw "Duplicate Lang_$id" }
    $current=@{}; $blocks[$id]=$current;continue
  }
  if($null -eq $current) { throw "Text outside language block: $item" }
  $sep=$item.IndexOf('=')
  if($sep -lt 1) { throw "Invalid key=value: $item" }
  $key=$item.Substring(0,$sep)
  $value=$item.Substring($sep+1)
  if($current.ContainsKey($key) -or $value.Length -eq 0) { throw "Duplicate/empty translation: $key" }
  $current[$key]=$value
}
foreach($id in 0..5) {
  if(-not $blocks.ContainsKey($id)) { throw "Missing Lang_$id" }
  if($id -ne 0) {
    $missing=@($blocks[0].Keys | Where-Object { -not $blocks[$id].ContainsKey($_) })
    $extra=@($blocks[$id].Keys | Where-Object { -not $blocks[0].ContainsKey($_) })
    if($missing.Count -gt 0 -or $extra.Count -gt 0) { throw "Lang_$id key mismatch" }
  }
}
$used=@{}
Get-ChildItem -Path (Join-Path $root 'src') -Filter '*.cs' -Recurse -File | ForEach-Object {
  $body=[IO.File]::ReadAllText($_.FullName)
  foreach($m in [regex]::Matches($body,'Strings\.(?:T|F)\(\s*"([^"]+)"')) { $used[$m.Groups[1].Value]=$true }
}
foreach($k in $used.Keys) {if(-not $blocks[0].ContainsKey($k)) { throw "Missing source translation $k" }}
Write-Output ("LANGUAGE QA PASS: {0} languages, {1} keys, {2} referenced keys" -f $blocks.Count, $blocks[0].Count, $used.Count)
