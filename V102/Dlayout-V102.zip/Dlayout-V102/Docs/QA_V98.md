﻿# Dlayout V98 — per-angle result preservation and Desktop compile fix / QA

## Baseline and scope

- Source: Dlayout V96. The last explicitly approved geometry/error-handling baseline was V93; V96 has the latest agreed consolidated DUser and CAD–EXE protocol.
- CAD targets: AutoCAD 2022, AutoCAD 2025, GstarCAD 2027. There is no GstarCAD 2018 target.
- `DLAYOUT` remains the sole CAD command.
- The periodic solver (Pitch, Gap, constraints, sampling and candidate scoring) is unchanged. V98 only observes validated candidate solutions and saves the best one of every tested anchor angle.
- Keep global Top-10/25/50/100/200/500 archive separate from the entire per-angle archive.

## Data contract

- Permanent settings: `DUser\Dlayout_settings.ini`, unchanged.
- Language: `DUser\MIS_SET.SET`, unchanged.
- New long-lived result files: `DUser\Dlayout_results\Dlayout_yyyyMMdd_HHmmss_GUID.jsonl`. Each computation gets its own uniquely named append-only file.
- First line: run version, exact geometry/settings SHA-256 signature, scanned angle count, settings and source silhouettes (only once, not repeated every angle).
- On each completed angular pass, append its best valid solution (Pitch, Width, Score, Efficiency, useful/material areas, every part's identity/X/Y/rotation, sweep angle, elapsed milliseconds), or a `NO_SOLUTION` record. Flush data to disk before beginning the next pass.
- A cancelled partial angle is stored with status `PARTIAL`. A late collective-refinement improvement at a completed angle is appended as an updated record for that same angle; latest record wins.
- Final status line: `COMPLETED`, `CANCELLED` or `FAILED`. The result file is **not** deleted with temporary CAD bridge sessions, including after successful drawing insertion.
- Do not edit settings/AppData/other modules when writing an angle result. Retain normal TEMP bridge cleanup/diagnostics behavior from V96.
- Reopen: `Open saved angle results` requires the same selected silhouettes, quantities and optimization settings. Mismatches are rejected. Preview/draw is reconstructed from current original geometry plus saved placement transforms, without rerunning the optimizer.

## UI and CAD transfer

- `Result view`: global best list or one best/NO_SOLUTION/PARTIAL row for each scanned angle. Sorting by efficiency is possible without discarding unsuccessful angles.
- Selecting a feasible angle displays that layout in preview and enables Apply/Export; a `NO_SOLUTION` row cannot be applied.
- For at most 500 solved angles, the existing CAD protocol-2 picker gets all angle winners in angle view. Above 500, only the explicitly selected winner is sent to the CAD picker; the full angle list remains available in EXE and in DUser. Protocol-2 remains unchanged.
- Objective/quality/clearance/source changes invalidate loaded results and require recalculation or re-opening a matching saved archive.

## Verification needed on Windows

1. Run `Build_All.cmd`: Desktop, three CAD DLLs and Desktop `--selftest` all PASS. Published `Dprogram\Dlayout\Dlayout.exe` must be V98.
2. On a 15° Fast sweep, verify 24 angle records in the per-angle list and JSONL file, regardless of global Top 10.
3. Test a failed angle: it must be present as `NO_SOLUTION`, never replaced with another angle's result.
4. Verify a selected angle's pitch, width, placement centers/rotations, net/material areas and CAD reproduction match its saved record.
5. Stop midway: completed angles and the partial in-progress record survive; normal CAD TEMP cleanup does not delete them.
6. Reopen the saved archive with the original selections and settings; confirm preview and CAD Apply without recomputing. Change one shape/Gap and confirm a visible mismatch warning.
7. Verify cooperative final-pass improvements replace the stored winner for the same angle, not a different angle.
8. Verify all six UI languages, plus AutoCAD2022/2025/GstarCAD2027 and all original Bulge/closed-contour, mixed-validity selection and no-solution regression DWGs.
9. On a sweep above 500 angles, verify EXE can still select every angle and CAD receives the selected winner without violating the protocol-2 500-result guard.

## Test status

- Static code/package checks: performed in this environment.
- Windows .NET compilation, Desktop selftest execution, NETLOAD and CAD/DWG tests: **NOT RUN** in this environment. Do not mark build PASS until tested on Windows.
