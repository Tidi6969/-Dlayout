using System;
using Gssoft.Gscad.DatabaseServices;
using Gssoft.Gscad.Geometry;
using LayoutMaterial;
using LayoutMaterial.Models;

namespace LayoutMaterial.Services
{
    /// <summary>
    /// Port 1-1 logic từ (pitchcalculator + _mindist) trong LISP.
    /// Ghi chú:
    /// - obj1: polyline đã rotate (tạm)
    /// - obj2: bản copy obj1, move sang phải rồi hiệu chỉnh dx để đạt gap ~ A
    /// - filter: chỉ accept nếu gap nằm trong [0.9A .. 1.1A]
    /// </summary>
    public sealed class PitchCalculatorService
    {
        private const int DefaultDiv = 200;

        public LayoutRow? Compute(
            Transaction tr,
            BlockTableRecord space,
            Polyline obj1InDb,
            double A,
            double rotateDeg,
            double topMargin = 0.0,
            double bottomMargin = 0.0)
        {
            if (A <= 0) return null;

            // Bounding box + centerX + area
            var bb1 = GetExtentsSafe(obj1InDb);
            var mn = bb1.MinPoint;
            var mx = bb1.MaxPoint;

            double C = Math.Abs(mx.X - mn.X);   // width
            double D = Math.Abs(mx.Y - mn.Y);   // height
            double X1 = CenterOf(bb1).X;

            double areaVal = obj1InDb.Area;

            // obj2 = copy obj1
            var obj2 = (Polyline)obj1InDb.Clone();
            space.AppendEntity(obj2);
            tr.AddNewlyCreatedDBObject(obj2, true);

            // move obj2 (A + C, 0)
            obj2.TransformBy(Matrix3d.Displacement(new Vector3d(A + C, 0, 0)));

            // mindist
            var res = MinDistance(obj1InDb, obj2, DefaultDiv);
            double E = res.Distance;
            var pt1 = res.P1;
            var pt2 = res.P2;
            double theta = res.HasPoints ? AngleBetweenDeg(pt1, pt2) : 0.0;

            // avoid 90 deg (|theta-90| <= 1deg), max 20
            int n = 0;
            while (n < 20 && Math.Abs(theta - 90.0) <= 1.0)
            {
                obj2.TransformBy(Matrix3d.Displacement(new Vector3d(-0.9 * A, 0, 0)));
                res = MinDistance(obj1InDb, obj2, DefaultDiv);
                E = res.Distance;
                pt1 = res.P1;
                pt2 = res.P2;
                theta = res.HasPoints ? AngleBetweenDeg(pt1, pt2) : 0.0;
                n++;
            }

            // adjust dx = (A - E) / cos(theta)
            double dx = DxFromGap(A, E, theta);
            if (Math.Abs(dx) > 1e-12)
                obj2.TransformBy(Matrix3d.Displacement(new Vector3d(dx, 0, 0)));

            // recompute
            res = MinDistance(obj1InDb, obj2, DefaultDiv);
            E = res.Distance;
            pt1 = res.P1;
            pt2 = res.P2;
            theta = res.HasPoints ? AngleBetweenDeg(pt1, pt2) : 0.0;

            // refine 1 more if needed
            if (Math.Abs(E - A) > 0.001)
            {
                dx = DxFromGap(A, E, theta);
                if (Math.Abs(dx) > 1e-12)
                    obj2.TransformBy(Matrix3d.Displacement(new Vector3d(dx, 0, 0)));

                res = MinDistance(obj1InDb, obj2, DefaultDiv);
                E = res.Distance;
            }

            // filter E in [0.9A, 1.1A]
            double Emin = 0.9 * A;
            double Emax = 1.1 * A;
            if (E < Emin || E > Emax)
            {
                obj2.Erase(true);
                return null;
            }

            // Pitch K = |centerX2 - centerX1|
            var bb2 = GetExtentsSafe(obj2);
            double X2 = CenterOf(bb2).X;
            double K = Math.Abs(X2 - X1);

            // rate = 100*area/(K*(D + top + bottom))
            double materialHeight = D + Math.Max(0.0, topMargin) + Math.Max(0.0, bottomMargin);
            double denomHeight = materialHeight > 1e-12 ? materialHeight : D;
            double rate = (K > 1e-12 && denomHeight > 1e-12) ? (100.0 * areaVal / (K * denomHeight)) : 0.0;

            var row = new LayoutRow
            {
                Area = NumericFormat.RoundTo(areaVal, NumericFormat.CalculatorDecimals),
                Pitch = NumericFormat.RoundTo(K, NumericFormat.CalculatorDecimals),
                Height = NumericFormat.RoundTo(D, NumericFormat.CalculatorDecimals),
                RotateDeg = NumericFormat.RoundTo(rotateDeg, NumericFormat.CalculatorDecimals),
                Gap = NumericFormat.RoundTo(E, NumericFormat.CalculatorDecimals),
                Rate = NumericFormat.RoundTo(rate, NumericFormat.CalculatorDecimals)
            };

            // cleanup obj2
            obj2.Erase(true);
            return row;
        }

        private static double DxFromGap(double A, double E, double thetaDeg)
        {
            double rad = thetaDeg * Math.PI / 180.0;
            double c = Math.Cos(rad);
            if (Math.Abs(c) < 1e-6) return 0.0;
            return (A - E) / c;
        }

        private static Extents3d GetExtentsSafe(Entity e)
        {
            // Some entities throw if they have no extents yet; in our flow they should.
            try { return e.GeometricExtents; }
            catch
            {
                // Fallback: small extents around origin (avoid crash)
                return new Extents3d(new Point3d(0, 0, 0), new Point3d(0, 0, 0));
            }
        }

        private static Point3d CenterOf(Extents3d ex)
        {
            return new Point3d(
                (ex.MinPoint.X + ex.MaxPoint.X) / 2.0,
                (ex.MinPoint.Y + ex.MaxPoint.Y) / 2.0,
                (ex.MinPoint.Z + ex.MaxPoint.Z) / 2.0
            );
        }

        private static double AngleBetweenDeg(Point3d p1, Point3d p2)
        {
            double dx = p2.X - p1.X;
            double dy = p2.Y - p1.Y;
            double ang = Math.Atan2(dy, dx) * 180.0 / Math.PI;
            return Math.Abs(ang);
        }

        private static double CurveLength(Curve c)
        {
            if (c is Polyline pl) return pl.Length;
            try
            {
                return c.GetDistanceAtParameter(c.EndParam);
            }
            catch
            {
                // best-effort
                return c.StartPoint.DistanceTo(c.EndPoint);
            }
        }

        /// <summary>
        /// LISP _mindist:
        /// - nếu intersect => 0
        /// - else sample N điểm trên curveA, lấy closestPoint trên curveB, min distance
        /// </summary>
        public static MinDistResult MinDistance(Curve curveA, Curve curveB, int div)
        {
            // intersect?
            try
            {
                var pts = new Point3dCollection();
                curveA.IntersectWith(curveB, Intersect.OnBothOperands, pts, IntPtr.Zero, IntPtr.Zero);
                if (pts.Count > 0)
                {
                    var p = pts[0];
                    return new MinDistResult(0.0, p, p, true);
                }
            }
            catch
            {
                // ignore intersection errors and continue sampling
            }

            double len = CurveLength(curveA);
            if (len <= 1e-12)
            {
                var pA = curveA.StartPoint;
                var pB = curveB.GetClosestPointTo(pA, false);
                return new MinDistResult(pA.DistanceTo(pB), pA, pB, true);
            }

            double best = double.MaxValue;
            Point3d bestP1 = Point3d.Origin;
            Point3d bestP2 = Point3d.Origin;

            int steps = Math.Max(10, div);
            for (int i = 0; i <= steps; i++)
            {
                double dist = len * i / steps;
                Point3d p1;
                try { p1 = curveA.GetPointAtDist(dist); }
                catch { continue; }

                Point3d p2;
                try { p2 = curveB.GetClosestPointTo(p1, false); }
                catch { continue; }

                double d = p1.DistanceTo(p2);
                if (d <= best)
                {
                    best = d;
                    bestP1 = p1;
                    bestP2 = p2;
                }
            }

            if (best == double.MaxValue)
                return new MinDistResult(0.0, Point3d.Origin, Point3d.Origin, false);

            return new MinDistResult(best, bestP1, bestP2, true);
        }
    }
}
