using System;
using System.Collections.Generic;
using Gssoft.Gscad.DatabaseServices;
using Gssoft.Gscad.EditorInput;

namespace LayoutMaterial.Services
{
    // Temporarily enables source layers only while the user makes the selection.
    // Every original Lock/Off/Freeze flag is restored before contour processing.
    internal sealed class CadSelectionLayerScope : IDisposable
    {
        private sealed class LayerState
        {
            internal ObjectId Id;
            internal bool IsOff;
            internal bool IsFrozen;
            internal bool IsLocked;
        }

        private readonly Database database;
        private readonly Editor editor;
        private readonly List<LayerState> states = new List<LayerState>();
        private bool disposed;

        internal CadSelectionLayerScope(Database db, Editor ed)
        {
            database = db ?? throw new ArgumentNullException(nameof(db));
            editor = ed ?? throw new ArgumentNullException(nameof(ed));
            try
            {
                using (var tr = database.TransactionManager.StartTransaction())
                {
                    var table = (LayerTable)tr.GetObject(database.LayerTableId, OpenMode.ForRead);
                    foreach (ObjectId id in table)
                    {
                        var layer = tr.GetObject(id, OpenMode.ForRead) as LayerTableRecord;
                        if (layer == null || layer.Name.IndexOf('|') >= 0) continue;
                        if (!layer.IsOff && !layer.IsFrozen && !layer.IsLocked) continue;
                        states.Add(new LayerState { Id = id, IsOff = layer.IsOff,
                            IsFrozen = layer.IsFrozen, IsLocked = layer.IsLocked });
                        layer.UpgradeOpen();
                        layer.IsOff = false;
                        layer.IsFrozen = false;
                        layer.IsLocked = false;
                    }
                    tr.Commit();
                }
                if (states.Count > 0) editor.Regen();
            }
            catch (System.Exception setupError)
            {
                try { Restore(); }
                catch (System.Exception restoreError)
                {
                    throw new InvalidOperationException(
                        "Layer selection setup failed and original layer states could not be fully restored.",
                        new AggregateException(setupError, restoreError));
                }
                throw;
            }
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            Restore();
        }

        private void Restore()
        {
            if (states.Count == 0) return;
            var errors = new List<string>();
            using (var tr = database.TransactionManager.StartTransaction())
            {
                foreach (LayerState state in states)
                {
                    try
                    {
                        if (!state.Id.IsValid || state.Id.IsErased) continue;
                        var layer = tr.GetObject(state.Id, OpenMode.ForWrite) as LayerTableRecord;
                        if (layer == null) continue;
                        layer.IsOff = state.IsOff;
                        layer.IsFrozen = state.IsFrozen;
                        layer.IsLocked = state.IsLocked;
                    }
                    catch (System.Exception ex)
                    {
                        errors.Add(state.Id.Handle.ToString() + ": " + ex.Message);
                    }
                }
                tr.Commit();
            }
            try { editor.Regen(); }
            catch (System.Exception ex) { errors.Add("REGEN: " + ex.Message); }
            states.Clear();
            if (errors.Count > 0)
                throw new InvalidOperationException("Cannot restore all original layer states: " +
                    string.Join("; ", errors.ToArray()));
        }
    }
}
