using System;
using System.Collections.Generic;
using System.Linq;
using Gssoft.Gscad.DatabaseServices;
using Gssoft.Gscad.EditorInput;
using Gssoft.Gscad.Geometry;
using LayoutMaterial.Commands;

namespace LayoutMaterial.Services
{
    // V82: read-only scan of the SELECTED PART GROUP for nested closed planar curves.
    // Holes do not change the packing silhouettes. Exact CAD curve areas are
    // used for efficiency; the sampled rings are ONLY for containment tests.
    internal static class CadHoleScanner
    {
        private sealed class Loop
        {
            internal ObjectId Id;
            internal List<Point2d> Polygon;
            internal double Area;
        }

        // V95: an invalid hole can invalidate ONE part's net area, not all
        // independent parts in the same selection. No guesswork on unknown area.
        internal static List<DlayoutMultiCommand.SourcePart> Scan(Database db,
            List<DlayoutMultiCommand.SourcePart> parts,
            Func<Polyline,double,List<Point2d>> tessellate,
            Func<Point2d,List<Point2d>,bool> inside,Editor ed)
        {
            var valid=new List<DlayoutMultiCommand.SourcePart>();
            using(var tr=db.TransactionManager.StartTransaction())
            {
                foreach(var source in parts)
                {
                    try
                    {
                        var loops=new List<Loop>();
                        foreach(ObjectId id in source.InnerContours)
                        {
                            Entity entity=tr.GetObject(id,OpenMode.ForRead) as Entity;
                            if(entity==null || entity.IsErased) continue;
                            List<Point2d> polygon=null;
                            double area=0;
                            if(entity is Polyline pl && pl.Closed)
                            {
                                // Two bulged vertices may describe a closed circular/curved hole.
                                // Validate the plane separately from the geometry.
                                if(Math.Abs(pl.Elevation)>=1e-6 ||
                                    Math.Abs(pl.Normal.X)>=1e-8 || Math.Abs(pl.Normal.Y)>=1e-8 ||
                                    Math.Abs(pl.Normal.Z-1)>=1e-8)
                                    throw new InvalidOperationException(Lang.T("GroupInvalidPlane"));
                                if(pl.NumberOfVertices<2)
                                    throw new InvalidOperationException(Lang.T("GroupInvalidGeometry"));
                                polygon=tessellate(pl,.005);
                                area=Math.Abs(pl.Area);
                            }
                            else if(entity is Polyline2d legacy2d && legacy2d.Closed)
                            {
                                polygon=CadSelectionGrouper.SampleLegacyClosedPolyline(legacy2d);
                                area=Math.Abs(DlayoutMultiCommand.Area(polygon));
                            }
                            else if(entity is Polyline3d legacy3d && legacy3d.Closed)
                            {
                                polygon=CadSelectionGrouper.SampleLegacyClosedPolyline(legacy3d);
                                area=Math.Abs(DlayoutMultiCommand.Area(polygon));
                            }
                            else if(entity is Circle c)
                            {
                                if(c.Radius<=0 || Math.Abs(c.Center.Z)>=1e-6 ||
                                    Math.Abs(c.Normal.X)>=1e-8 || Math.Abs(c.Normal.Y)>=1e-8 ||
                                    Math.Abs(c.Normal.Z-1)>=1e-8)
                                    throw new InvalidOperationException(Lang.T("GroupInvalidPlane"));
                                int n=Math.Max(48,(int)Math.Ceiling(Math.PI/
                                    Math.Acos(Math.Max(0,1-.005/c.Radius))));
                                if(n>2000) throw new InvalidOperationException(Lang.T("GroupTooDetailed"));
                                polygon=new List<Point2d>(n);
                                for(int i=0;i<n;i++) { double t=2*Math.PI*i/n;
                                    polygon.Add(new Point2d(c.Center.X+c.Radius*Math.Cos(t),
                                        c.Center.Y+c.Radius*Math.Sin(t))); }
                                area=Math.PI*c.Radius*c.Radius;
                            }
                            // Lines, open curves, text and dimensions belong to the
                            // selected rigid part but do not subtract area.
                            if(polygon==null) continue;
                            if(polygon.Count<3 || polygon.Count>2000 ||
                                double.IsNaN(area) || double.IsInfinity(area) || area<=1e-8)
                                throw new InvalidOperationException(Lang.T("GroupInvalidGeometry"));
                            if(area<source.GrossArea-1e-7 &&
                                StrictlyContains(source.Polygon,polygon,inside))
                                loops.Add(new Loop {Id=id,Polygon=polygon,Area=area});
                        }
                        double net=source.GrossArea;
                        foreach(var inner in loops)
                        {
                            int depth=loops.Count(other=>other!=inner &&
                                other.Area>inner.Area+1e-7 &&
                                StrictlyContains(other.Polygon,inner.Polygon,inside));
                            net+=depth%2==0 ? -inner.Area : inner.Area;
                        }
                        if(double.IsNaN(net) || double.IsInfinity(net) ||
                            net<=0 || net>source.GrossArea+1e-6)
                            throw new InvalidOperationException(Lang.T("GroupInvalidNetArea"));
                        source.NetArea=Math.Min(source.GrossArea,net);
                        ed.WriteMessage("\n[Dlayout] "+Lang.F("StripNetAreaLog",source.Handle,
                            loops.Count,source.NetArea.ToString("0.###",
                                System.Globalization.CultureInfo.InvariantCulture)));
                        valid.Add(source);
                    }
                    catch(System.Exception ex)
                    {
                        // Source is excluded entirely. Never set a guessed gross
                        // area in place of unreadable selected hole geometry.
                        ed.WriteMessage("\n"+Lang.F("GroupSkipDetail",source.Handle,
                            Lang.F("GroupHoleFailure",ex.Message)));
                    }
                }
                tr.Commit();
            }
            ed.WriteMessage("\n"+Lang.F("GroupFinalSummary",valid.Count,
                parts.Count-valid.Count));
            return valid;
        }

        private static bool StrictlyContains(List<Point2d> parent, List<Point2d> child,
            Func<Point2d, List<Point2d>, bool> inside)
        {
            // Check each vertex AND every edge midpoint. Disallow any segment
            // intersection: bounding boxes and vertices alone are insufficient
            // for concave CAD silhouettes.
            double minX = parent.Min(p => p.X), maxX = parent.Max(p => p.X);
            double minY = parent.Min(p => p.Y), maxY = parent.Max(p => p.Y);
            for (int i = 0; i < child.Count; i++)
            {
                Point2d a = child[i], b = child[(i + 1) % child.Count];
                if (a.X <= minX + 1e-7 || a.X >= maxX - 1e-7 ||
                    a.Y <= minY + 1e-7 || a.Y >= maxY - 1e-7 ||
                    !inside(a, parent) || !inside(new Point2d((a.X + b.X) / 2, (a.Y + b.Y) / 2), parent)) return false;
                for (int j = 0; j < parent.Count; j++)
                    if (Intersect(a, b, parent[j], parent[(j + 1) % parent.Count])) return false;
            }
            return true;
        }
        private static double Cross(Point2d a, Point2d b, Point2d c) =>
            (b.X - a.X) * (c.Y - a.Y) - (b.Y - a.Y) * (c.X - a.X);
        private static bool Intersect(Point2d a, Point2d b, Point2d c, Point2d d)
        {
            double ab1 = Cross(a, b, c), ab2 = Cross(a, b, d), cd1 = Cross(c, d, a), cd2 = Cross(c, d, b);
            return (ab1 * ab2 < 0 && cd1 * cd2 < 0) ||
                (Math.Abs(ab1) < 1e-8 && Between(a, b, c)) ||
                (Math.Abs(ab2) < 1e-8 && Between(a, b, d)) ||
                (Math.Abs(cd1) < 1e-8 && Between(c, d, a)) ||
                (Math.Abs(cd2) < 1e-8 && Between(c, d, b));
        }
        private static bool Between(Point2d a, Point2d b, Point2d p) =>
            p.X >= Math.Min(a.X, b.X) - 1e-8 && p.X <= Math.Max(a.X, b.X) + 1e-8 &&
            p.Y >= Math.Min(a.Y, b.Y) - 1e-8 && p.Y <= Math.Max(a.Y, b.Y) + 1e-8;
    }
}
