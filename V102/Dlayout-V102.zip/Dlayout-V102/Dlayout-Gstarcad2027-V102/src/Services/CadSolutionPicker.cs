using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Gssoft.Gscad.Geometry;
using LayoutMaterial.Commands;

namespace LayoutMaterial.Services
{
    // Lightweight reference image like the Desktop, with all CAD source curves
    // retained independently. This DOES NOT replace the true AutoCAD DrawJig
    // preview, which follows once the result and P/W have been selected.
    internal sealed class CadSolutionPicker : Form
    {
        private readonly List<DlayoutMultiCommand.CadSolution> all;
        private readonly List<DlayoutMultiCommand.CadSolution> shown = new List<DlayoutMultiCommand.CadSolution>();
        private readonly ListBox list = new ListBox();
        private readonly ComboBox sortMetric = new ComboBox();
        private readonly ComboBox sortDirection = new ComboBox();
        private readonly ComboBox searchMetric = new ComboBox();
        private readonly TextBox searchValue = new TextBox();
        private readonly Button findNearest = new Button();
        private readonly Button clearSearch = new Button();
        private readonly Label info = new Label();
        private readonly Canvas image = new Canvas();
        private readonly double bottomMargin;
        private readonly StripDisplaySettings display;
        private bool nearestSearchActive;
        private double nearestSearchTarget;
        internal DlayoutMultiCommand.CadSolution Selected { get; private set; }

        private sealed class Canvas : Panel
        {
            internal Action<Graphics,Rectangle> Render;
            internal Canvas() { DoubleBuffered = true; ResizeRedraw = true; BackColor = Color.FromArgb(32,36,44); }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                if(Render!=null) Render(e.Graphics,ClientRectangle);
            }
        }
        internal CadSolutionPicker(List<DlayoutMultiCommand.CadSolution> solutions, int defaultIndex, double bottom, StripDisplaySettings initialDisplay)
        {
            if (solutions == null || solutions.Count == 0) throw new ArgumentException("At least one CAD solution is required.", nameof(solutions));
            all = solutions; bottomMargin = bottom; display = initialDisplay.Copy();
            LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
            Text = Lang.T("SolutionsTitle");
            StartPosition=FormStartPosition.CenterParent;
            ClientSize=new Size(1050,680);
            MinimumSize=new Size(780,520);
            Font=new System.Drawing.Font("Segoe UI",9.5f);
            ShowInTaskbar=false;
            var left = new TableLayoutPanel { Dock=DockStyle.Left,Width=310,
                Padding=new Padding(10),ColumnCount=1,RowCount=4 };
            left.RowStyles.Add(new RowStyle(SizeType.Absolute,45));
            left.RowStyles.Add(new RowStyle(SizeType.Absolute,116));
            left.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            left.RowStyles.Add(new RowStyle(SizeType.Absolute,60));
            left.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            var right = new Panel { Dock=DockStyle.Fill,Padding=new Padding(9) };
            Controls.Add(right); Controls.Add(left);
            var header = new Label { Dock=DockStyle.Fill,
                Text=Lang.T("SolutionsHeader"),TextAlign=ContentAlignment.MiddleLeft };
            left.Controls.Add(header,0,0);

            var controls = new Panel { Dock=DockStyle.Fill };
            left.Controls.Add(controls,0,1);
            var sortRow = new Panel { Left=0,Top=0,Width=288,Height=34 };
            var sortLabel = new Label { Text=Lang.T("SolutionsSortBy"),TextAlign=ContentAlignment.MiddleLeft,
                Left=0,Top=3,Width=62,Height=28 };
            sortMetric.DropDownStyle=ComboBoxStyle.DropDownList;
            sortMetric.SetBounds(63,3,112,28);
            sortMetric.DropDownWidth=150;
            sortMetric.Items.AddRange(new object[] { Lang.T("SolutionsMetricAngle"),
                Lang.T("SolutionsMetricEfficiency"),Lang.T("SolutionsMetricPitch"),Lang.T("SolutionsMetricHeight") });
            sortDirection.DropDownStyle=ComboBoxStyle.DropDownList;
            sortDirection.SetBounds(180,3,105,28);
            sortDirection.DropDownWidth=130;
            sortDirection.Items.AddRange(new object[] { Lang.T("SolutionsDirectionAsc"),Lang.T("SolutionsDirectionDesc") });
            sortRow.Controls.Add(sortLabel);sortRow.Controls.Add(sortMetric);sortRow.Controls.Add(sortDirection);
            controls.Controls.Add(sortRow);

            var findRow = new Panel { Left=0,Top=37,Width=288,Height=34 };
            var findLabel = new Label { Text=Lang.T("SolutionsFindBy"),TextAlign=ContentAlignment.MiddleLeft,
                Left=0,Top=3,Width=62,Height=28 };
            searchMetric.DropDownStyle=ComboBoxStyle.DropDownList;
            searchMetric.SetBounds(63,3,222,28);
            searchMetric.DropDownWidth=220;
            searchMetric.Items.AddRange(new object[] { Lang.T("SolutionsMetricAngle"),
                Lang.T("SolutionsMetricEfficiency"),Lang.T("SolutionsMetricPitch"),Lang.T("SolutionsMetricHeight") });
            findRow.Controls.Add(findLabel);findRow.Controls.Add(searchMetric);
            controls.Controls.Add(findRow);

            var targetRow = new Panel { Left=0,Top=74,Width=288,Height=34 };
            var targetLabel = new Label { Text=Lang.T("SolutionsTarget"),TextAlign=ContentAlignment.MiddleLeft,
                Left=0,Top=3,Width=49,Height=28 };
            searchValue.SetBounds(50,3,64,28);
            searchValue.Text="0";
            findNearest.Text=Lang.T("SolutionsFindNearest");
            findNearest.SetBounds(118,2,94,30);
            clearSearch.Text=Lang.T("SolutionsClearSearch");
            clearSearch.SetBounds(216,2,69,30);
            clearSearch.Enabled=false;
            targetRow.Controls.Add(targetLabel);targetRow.Controls.Add(searchValue);
            targetRow.Controls.Add(findNearest);targetRow.Controls.Add(clearSearch);
            controls.Controls.Add(targetRow);

            list.Dock=DockStyle.Fill; list.IntegralHeight=false;
            left.Controls.Add(list,0,2);
            var footer=new Panel { Dock=DockStyle.Bottom,Height=60 };
            left.Controls.Add(footer,0,3);
            var choose=new Button { Text=Lang.T("SolutionsChoose"),Width=144,Height=37,Left=2,Top=10 };
            var cancel=new Button { Text=Lang.T("Cancel"),Width=112,Height=37,Left=157,Top=10,DialogResult=DialogResult.Cancel };
            choose.Click+=(s,e)=> { if(list.SelectedIndex>=0) { Selected=shown[list.SelectedIndex];DialogResult=DialogResult.OK;Close(); } };
            list.DoubleClick+=(s,e)=>choose.PerformClick();
            footer.Controls.Add(choose); footer.Controls.Add(cancel);
            AcceptButton=choose;CancelButton=cancel;
            info.Dock=DockStyle.Bottom; info.Height=92; info.TextAlign=ContentAlignment.MiddleLeft;
            image.Dock=DockStyle.Fill;
            image.Render=Render;
            right.Controls.Add(image);right.Controls.Add(info);
            list.SelectedIndexChanged+=(s,e)=>RefreshSelection();

            // Default to the usual high-efficiency ranking, while keeping all four
            // metrics and both directions directly available at solution selection.
            sortMetric.SelectedIndex=1;
            sortDirection.SelectedIndex=1;
            searchMetric.SelectedIndex=1;
            Reload(false);
            var initial=all[Math.Max(0,Math.Min(defaultIndex,all.Count-1))];
            int n=shown.FindIndex(s=>ReferenceEquals(s,initial));
            list.SelectedIndex=n>=0?n:0;

            sortMetric.SelectedIndexChanged+=(s,e)=> { if(!nearestSearchActive) Reload(false); };
            sortDirection.SelectedIndexChanged+=(s,e)=> { if(!nearestSearchActive) Reload(false); };
            searchMetric.SelectedIndexChanged+=(s,e)=> { if(nearestSearchActive) Reload(true); };
            findNearest.Click+=(s,e)=>ApplyNearestSearch();
            clearSearch.Click+=(s,e)=>ClearNearestSearch();
            searchValue.KeyDown+=(s,e)=> { if(e.KeyCode==Keys.Enter) { e.SuppressKeyPress=true;ApplyNearestSearch(); } };
        }
        private static bool IsFinite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
        private static double Efficiency(DlayoutMultiCommand.CadSolution s)
        {
            double area=s.Placements.Sum(p=>p.Source.NetArea);
            double denominator=s.Pitch*s.Width;
            return denominator>0 && IsFinite(denominator) ? area/denominator*100 : double.NaN;
        }
        private static double MetricValue(DlayoutMultiCommand.CadSolution s,int metric)
        {
            switch(metric)
            {
                case 0: return s.RelativeAngle;
                case 1: return Efficiency(s);
                case 2: return s.Pitch;
                case 3: return s.Width;
                default: return double.NaN;
            }
        }
        private static bool TryParseTarget(string raw,out double value)
        {
            return (double.TryParse(raw,NumberStyles.Float,CultureInfo.CurrentCulture,out value) ||
                double.TryParse(raw,NumberStyles.Float,CultureInfo.InvariantCulture,out value)) && IsFinite(value);
        }
        private void ApplyNearestSearch()
        {
            if(searchMetric.SelectedIndex<0)return;
            double target;
            if(!TryParseTarget(searchValue.Text,out target))
            {
                MessageBox.Show(this,Lang.T("SolutionsSearchInvalid"),Text,MessageBoxButtons.OK,MessageBoxIcon.Warning);
                searchValue.Focus();searchValue.SelectAll();return;
            }
            if(searchMetric.SelectedIndex==0 && all.All(s=>!IsFinite(s.RelativeAngle)))
            {
                MessageBox.Show(this,Lang.T("SolutionsAngleMissing"),Text,MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            nearestSearchTarget=target;
            nearestSearchActive=true;
            sortMetric.Enabled=false;sortDirection.Enabled=false;clearSearch.Enabled=true;
            Reload(true);
        }
        private void ClearNearestSearch()
        {
            nearestSearchActive=false;
            sortMetric.Enabled=true;sortDirection.Enabled=true;clearSearch.Enabled=false;
            Reload(false);
        }
        private void Reload(bool selectNearestFirst)
        {
            var old = list.SelectedIndex>=0 && list.SelectedIndex<shown.Count ? shown[list.SelectedIndex] : null;
            shown.Clear();shown.AddRange(all);
            int metric=nearestSearchActive?searchMetric.SelectedIndex:sortMetric.SelectedIndex;
            if(nearestSearchActive)
            {
                shown.Sort((a,b)=>
                {
                    double av=MetricValue(a,metric),bv=MetricValue(b,metric);
                    double ad=IsFinite(av)?Math.Abs(av-nearestSearchTarget):double.PositiveInfinity;
                    double bd=IsFinite(bv)?Math.Abs(bv-nearestSearchTarget):double.PositiveInfinity;
                    int c=ad.CompareTo(bd);
                    return c!=0?c:a.OriginalIndex.CompareTo(b.OriginalIndex);
                });
            }
            else
            {
                bool descending=sortDirection.SelectedIndex==1;
                shown.Sort((a,b)=>
                {
                    double av=MetricValue(a,metric),bv=MetricValue(b,metric);
                    bool aValid=IsFinite(av),bValid=IsFinite(bv);
                    if(aValid!=bValid)return aValid?-1:1; // unavailable metrics always last
                    if(!aValid)return a.OriginalIndex.CompareTo(b.OriginalIndex);
                    int c=av.CompareTo(bv);
                    if(descending)c=-c;
                    return c!=0?c:a.OriginalIndex.CompareTo(b.OriginalIndex);
                });
            }
            list.BeginUpdate();
            try
            {
                list.Items.Clear();
                foreach(var s in shown)
                {
                    string angle=IsFinite(s.RelativeAngle)?"φ="+s.RelativeAngle.ToString("0.###",CultureInfo.InvariantCulture)+"°":"φ=N/A";
                    list.Items.Add("#"+(s.OriginalIndex+1).ToString("000",CultureInfo.InvariantCulture)+
                        "  "+angle+"  η="+Efficiency(s).ToString("0.##",CultureInfo.InvariantCulture)+"%"+
                        "  P="+s.Pitch.ToString("0.###",CultureInfo.InvariantCulture)+
                        "  W="+s.Width.ToString("0.###",CultureInfo.InvariantCulture));
                }
            }
            finally { list.EndUpdate(); }
            if(shown.Count>0)
            {
                int index=selectNearestFirst&&nearestSearchActive?0:
                    old==null?0:shown.FindIndex(s=>ReferenceEquals(s,old));
                list.SelectedIndex=index>=0?index:0;
            }
        }
        private void RefreshSelection()
        {
            if(list.SelectedIndex<0 || list.SelectedIndex>=shown.Count)return;
            var s=shown[list.SelectedIndex];
            string angle=IsFinite(s.RelativeAngle)?s.RelativeAngle.ToString("0.####",CultureInfo.InvariantCulture)+"°":"N/A";
            info.Text=Lang.F("SolutionsInfo", s.OriginalIndex+1, all.Count,
                s.Pitch.ToString("0.####",CultureInfo.InvariantCulture),
                s.Width.ToString("0.####",CultureInfo.InvariantCulture),
                Efficiency(s).ToString("0.##",CultureInfo.InvariantCulture),angle);
            image.Invalidate();
        }
        private static Point2d Transform(Point2d pt,DlayoutMultiCommand.Placement place,int cycle,double pitch)
        {
            double a=place.Angle*Math.PI/180.0,cos=Math.Cos(a),sin=Math.Sin(a);
            double x=pt.X-place.Source.Center.X,y=pt.Y-place.Source.Center.Y;
            return new Point2d(place.Center.X+x*cos-y*sin+pitch*cycle,
                place.Center.Y+x*sin+y*cos);
        }
        private void Render(Graphics g,Rectangle area)
        {
            g.SmoothingMode=SmoothingMode.AntiAlias;
            if(list.SelectedIndex<0 || list.SelectedIndex>=shown.Count) return;
            var s=shown[list.SelectedIndex];
            double minX=double.PositiveInfinity,maxX=double.NegativeInfinity;
            double minY=double.PositiveInfinity,maxY=double.NegativeInfinity;
            foreach(var p in s.Placements)
                foreach(var q in p.Source.Polygon)
                {
                    var pt=Transform(q,p,0,s.Pitch);
                    minX=Math.Min(minX,pt.X);maxX=Math.Max(maxX,pt.X);
                    minY=Math.Min(minY,pt.Y);maxY=Math.Max(maxY,pt.Y);
                }
            double minStripY=minY-bottomMargin;
            double low=minStripY,high=low+s.Width;
            maxX+=(display.Steps-1)*s.Pitch;
            double spanX=Math.Max(1e-6,maxX-minX),spanY=Math.Max(1e-6,high-low);
            double sizeX=Math.Max(1,area.Width-50),sizeY=Math.Max(1,area.Height-45);
            double scale=Math.Min(sizeX/spanX,sizeY/spanY);
            double x0=area.Left+(area.Width-spanX*scale)/2;
            double y0=area.Top+(area.Height-spanY*scale)/2;
            PointF Project(Point2d p)=>new PointF((float)(x0+(p.X-minX)*scale),
                (float)(y0+(high-p.Y)*scale));
            using(var edge=new Pen(Color.FromArgb(150,173,184),1))
            {
                var a=Project(new Point2d(minX,low));var b=Project(new Point2d(maxX,low));
                g.DrawLine(edge,a,b);
                a=Project(new Point2d(minX,high));b=Project(new Point2d(maxX,high));g.DrawLine(edge,a,b);
            }
            // The picker is a shape comparison, not the final CAD-entity preview.
            // The final DrawJig uses each original CAD entity, its source colors
            // and all attached curves exactly as they will be committed.
            var partOrdinal = new Dictionary<DlayoutMultiCommand.SourcePart, int>();
            foreach (var p in s.Placements)
                if (!partOrdinal.ContainsKey(p.Source))
                    partOrdinal.Add(p.Source, partOrdinal.Count);
            for(int cycle=0; cycle<display.Steps; cycle++)
            {
                foreach(var p in s.Placements)
                {
                    Color stroke = display.ColorMode == StripColorMode.ByStation
                        ? StripAciPalette.Preview(StripAciPalette.ForIndex(cycle))
                        : display.ColorMode == StripColorMode.ByPart
                            ? StripAciPalette.Preview(StripAciPalette.ForIndex(partOrdinal[p.Source]))
                            : Color.FromArgb(185, 194, 207); // Illustrative only for source colors.
                    Color fill = Color.FromArgb(37,stroke.R,stroke.G,stroke.B);
                    using(var pen=new Pen(stroke,1.7f))
                    using(var brush=new SolidBrush(fill))
                    {
                        PointF[] ring=p.Source.Polygon.Select(q=>Project(Transform(q,p,cycle,s.Pitch))).ToArray();
                        if(ring.Length>=3) {g.FillPolygon(brush,ring);g.DrawPolygon(pen,ring);}
                        foreach(var extra in p.Source.PreviewExtras)
                        {
                            PointF[] pts=extra.Select(q=>Project(Transform(q,p,cycle,s.Pitch))).ToArray();
                            if(pts.Length>=2)g.DrawLines(pen,pts);
                            else if(pts.Length==1)g.DrawEllipse(pen,pts[0].X-2,pts[0].Y-2,4,4);
                        }
                    }
                }
            }
        }
    }
}
