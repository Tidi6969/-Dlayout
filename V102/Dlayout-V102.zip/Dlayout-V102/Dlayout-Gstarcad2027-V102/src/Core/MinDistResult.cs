using Gssoft.Gscad.Geometry;

namespace LayoutMaterial.Services
{
    public readonly struct MinDistResult
    {
        public MinDistResult(double distance, Point3d p1, Point3d p2, bool hasPoints)
        {
            Distance = distance;
            P1 = p1;
            P2 = p2;
            HasPoints = hasPoints;
        }

        public double Distance { get; }
        public Point3d P1 { get; }
        public Point3d P2 { get; }
        public bool HasPoints { get; }
    }
}
