using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Gssoft.Gscad.ApplicationServices;

namespace LayoutMaterial
{
    /// <summary>
    /// DCAD runtime path resolver.
    /// Source of truth is the current CAD profile Support File Search Path.
    /// Find operations never create folders/files and never infer sibling DCAD folders.
    /// </summary>
    internal static class RuntimeDataResolver
    {
        private static readonly string[] KnownFolders = { "DData", "DUser", "DProgram", "DHelp", "Dicon" };

        internal static List<string> FindAllFilesInNamedFolder(string folderName, string fileName)
        {
            RequireKnownFolder(folderName);
            RequireFileNameOnly(fileName);
            var result = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string folder in GetNamedFolders(folderName))
            {
                string found = FindCaseInsensitiveFile(folder, fileName);
                if (!string.IsNullOrWhiteSpace(found) && seen.Add(found)) result.Add(found);
            }
            return result;
        }

        internal static string FindFileInNamedFolder(string folderName, string fileName)
        {
            List<string> found = FindAllFilesInNamedFolder(folderName, fileName);
            return found.Count == 0 ? null : found[0];
        }

        internal static string ResolveExistingDUserDestination(string fileName)
        {
            RequireFileNameOnly(fileName);
            List<string> dirs = GetNamedFolders("DUser");
            if (dirs.Count == 0)
                throw new InvalidOperationException("USER_FOLDER_NOT_CONFIGURED: register the DUser directory itself in CAD Options > Files > Support File Search Path. Parent registrations are not accepted.");
            if (dirs.Count > 1)
                throw new InvalidOperationException("USER_FOLDER_AMBIGUOUS: multiple DUser folders are registered: " + string.Join("; ", dirs.ToArray()));
            return Path.Combine(dirs[0], fileName);
        }

        internal static string SupportPathDiagnostic()
        {
            try { return string.Join("; ", GetRegisteredSupportPaths().ToArray()); }
            catch (Exception ex) { return "<unavailable: " + ex.Message + ">"; }
        }

        internal static IList<string> GetSupportPaths() { return GetRegisteredSupportPaths(); }
        internal static void ClearRuntimePathCache() { /* Resolve the active CAD profile on every command. */ }
        internal static string FindNamedFolder(string folderName, bool createIfMissing)
        {
            // Find NEVER creates, irrespective of legacy callers.
            List<string> folders = GetNamedFolders(folderName);
            if (folders.Count > 1) throw new InvalidOperationException(
                "MULTIPLE_DIRECT_FOLDERS: " + folderName + ": " + string.Join("; ", folders.ToArray()));
            return folders.FirstOrDefault();
        }
        internal static string FindPrimaryDUserFolder()
        {
            // A write destination must be unique: never guess among multiple profiles.
            List<string> dirs = GetNamedFolders("DUser");
            if (dirs.Count == 0) return null;
            if (dirs.Count > 1) throw new InvalidOperationException(
                "USER_FOLDER_AMBIGUOUS: " + string.Join("; ", dirs.ToArray()));
            return dirs[0];
        }
        internal static string DescribeSearch() { return SupportPathDiagnostic(); }

        // DCAD-DATA-DIR-001 V1.6: ONLY the logical directory itself may be
        // registered in the current CAD profile. Never inspect P\DUser or
        // a sibling directory just because P occurs in Support Search Path.
        private static List<string> GetNamedFolders(string folderName)
        {
            RequireKnownFolder(folderName);
            string raw = ReadSupportPathText();
            if (string.IsNullOrWhiteSpace(raw))
                throw new InvalidOperationException("PATH_SOURCE_UNAVAILABLE: CAD Support File Search Path could not be read.");
            var result = new List<string>();
            var details = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            int index = 0;
            foreach (string entry in raw.Split(new[] { ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                ++index; // One-based SupportPathIndex from the CAD profile.
                string path = NormalizeAbsoluteDirectory(entry);
                if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path) ||
                    !string.Equals(SafeFileName(path), folderName, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (!seen.Add(path)) continue;
                result.Add(path);
                details.Add("[" + index + "] " + path);
            }
            if (result.Count > 1)
                throw new InvalidOperationException(
                    (string.Equals(folderName, "DUser", StringComparison.OrdinalIgnoreCase)
                        ? "USER_FOLDER_AMBIGUOUS" : "FOLDER_AMBIGUOUS") +
                    ": multiple DIRECT " + folderName + " entries in CAD Support File Search Path: " +
                    string.Join("; ", details.ToArray()));
            return result;
        }

        private static List<string> GetRegisteredSupportPaths()
        {
            string supportText = ReadSupportPathText();
            if (string.IsNullOrWhiteSpace(supportText))
                throw new InvalidOperationException("PATH_SOURCE_UNAVAILABLE: CAD Support File Search Path is empty or cannot be read.");

            var result = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string raw in supportText.Split(new[] { ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string path = NormalizeAbsoluteDirectory(raw);
                if (string.IsNullOrWhiteSpace(path) || !Directory.Exists(path) || !seen.Add(path)) continue;
                result.Add(path);
            }
            if (result.Count == 0)
                throw new InvalidOperationException("PATH_SOURCE_UNAVAILABLE: CAD returned no valid existing Support File Search Path entries.");
            return result;
        }

        private static string ReadSupportPathText()
        {
            // AutoCAD: ACADPREFIX is the current profile Support File Search Path source.
            try
            {
                string text = Convert.ToString(Application.GetSystemVariable("ACADPREFIX"));
                if (!string.IsNullOrWhiteSpace(text)) return text;
            }
            catch { }

            // Verified fallback: AutoCAD Preferences.Files.SupportPath.
            string com = ReadComSupportPath();
            return string.IsNullOrWhiteSpace(com) ? string.Empty : com;
        }

        private static string ReadComSupportPath()
        {
            try
            {
                PropertyInfo appProperty = typeof(Application).GetProperty("AcadApplication", BindingFlags.Public | BindingFlags.Static);
                object app = appProperty == null ? null : appProperty.GetValue(null, null);
                if (app == null) return null;
                object preferences = app.GetType().InvokeMember("Preferences", BindingFlags.GetProperty, null, app, null);
                object files = preferences == null ? null : preferences.GetType().InvokeMember("Files", BindingFlags.GetProperty, null, preferences, null);
                object supportPath = files == null ? null : files.GetType().InvokeMember("SupportPath", BindingFlags.GetProperty, null, files, null);
                string text = Convert.ToString(supportPath);
                return string.IsNullOrWhiteSpace(text) ? null : text;
            }
            catch { return null; }
        }

        private static string FindCaseInsensitiveFile(string folder, string fileName)
        {
            string direct = Path.Combine(folder, fileName);
            if (File.Exists(direct)) return direct;
            return Directory.GetFiles(folder).FirstOrDefault(path =>
                string.Equals(Path.GetFileName(path), fileName, StringComparison.OrdinalIgnoreCase));
        }

        private static string NormalizeAbsoluteDirectory(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return null;
            string value = raw.Trim();
            if (value.Length >= 2 && value[0] == '"' && value[value.Length - 1] == '"')
                value = value.Substring(1, value.Length - 2);
            try { value = Environment.ExpandEnvironmentVariables(value); } catch { return null; }
            if (!Path.IsPathRooted(value)) return null;
            try
            {
                string full = Path.GetFullPath(value).Replace('/', '\\');
                string driveRoot = Path.GetPathRoot(full);
                return string.Equals(full, driveRoot, StringComparison.OrdinalIgnoreCase)
                    ? full
                    : full.TrimEnd('\\', '/');
            }
            catch { return null; }
        }

        private static void RequireKnownFolder(string folderName)
        {
            if (!IsKnownFolder(folderName))
                throw new ArgumentException("UNKNOWN_LOGICAL_FOLDER: " + (folderName ?? "<null>"), "folderName");
        }

        private static void RequireFileNameOnly(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName) || fileName == "." || fileName == ".." ||
                !string.Equals(Path.GetFileName(fileName), fileName, StringComparison.Ordinal) ||
                fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                throw new ArgumentException("FILE_NAME_ONLY_REQUIRED", "fileName");
        }

        private static void RequireSimplePathSegment(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value == "." || value == ".." ||
                value.IndexOf('\\') >= 0 || value.IndexOf('/') >= 0 || value.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
                throw new ArgumentException("INVALID_PROGRAM_PATH_SEGMENT: " + (value ?? "<null>"));
        }

        private static bool IsKnownFolder(string value)
        {
            return KnownFolders.Any(folder => string.Equals(folder, value, StringComparison.OrdinalIgnoreCase));
        }

        private static string SafeFileName(string path)
        {
            try { return Path.GetFileName((path ?? string.Empty).TrimEnd('\\', '/')); }
            catch { return string.Empty; }
        }
    }
}
