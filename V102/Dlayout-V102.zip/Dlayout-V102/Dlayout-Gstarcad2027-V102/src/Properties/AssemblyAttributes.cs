using Gssoft.Gscad.Runtime;

[assembly: CommandClass(typeof(LayoutMaterial.Commands.DlayoutMultiCommand))]
