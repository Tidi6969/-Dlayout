@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "NO_PAUSE=0"
if /I "%~1"=="/nopause" set "NO_PAUSE=1"
if not exist "log" mkdir "log" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Buildtime\Build_Release.ps1"
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" if not exist "bin\DlayoutG27.dll" set "RC=1"
if "%RC%"=="0" (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[PASS] GstarCAD 2027 V102 - bin\DlayoutG27.dll' -ForegroundColor Green"
) else (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[FAIL] GstarCAD 2027 V102 - see log\Build-V102.log' -ForegroundColor Red"
)
if "%NO_PAUSE%"=="0" (
    echo Nhan phim bat ky de thoat... / Press any key to close this window...
    pause >nul
)
endlocal & exit /b %RC%
