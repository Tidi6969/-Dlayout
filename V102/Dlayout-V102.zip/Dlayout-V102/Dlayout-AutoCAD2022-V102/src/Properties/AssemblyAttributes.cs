using Autodesk.AutoCAD.Runtime;

[assembly: CommandClass(typeof(LayoutMaterial.Commands.DlayoutMultiCommand))]
