using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;

namespace LayoutMaterial.Commands
{
    // Matches DNest V38: launch shared Desktop at CAD command start,
    // send one absolute Job path through a per-session named pipe.
    internal sealed class DlayoutPreloadSession : IDisposable
    {
        private const string PipePrefix = "DCAD_Dlayout_";
        private readonly string pipeName;
        private bool dispatched;
        private bool disposed;
        public Process DesktopProcess { get; private set; }

        private DlayoutPreloadSession(Process process, string name)
        {
            DesktopProcess = process;
            pipeName = name;
        }

        public static DlayoutPreloadSession Start(string exe, int languageIndex)
        {
            if (string.IsNullOrWhiteSpace(exe) || !File.Exists(exe))
                throw new FileNotFoundException("Dlayout Desktop missing", exe);
            string id = Guid.NewGuid().ToString("N");
            long hwnd = ResolveCadMainWindow().ToInt64();
            var info = new ProcessStartInfo {
                FileName = exe,
                Arguments = "--preload-session " + id
                    + " --cad-owner-hwnd " + hwnd.ToString(CultureInfo.InvariantCulture)
                    + " --language-index " + languageIndex.ToString(CultureInfo.InvariantCulture),
                WorkingDirectory = Path.GetDirectoryName(exe),
                UseShellExecute = false,
                CreateNoWindow = true
            };
            Process process = Process.Start(info);
            if (process == null) throw new InvalidOperationException("Could not start Dlayout Desktop.");
            return new DlayoutPreloadSession(process, PipePrefix + id);
        }

        public void SendJob(string jobPath)
        {
            if (disposed) throw new ObjectDisposedException(nameof(DlayoutPreloadSession));
            if (string.IsNullOrWhiteSpace(jobPath) || !File.Exists(jobPath))
                throw new FileNotFoundException("Dlayout CAD Job missing", jobPath);
            string payload = Convert.ToBase64String(Encoding.UTF8.GetBytes(Path.GetFullPath(jobPath)));
            SendLine("JOB " + payload, 15000);
            dispatched = true;
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            if (dispatched) return;
            try { SendLine("CANCEL", 1000); } catch { }
            try {
                if (!DesktopProcess.HasExited && !DesktopProcess.WaitForExit(1800)) DesktopProcess.Kill();
            } catch { }
        }

        private void SendLine(string line, int timeout)
        {
            using (var client = new NamedPipeClientStream(".", pipeName, PipeDirection.Out))
            {
                client.Connect(timeout);
                using (var writer = new StreamWriter(client, new UTF8Encoding(false), 4096, true))
                {
                    writer.AutoFlush = true;
                    writer.WriteLine(line);
                }
            }
        }

        private static IntPtr ResolveCadMainWindow()
        {
            try {
                using (Process current = Process.GetCurrentProcess())
                {
                    if (current.MainWindowHandle != IntPtr.Zero) return current.MainWindowHandle;
                    IntPtr foreground = GetForegroundWindow();
                    if (foreground != IntPtr.Zero)
                    {
                        uint pid;
                        GetWindowThreadProcessId(foreground, out pid);
                        if (pid == (uint)current.Id) return foreground;
                    }
                }
            } catch { }
            return IntPtr.Zero;
        }

        [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr handle, out uint processId);
    }
}
