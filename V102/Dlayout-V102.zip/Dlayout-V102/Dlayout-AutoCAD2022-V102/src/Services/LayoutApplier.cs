using System;
using System.Collections.Generic;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.GraphicsInterface;
using LayoutMaterial.Models;

namespace LayoutMaterial.Services
{
    public sealed class LayoutApplier
    {
        public void Apply(Editor ed, Database db, LayoutSettings s)
        {
            if (s.StationNo < 1) s.StationNo = 1;

            // select objects
            var psr = ed.GetSelection();
            if (psr.Status != PromptStatus.OK || psr.Value == null) return;
            var ss = psr.Value;

            using (var tr = db.TransactionManager.StartTransaction())
            {
                var space = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);

                // collect original ids
                var ids = new List<ObjectId>(ss.Count);
                foreach (SelectedObject so in ss)
                {
                    if (so != null && so.ObjectId.IsValid) ids.Add(so.ObjectId);
                }
                if (ids.Count == 0) { tr.Commit(); return; }

                // compute bb + center
                var bb = SelectionExtents(tr, ids);
                var center = CenterOf(bb);

                EnsureMaterLayer(tr, db);

                // rotate all selected around center and move originals to layer MATER only
                var rotMat = Matrix3d.Rotation(s.RotateDeg * Math.PI / 180.0, Vector3d.ZAxis, center);
                foreach (var id in ids)
                {
                    if (!id.IsValid) continue;
                    var ent = (Entity)tr.GetObject(id, OpenMode.ForWrite, false);
                    ent.TransformBy(rotMat);
                    ent.Layer = "MATER";
                }

                // copy stations 2..n
                int dir = (s.Feed == "Rg-to-Lft") ? -1 : 1;
                var allIds = new List<ObjectId>(ids);

                for (int i = 2; i <= s.StationNo; i++)
                {
                    double dx = dir * s.Pitch * (i - 1);
                    var disp = Matrix3d.Displacement(new Vector3d(dx, 0, 0));

                    foreach (var id in ids)
                    {
                        var ent = (Entity)tr.GetObject(id, OpenMode.ForRead, false);
                        var clone = (Entity)ent.Clone();
                        clone.TransformBy(disp);
                        clone.Layer = "MATER";
                        space.AppendEntity(clone);
                        tr.AddNewlyCreatedDBObject(clone, true);
                        allIds.Add(clone.ObjectId);
                    }
                }

                // union bb of all
                var bbAll = SelectionExtents(tr, allIds);

                // draw strip lines on layer MATER according to Parallel Line options
                DrawParallelLines(tr, space, bbAll, s.Upper, s.Lower, s.XLineParallel, s.YLineParallel);

                tr.Commit();
            }

            if (!s.CreateInformation) return;

            using (var tr = db.TransactionManager.StartTransaction())
            {
                EnsureMaterLayer(tr, db);
                // Use the active TextStyle from the current drawing, never create a private Arial style.
                var textStyleId = db.Textstyle;
                var lines = BuildInformationLines(s);
                var jig = new InfoTextJig(textStyleId, lines, 2.5, "\n" + Lang.T("PickInfoInsertPoint"));
                var dragRes = ed.Drag(jig);
                if (dragRes.Status != PromptStatus.OK)
                {
                    tr.Commit();
                    return;
                }

                var space = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);
                AppendInformationText(tr, space, jig.Position, textStyleId, lines, 2.5);
                tr.Commit();
            }
        }

        private static Extents3d SelectionExtents(Transaction tr, List<ObjectId> ids)
        {
            bool has = false;
            Extents3d ex = default;

            foreach (var id in ids)
            {
                if (!id.IsValid) continue;
                var ent = tr.GetObject(id, OpenMode.ForRead, false) as Entity;
                if (ent == null) continue;

                Extents3d eex;
                try { eex = ent.GeometricExtents; }
                catch { continue; }

                if (!has)
                {
                    ex = eex;
                    has = true;
                }
                else
                {
                    ex.AddExtents(eex);
                }
            }

            if (!has)
                ex = new Extents3d(new Point3d(0, 0, 0), new Point3d(0, 0, 0));

            return ex;
        }

        private static Point3d CenterOf(Extents3d ex)
            => new Point3d((ex.MinPoint.X + ex.MaxPoint.X) / 2.0, (ex.MinPoint.Y + ex.MaxPoint.Y) / 2.0, 0);

        private static void EnsureMaterLayer(Transaction tr, Database db)
        {
            var lt = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (lt.Has("MATER")) return;

            lt.UpgradeOpen();
            var ltr = new LayerTableRecord
            {
                Name = "MATER"
            };
            lt.Add(ltr);
            tr.AddNewlyCreatedDBObject(ltr, true);
        }

        private static void DrawParallelLines(Transaction tr, BlockTableRecord space, Extents3d ex, double upper, double lower, bool drawX, bool drawY)
        {
            if (!drawX && !drawY) return;

            double xmin = ex.MinPoint.X;
            double xmax = ex.MaxPoint.X;
            double ymin = ex.MinPoint.Y;
            double ymax = ex.MaxPoint.Y;

            if (drawX)
            {
                double width = Math.Abs(xmax - xmin);
                double extX = width * 0.05; // 5%
                double x1 = xmin - extX;
                double x2 = xmax + extX;

                // For X-parallel lines: Upper = top offset, Lower = bottom offset.
                double yTop = ymax + upper;
                double yBot = ymin - lower;

                var l1 = new Line(new Point3d(x1, yTop, 0), new Point3d(x2, yTop, 0)) { Layer = "MATER", ColorIndex = 256, Linetype = "ByLayer" };
                var l2 = new Line(new Point3d(x1, yBot, 0), new Point3d(x2, yBot, 0)) { Layer = "MATER", ColorIndex = 256, Linetype = "ByLayer" };

                space.AppendEntity(l1);
                tr.AddNewlyCreatedDBObject(l1, true);

                space.AppendEntity(l2);
                tr.AddNewlyCreatedDBObject(l2, true);
            }

            if (drawY)
            {
                double height = Math.Abs(ymax - ymin);
                double extY = height * 0.05; // 5%
                double y1 = ymin - extY;
                double y2 = ymax + extY;

                // For Y-parallel lines: Upper = left offset, Lower = right offset.
                double xLeft = xmin - upper;
                double xRight = xmax + lower;

                var l3 = new Line(new Point3d(xLeft, y1, 0), new Point3d(xLeft, y2, 0)) { Layer = "MATER", ColorIndex = 256, Linetype = "ByLayer" };
                var l4 = new Line(new Point3d(xRight, y1, 0), new Point3d(xRight, y2, 0)) { Layer = "MATER", ColorIndex = 256, Linetype = "ByLayer" };

                space.AppendEntity(l3);
                tr.AddNewlyCreatedDBObject(l3, true);

                space.AppendEntity(l4);
                tr.AddNewlyCreatedDBObject(l4, true);
            }
        }
        private static string[] BuildInformationLines(LayoutSettings s)
        {
            string materialValue = string.IsNullOrWhiteSpace(s.Material) ? "..." : s.Material.Trim();
            string thicknessText = NumericFormat.FormatUpTo(s.Thickness, NumericFormat.CalculatorDecimals);
            string widthText = NumericFormat.FormatUpTo(s.MaterWidth, NumericFormat.CalculatorDecimals);
            string pitchText = NumericFormat.FormatUpTo(s.Pitch, NumericFormat.CalculatorDecimals);
            string rateText = NumericFormat.RoundTo(s.Rate, 1).ToString("0.0", System.Globalization.CultureInfo.InvariantCulture);

            return new[]
            {
                Lang.F("InfoLine1", materialValue),
                Lang.F("InfoLine2", thicknessText, widthText, pitchText),
                Lang.F("InfoLine3", rateText)
            };
        }

        private static void AppendInformationText(Transaction tr, BlockTableRecord space, Point3d insertionPoint, ObjectId textStyleId, string[] lines, double textHeight)
        {
            double gap = textHeight * 1.35;
            for (int i = 0; i < lines.Length; i++)
            {
                var pos = new Point3d(insertionPoint.X, insertionPoint.Y - gap * i, 0.0);
                var txt = CreateInfoText(lines[i], pos, textHeight, textStyleId);
                space.AppendEntity(txt);
                tr.AddNewlyCreatedDBObject(txt, true);
            }
        }

        private sealed class InfoTextJig : DrawJig
        {
            private readonly ObjectId _textStyleId;
            private readonly string[] _lines;
            private readonly double _textHeight;
            private readonly string _message;
            private Point3d _position;

            public InfoTextJig(ObjectId textStyleId, string[] lines, double textHeight, string message)
            {
                _textStyleId = textStyleId;
                _lines = lines;
                _textHeight = textHeight;
                _message = message;
                _position = Point3d.Origin;
            }

            public Point3d Position => _position;

            protected override SamplerStatus Sampler(JigPrompts prompts)
            {
                var opts = new JigPromptPointOptions(_message)
                {
                    UserInputControls = UserInputControls.Accept3dCoordinates | UserInputControls.NoZeroResponseAccepted
                };

                var res = prompts.AcquirePoint(opts);
                if (res.Status != PromptStatus.OK)
                    return SamplerStatus.Cancel;
                if (res.Value.IsEqualTo(_position))
                    return SamplerStatus.NoChange;

                _position = res.Value;
                return SamplerStatus.OK;
            }

            protected override bool WorldDraw(WorldDraw draw)
            {
                double gap = _textHeight * 1.35;
                for (int i = 0; i < _lines.Length; i++)
                {
                    using (var txt = CreateInfoText(_lines[i], new Point3d(_position.X, _position.Y - gap * i, 0.0), _textHeight, _textStyleId))
                    {
                        draw.Geometry.Draw(txt);
                    }
                }
                return true;
            }
        }

        private static DBText CreateInfoText(string value, Point3d position, double textHeight, ObjectId textStyleId)
        {
            return new DBText
            {
                Position = position,
                Height = textHeight,
                TextString = value,
                Layer = "MATER",
                TextStyleId = textStyleId,
                ColorIndex = 256,
                Linetype = "ByLayer"
            };
        }

    }
}
