using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using LayoutMaterial.Models;

namespace LayoutMaterial.Services
{
    // One persistent settings file for CAD and Desktop: DUser\\Dlayout_settings.ini.
    // DUser must be DIRECT-registered; never inspect AppData or Layout_material data.
    internal static class DlayoutSettingsStore
    {
        internal const string FileName = "Dlayout_settings.ini";
        internal static string PathName => RuntimeDataResolver.ResolveExistingDUserDestination(FileName);

        internal static Dictionary<string, string> Read()
        {
            var data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string path = PathName;
            if (!File.Exists(path)) return data; // New install: use explicit defaults.
            string section = "";
            int lineNo = 0;
            foreach (string sourceLine in File.ReadAllLines(path, Encoding.UTF8))
            {
                lineNo++;
                string line = sourceLine.Trim();
                if (line.Length == 0 || line.StartsWith(";") || line.StartsWith("#")) continue;
                if (line.StartsWith("[") && line.EndsWith("]"))
                { section = line.Substring(1, line.Length - 2).Trim(); continue; }
                int split = line.IndexOf('=');
                if (split < 1) throw new InvalidDataException(FileName + " line " + lineNo + ": expected key=value");
                string key = section + "." + line.Substring(0, split).Trim();
                if (data.ContainsKey(key)) throw new InvalidDataException(FileName + " duplicate key " + key);
                data[key] = line.Substring(split + 1).Trim();
            }
            return data;
        }
        internal static int Int(Dictionary<string, string> data, string key, int fallback, int min, int max)
        {
            string raw;
            if (!data.TryGetValue(key, out raw)) return fallback;
            int value;
            if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out value) || value < min || value > max)
                throw new InvalidDataException(FileName + ": invalid " + key + "=" + raw);
            return value;
        }
        internal static double Number(Dictionary<string, string> data, string key, double fallback, double min, double max)
        {
            string raw;
            if (!data.TryGetValue(key, out raw)) return fallback;
            double value;
            if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value) ||
                double.IsNaN(value) || double.IsInfinity(value) || value < min || value > max)
                throw new InvalidDataException(FileName + ": invalid " + key + "=" + raw);
            return value;
        }
        internal static CalculatorInputSettings LoadCalculation()
        {
            var data = Read();
            return new CalculatorInputSettings {
                NearestGap = Number(data, "Calculation.Gap", 5, 0, 100000),
                TopMargin = Number(data, "Calculation.Top", 5, 0, 100000),
                BottomMargin = Number(data, "Calculation.Bottom", 5, 0, 100000),
                StartAngle = Int(data, "Calculation.StartAngle", 5, 0, 360),
                EndAngle = Int(data, "Calculation.EndAngle", 180, 0, 360),
                StepAngle = Int(data, "Calculation.StepAngle", 2, 1, 360)
            };
        }
        internal static void SaveSection(string section, IDictionary<string, string> updates)
        {
            // Serialize CAD and Desktop writes so either can update its section
            // without deleting unrelated keys from the same INI file.
            using (var gate = new System.Threading.Mutex(false, @"Local\DCAD_Dlayout_Settings"))
            {
                bool locked = false;
                try
                {
                    try { locked = gate.WaitOne(10000); }
                    catch (System.Threading.AbandonedMutexException) { locked = true; }
                    if (!locked) throw new IOException("Dlayout settings locked by another process.");
                    var values = Read();
                    foreach (var pair in updates) values[section + "." + pair.Key] = pair.Value;
                    var sb = new StringBuilder("# DCAD Dlayout settings V1\r\n");
                    string previous = null;
                    foreach (var pair in new SortedDictionary<string, string>(values, StringComparer.OrdinalIgnoreCase))
                    {
                        int dot = pair.Key.IndexOf('.');
                        if (dot <= 0) throw new InvalidDataException("Invalid Dlayout setting " + pair.Key);
                        string current = pair.Key.Substring(0, dot);
                        if (!string.Equals(previous, current, StringComparison.OrdinalIgnoreCase))
                        { sb.Append("\r\n[").Append(current).Append("]\r\n"); previous = current; }
                        sb.Append(pair.Key.Substring(dot + 1)).Append('=').Append(pair.Value).Append("\r\n");
                    }
                    DcadAtomicFile.WriteAllText(PathName, sb.ToString());
                }
                finally { if (locked) gate.ReleaseMutex(); }
            }
        }
    }
}
