using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using LayoutMaterial.Commands;

namespace LayoutMaterial.Services
{
    // V95: isolate invalid/ambiguous selected contours by HANDLE, not by command.
    // Never reinterpret a failed hole or an overlapping contour as safe empty geometry.
    // Unrelated, verified outer parts are still sent to the unchanged solver.
    internal static class CadSelectionGrouper
    {
        private sealed class Candidate
        {
            internal ObjectId Id;
            internal List<Point2d> Ring;
            internal double GrossArea;
            internal Point3d Center;
        }
        private sealed class BadContour
        {
            internal ObjectId Id;
            internal Bounds2 Bounds;
            internal List<Point2d> Ring;
        }
        private sealed class Bounds2
        {
            internal double X0, X1, Y0, Y1;
            internal bool Overlaps(Bounds2 b)
            {
                return X0 <= b.X1 + 1e-7 && X1 >= b.X0 - 1e-7 &&
                    Y0 <= b.Y1 + 1e-7 && Y1 >= b.Y0 - 1e-7;
            }
        }
        private static Bounds2 Bounds(List<Point2d> points)
        {
            return new Bounds2 { X0=points.Min(p=>p.X), X1=points.Max(p=>p.X),
                Y0=points.Min(p=>p.Y), Y1=points.Max(p=>p.Y) };
        }
        private static Bounds2 Bounds(Entity e)
        {
            var x=e.GeometricExtents;
            return new Bounds2 { X0=x.MinPoint.X, X1=x.MaxPoint.X,
                Y0=x.MinPoint.Y, Y1=x.MaxPoint.Y };
        }

        internal static List<DlayoutMultiCommand.SourcePart> Build(Database db,
            IEnumerable<ObjectId> selected,
            Func<Polyline, double, List<Point2d>> tessellate,
            Action<string> report)
        {
            var ids=selected.Where(x=>x.IsValid).Distinct().ToList();
            var candidates=new List<Candidate>();
            var samples=new Dictionary<ObjectId,Tuple<List<Point2d>,bool>>();
            var bad=new List<BadContour>();
            var rejected=new Dictionary<ObjectId,string>();
            var selectionInfo=new Dictionary<ObjectId,Tuple<string,string>>();
            Action<ObjectId,string> reject=(id,reason)=>
            {
                if (!rejected.ContainsKey(id)) rejected.Add(id,reason);
            };
            using (var tr=db.TransactionManager.StartTransaction())
            {
                foreach (var id in ids)
                {
                    Entity e=null;
                    try
                    {
                        e=tr.GetObject(id,OpenMode.ForRead) as Entity;
                        if(e==null || e.IsErased) continue;
                        selectionInfo[id]=Tuple.Create(e.GetType().Name,e.Layer);
                        // Layer names and layer visibility/lock state do not determine
                        // whether selected geometry is a valid contour. In particular,
                        // accept output parts previously placed on DLAYOUT_PARTS.
                        bool target=e is Circle || IsClosedPolyline(e);
                        string samplingError;
                        var points=Sample(e,tessellate,out samplingError);
                        if(points.Count>0)
                        {
                            bool closed=e is Circle || IsClosedPolyline(e) || !(e is Curve);
                            samples[id]=Tuple.Create(points,closed);
                        }
                        // Open geometry/text belongs to a rigid group but must not
                        // be mistaken for a closed OUTER silhouette.
                        if(!target) continue;
                        double area=0;
                        string reason=null;
                        if(points.Count<3) reason=string.IsNullOrEmpty(samplingError)
                            ? Lang.T("GroupInvalidGeometry") : Lang.F("GroupReadError",samplingError);
                        else if(points.Count>2000) reason=Lang.T("GroupTooDetailed");
                        else if(e is Polyline poly)
                        {
                            // A CLOSED 2-vertex polyline can be a valid loop when its
                            // bulged segments enclose area (e.g. two semicircles).
                            // Tessellation/Area below validate real geometry;
                            // the raw vertex count is NOT a planarity test.
                            if(!Planar(poly.Normal,poly.Elevation))
                                reason=Lang.T("GroupInvalidPlane");
                            else if(poly.NumberOfVertices<2)
                                reason=Lang.T("GroupInvalidGeometry");
                            else
                            {
                                try { area=Math.Abs(poly.Area); }
                                catch(System.Exception ex) { reason=Lang.F("GroupReadError",ex.Message); }
                            }
                        }
                        else if(e is Circle circle)
                        {
                            if(circle.Radius<=0 || !Planar(circle.Normal,circle.Center.Z))
                                reason=Lang.T("GroupInvalidPlane");
                            else area=Math.PI*circle.Radius*circle.Radius;
                        }
                        else if(e is Polyline2d || e is Polyline3d)
                        {
                            // Legacy POLYLINE entities are sampled in WCS. SampleCurve rejects
                            // any non-XY Z values; calculate their area from the validated ring.
                            area=Math.Abs(DlayoutMultiCommand.Area(points));
                        }
                        if(reason==null && points.Any(p=>double.IsNaN(p.X) ||
                           double.IsNaN(p.Y) || double.IsInfinity(p.X) || double.IsInfinity(p.Y)))
                            reason=Lang.T("GroupInvalidGeometry");
                        if(reason==null && (double.IsNaN(area) || double.IsInfinity(area) || area<=1e-8))
                            reason=Lang.T("GroupInvalidArea");
                        if(reason!=null)
                        {
                            reject(id,reason);
                            try { bad.Add(new BadContour {Id=id,Bounds=Bounds(e),Ring=points.Count>=3 ? points : null}); }
                            catch { throw new InvalidOperationException(Lang.F("GroupUnlocatable",id.Handle.ToString())); }
                            continue;
                        }
                        var contour=points;
                        candidates.Add(new Candidate { Id=id,Ring=contour,GrossArea=area,
                            Center=new Point3d((contour.Min(p=>p.X)+contour.Max(p=>p.X))/2,
                                (contour.Min(p=>p.Y)+contour.Max(p=>p.Y))/2,0) });
                    }
                    catch(System.Exception ex)
                    {
                        reject(id,Lang.F("GroupReadError",ex.Message));
                        if(e==null) continue;
                        // An unreadable annotation/open curve cannot become an
                        // outer/hole candidate. Skip only that accessory, not
                        // every otherwise valid part selected with it.
                        if(!(e is Circle) && !IsClosedPolyline(e)) continue;
                        try { bad.Add(new BadContour {Id=id,Bounds=Bounds(e)}); }
                        catch { throw new InvalidOperationException(
                            Lang.F("GroupUnlocatable",id.Handle.ToString()),ex); }
                    }
                }
                tr.Commit();
            }

            var blocked=new HashSet<ObjectId>();
            Action<Candidate,string> quarantine=(c,reason)=>
            {
                blocked.Add(c.Id); reject(c.Id,reason);
            };
            // Failed closed objects may be selected HOLES. If their extents
            // intersect an otherwise valid contour, its net area is uncertain:
            // quarantine the affected group, not the whole independent selection.
            foreach(var b in bad)
                foreach(var c in candidates)
                    if(Bounds(c.Ring).Overlaps(b.Bounds) &&
                        (b.Ring==null || Fits(b.Ring,c.Ring) ||
                         Fits(c.Ring,b.Ring) || ProperCrosses(b.Ring,c.Ring)))
                        quarantine(c,Lang.F("GroupAffected",b.Id.Handle.ToString()));

            // Equal outlines have no unique part/hole interpretation. Two crossing
            // closed contours likewise cannot be treated as independent parts.
            for(int i=0;i<candidates.Count;i++)
                for(int j=i+1;j<candidates.Count;j++)
                {
                    var a=candidates[i]; var b=candidates[j];
                    if(!Bounds(a.Ring).Overlaps(Bounds(b.Ring))) continue;
                    bool same=Math.Abs(a.GrossArea-b.GrossArea)<=
                        Math.Max(1e-7,a.GrossArea*1e-8) &&
                        Fits(a.Ring,b.Ring) && Fits(b.Ring,a.Ring);
                    bool crossing=!same && ProperCrosses(a.Ring,b.Ring);
                    if(!same && !crossing) continue;
                    quarantine(a,Lang.F("GroupConflict",b.Id.Handle.ToString()));
                    quarantine(b,Lang.F("GroupConflict",a.Id.Handle.ToString()));
                }
            // Don't promote a hole from a discarded outer into a new independent
            // part, or keep a parent whose nested loop was discarded.
            bool changed;
            do
            {
                changed=false;
                foreach(var a in candidates.Where(c=>blocked.Contains(c.Id)).ToList())
                    foreach(var b in candidates.Where(c=>!blocked.Contains(c.Id)))
                    {
                        if(Fits(a.Ring,b.Ring) || Fits(b.Ring,a.Ring))
                        { quarantine(b,Lang.F("GroupAffected",a.Id.Handle.ToString())); changed=true; }
                    }
            } while(changed);

            var safe=candidates.Where(c=>!blocked.Contains(c.Id)).ToList();
            var outer=safe.Where(c=>!safe.Any(p=>p!=c &&
                p.GrossArea>c.GrossArea+Math.Max(1e-7,p.GrossArea*1e-8) &&
                Fits(c.Ring,p.Ring))).ToList();
            var result=outer.Select(c=>new DlayoutMultiCommand.SourcePart {
                Id=c.Id,Handle=c.Id.Handle.ToString(),Center=c.Center,
                Polygon=c.Ring,SignedArea=DlayoutMultiCommand.Area(c.Ring),
                GrossArea=c.GrossArea,NetArea=c.GrossArea
            }).ToList();
            var outerIds=new HashSet<ObjectId>(outer.Select(x=>x.Id));
            int unassigned=0;
            var ambiguous=new HashSet<ObjectId>();
            foreach(var entry in samples)
            {
                if(outerIds.Contains(entry.Key) || blocked.Contains(entry.Key)) continue;
                var matching=result.Where(x=>Fits(entry.Value.Item1,x.Polygon,entry.Value.Item2))
                    .OrderBy(x=>x.GrossArea).ToList();
                if(matching.Count==0) { unassigned++; continue; }
                if(matching.Count>1)
                {
                    reject(entry.Key,Lang.T("GroupAmbiguous"));
                    foreach(var p in matching)
                    {
                        ambiguous.Add(p.Id);
                        reject(p.Id,Lang.F("GroupAffected",entry.Key.Handle.ToString()));
                    }
                    continue;
                }
                matching[0].InnerContours.Add(entry.Key);
                var preview=new List<Point2d>(entry.Value.Item1);
                if(entry.Value.Item2 && preview.Count>1) preview.Add(preview[0]);
                matching[0].PreviewExtras.Add(preview);
            }
            result.RemoveAll(x=>ambiguous.Contains(x.Id));
            if(result.Count==0)
            {
                // If every selected entity was ineligible as an outer profile, turn the
                // previously silent cases into explicit per-object rejection reasons.
                foreach(var id in ids)
                {
                    if(rejected.ContainsKey(id)) continue;
                    Tuple<string,string> info;
                    if(selectionInfo.TryGetValue(id,out info))
                        reject(id,Lang.F("GroupNoOuterObject",info.Item1,info.Item2));
                }
            }
            // All selection diagnostics are per entity, localized and deterministic.
            foreach(var id in ids)
            {
                string reason;
                if(rejected.TryGetValue(id,out reason))
                    report(Lang.F("GroupSkipDetail",id.Handle.ToString(),reason));
            }
            report(Lang.F("GroupCheckSummary",result.Count,rejected.Count));
            if(result.Count==0) throw new InvalidOperationException(Lang.T("GroupNoOuter"));
            report(Lang.F("GroupReport",result.Count,
                result.Sum(x=>x.InnerContours.Count),unassigned));
            return result;
        }

        private static bool ProperCrosses(List<Point2d> a,List<Point2d> b)
        {
            for(int i=0;i<a.Count;i++)
            {
                var p=a[i]; var q=a[(i+1)%a.Count];
                double ax0=Math.Min(p.X,q.X),ax1=Math.Max(p.X,q.X);
                double ay0=Math.Min(p.Y,q.Y),ay1=Math.Max(p.Y,q.Y);
                for(int j=0;j<b.Count;j++)
                {
                    var r=b[j]; var s=b[(j+1)%b.Count];
                    if(ax1<Math.Min(r.X,s.X) || ax0>Math.Max(r.X,s.X) ||
                       ay1<Math.Min(r.Y,s.Y) || ay0>Math.Max(r.Y,s.Y)) continue;
                    double c1=Cross(p,q,r), c2=Cross(p,q,s);
                    double c3=Cross(r,s,p), c4=Cross(r,s,q);
                    if(c1*c2 < -1e-16 && c3*c4 < -1e-16) return true;
                }
            }
            return false;
        }
        private static double Cross(Point2d a,Point2d b,Point2d p) =>
            (b.X-a.X)*(p.Y-a.Y)-(b.Y-a.Y)*(p.X-a.X);

        private static bool IsClosedPolyline(Entity e) =>
            (e is Polyline pl && pl.Closed) ||
            (e is Polyline2d pl2 && pl2.Closed) ||
            (e is Polyline3d pl3 && pl3.Closed);

        // Legacy 2D/3D POLYLINE does not expose the same lightweight-polyline
        // tessellation API. Sample its WCS curve, then drop the duplicate closing point.
        internal static List<Point2d> SampleLegacyClosedPolyline(Curve curve)
        {
            var points=SampleCurve(curve,1024);
            if(points.Count>1)
            {
                var first=points[0]; var last=points[points.Count-1];
                double dx=first.X-last.X,dy=first.Y-last.Y;
                if(dx*dx+dy*dy<=1e-12) points.RemoveAt(points.Count-1);
            }
            return points;
        }

        private static bool Planar(Vector3d normal,double z) =>
            Math.Abs(normal.X)<1e-8 && Math.Abs(normal.Y)<1e-8 &&
            Math.Abs(normal.Z-1)<1e-8 && Math.Abs(z)<1e-6;

        private static List<Point2d> Sample(Entity e,
            Func<Polyline,double,List<Point2d>> tessellate,out string error)
        {
            error=null;
            try
            {
                if(e is Polyline poly)
                {
                    if(!Planar(poly.Normal,poly.Elevation)) return new List<Point2d>();
                    if(poly.Closed) return tessellate(poly,.005);
                    return SampleCurve(poly,Math.Min(1024,Math.Max(16,poly.NumberOfVertices*8)));
                }
                if(e is Polyline2d legacy2d)
                    return legacy2d.Closed ? SampleLegacyClosedPolyline(legacy2d) : SampleCurve(legacy2d,128);
                if(e is Polyline3d legacy3d)
                    return legacy3d.Closed ? SampleLegacyClosedPolyline(legacy3d) : SampleCurve(legacy3d,128);
                if(e is Circle circle)
                {
                    if(!Planar(circle.Normal,circle.Center.Z) || circle.Radius<=0)
                        return new List<Point2d>();
                    int n=Math.Max(48,(int)Math.Ceiling(Math.PI/
                        Math.Acos(Math.Max(0,1-.005/circle.Radius))));
                    if(n>2000) return new List<Point2d>();
                    var pts=new List<Point2d>(n);
                    for(int i=0;i<n;i++) { double t=2*Math.PI*i/n;
                        pts.Add(new Point2d(circle.Center.X+circle.Radius*Math.Cos(t),
                            circle.Center.Y+circle.Radius*Math.Sin(t))); }
                    return pts;
                }
                if(e is Line line)
                    return new List<Point2d> { ToPoint(line.StartPoint),
                        Mid(ToPoint(line.StartPoint),ToPoint(line.EndPoint)),ToPoint(line.EndPoint) };
                if(e is Arc arc && Planar(arc.Normal,arc.Center.Z)) return SampleCurve(arc,80);
                if(e is Curve curve) return SampleCurve(curve,128);
                var ex=e.GeometricExtents;
                if(Math.Abs(ex.MinPoint.Z)>1e-5 || Math.Abs(ex.MaxPoint.Z)>1e-5)
                    return new List<Point2d>();
                return new List<Point2d> {
                    new Point2d(ex.MinPoint.X,ex.MinPoint.Y),
                    new Point2d(ex.MaxPoint.X,ex.MinPoint.Y),
                    new Point2d(ex.MaxPoint.X,ex.MaxPoint.Y),
                    new Point2d(ex.MinPoint.X,ex.MaxPoint.Y) };
            }
            catch(System.Exception ex) { error=ex.Message; return new List<Point2d>(); }
        }
        private static List<Point2d> SampleCurve(Curve e,int count)
        {
            double start=e.StartParam,end=e.EndParam;
            if(double.IsNaN(start) || double.IsNaN(end) || end<=start || count<=0)
                return new List<Point2d>();
            var result=new List<Point2d>(count+1);
            for(int i=0;i<=count;i++)
            {
                Point3d point=e.GetPointAtParameter(start+(end-start)*i/count);
                if(Math.Abs(point.Z)>1e-5) return new List<Point2d>();
                result.Add(ToPoint(point));
            }
            return result;
        }
        private static Point2d ToPoint(Point3d p) => new Point2d(p.X,p.Y);
        private static Point2d Mid(Point2d a,Point2d b) =>
            new Point2d((a.X+b.X)/2,(a.Y+b.Y)/2);
        private static double Dist2(Point2d a,Point2d b,Point2d q)
        {
            double dx=b.X-a.X,dy=b.Y-a.Y,d=dx*dx+dy*dy;
            if(d<1e-20) return (a.X-q.X)*(a.X-q.X)+(a.Y-q.Y)*(a.Y-q.Y);
            double t=Math.Max(0,Math.Min(1,((q.X-a.X)*dx+(q.Y-a.Y)*dy)/d));
            double x=a.X+t*dx-q.X,y=a.Y+t*dy-q.Y;
            return x*x+y*y;
        }
        internal static bool InsideOrOn(Point2d pt,List<Point2d> ring)
        {
            double scale=Math.Max(ring.Max(x=>x.X)-ring.Min(x=>x.X),
                ring.Max(x=>x.Y)-ring.Min(x=>x.Y));
            double tol=Math.Max(1e-7,scale*1e-8);
            for(int i=0;i<ring.Count;i++)
                if(Dist2(ring[i],ring[(i+1)%ring.Count],pt)<=tol*tol) return true;
            return DlayoutMultiCommand.Inside(pt,ring);
        }
        internal static bool Fits(List<Point2d> sample,List<Point2d> boundary,bool closed=true)
        {
            if(sample.Count==0 || boundary.Count<3) return false;
            for(int i=0;i<sample.Count;i++)
            {
                var a=sample[i];
                if(!InsideOrOn(a,boundary)) return false;
                if(sample.Count>1 && (closed || i+1<sample.Count))
                {
                    var b=sample[(i+1)%sample.Count];
                    if(!InsideOrOn(new Point2d((a.X+b.X)/2,(a.Y+b.Y)/2),boundary))
                        return false;
                }
            }
            return true;
        }
    }
}
