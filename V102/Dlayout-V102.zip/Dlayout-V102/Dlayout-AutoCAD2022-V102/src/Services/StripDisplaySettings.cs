using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Autodesk.AutoCAD.Colors;
using LayoutMaterial;

namespace LayoutMaterial.Services
{
    internal enum StripColorMode { Original = 0, ByStation = 1, ByPart = 2 }

    // Only post-optimizer rendering settings. No influence on P/W, gap, or solutions.
    internal sealed class StripDisplaySettings
    {
        internal const int DefaultSteps = 2;
        internal const int MaxSteps = 10000; // Safety bound for enormous accidental drawings.
        internal const string CurrentLayerToken = "@CURRENT@";
        internal int Steps = DefaultSteps;
        internal StripColorMode ColorMode = StripColorMode.ByStation;
        internal string TargetLayer = "MATER";
        internal StripDisplaySettings Copy() => new StripDisplaySettings {
            Steps = Steps, ColorMode = ColorMode, TargetLayer = TargetLayer
        };
        internal static bool ValidSteps(int n) => n >= 2 && n <= MaxSteps;
    }

    // CAD and Desktop share ONE direct-DUser settings INI.
    internal static class StripDisplaySettingsStore
    {
        internal static StripDisplaySettings Load()
        {
            var values = DlayoutSettingsStore.Read();
            var settings = new StripDisplaySettings();
            settings.Steps = DlayoutSettingsStore.Int(values, "Strip.DrawSteps", settings.Steps, 2, StripDisplaySettings.MaxSteps);
            string raw;
            if (values.TryGetValue("Strip.ColorMode", out raw))
            {
                StripColorMode mode;
                if (!Enum.TryParse(raw, true, out mode) || !Enum.IsDefined(typeof(StripColorMode), mode))
                    throw new InvalidDataException("Dlayout_settings.ini: invalid Strip.ColorMode");
                settings.ColorMode = mode;
            }
            if (values.TryGetValue("Strip.TargetLayer", out raw))
            {
                if (string.IsNullOrWhiteSpace(raw))
                    throw new InvalidDataException("Dlayout_settings.ini: invalid Strip.TargetLayer");
                settings.TargetLayer = raw.Trim();
            }
            return settings;
        }
        internal static void Save(StripDisplaySettings settings)
        {
            if (settings == null || !StripDisplaySettings.ValidSteps(settings.Steps) ||
                !Enum.IsDefined(typeof(StripColorMode), settings.ColorMode) ||
                string.IsNullOrWhiteSpace(settings.TargetLayer))
                throw new InvalidDataException("Invalid Dlayout strip settings.");
            DlayoutSettingsStore.SaveSection("Strip", new Dictionary<string, string> {
                { "DrawSteps", settings.Steps.ToString(CultureInfo.InvariantCulture) },
                { "ColorMode", settings.ColorMode.ToString() },
                { "TargetLayer", settings.TargetLayer }
            });
        }
    }

    // ACI colors. Use bright standard hues before expanding to the ACI table.
    // 0/7/8/9 are omitted: ByBlock/black-white/dark grays. 5 is dark blue.
    // ACI values of dark shades are filtered using their actual CAD RGB color.
    internal static class StripAciPalette
    {
        private static readonly int[] BaseColors = { 1, 2, 3, 4, 6 };
        private static readonly int[] OrderedColors = Build();
        private static int[] Build()
        {
            var values = new List<int>();
            foreach (int c in BaseColors) values.Add(c);
            // Full-intensity primary hues before other saturations, then shades.
            for (int remainder = 0; remainder <= 9; ++remainder)
                for (int ten = 10; ten <= 249; ten += 10)
                {
                    int index = ten + remainder;
                    try
                    {
                        var rgb = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                            ColorMethod.ByAci, (short)index).ColorValue;
                        int brightness = (rgb.R * 299 + rgb.G * 587 + rgb.B * 114) / 1000;
                        int strongest = Math.Max(rgb.R, Math.Max(rgb.G, rgb.B));
                        if (brightness >= 105 && strongest >= 160) values.Add(index);
                    }
                    catch { /* Skip unsupported palette entry. */ }
                }
            return values.ToArray();
        }
        internal static int ForIndex(int ordinal) => OrderedColors[Math.Abs(ordinal % OrderedColors.Length)];
        internal static System.Drawing.Color Preview(int aci)
        {
            try
            {
                var c = Autodesk.AutoCAD.Colors.Color.FromColorIndex(ColorMethod.ByAci, (short)aci).ColorValue;
                return System.Drawing.Color.FromArgb(c.R, c.G, c.B);
            }
            catch { return System.Drawing.Color.Gold; }
        }
    }
}
