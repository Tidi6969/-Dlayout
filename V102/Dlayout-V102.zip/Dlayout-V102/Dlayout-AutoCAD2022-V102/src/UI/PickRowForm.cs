using System;
using System.Collections.Generic;
using System.Windows.Forms;
using LayoutMaterial.Models;

namespace LayoutMaterial.UI
{
    public sealed class PickRowForm : Form
    {
        private readonly ListBox _list = new ListBox();
        private readonly Button _ok = new Button();
        private readonly Button _cancel = new Button();

        public LayoutRow? SelectedRow { get; private set; }

        public PickRowForm(IReadOnlyList<LayoutRow> rows, LayoutRow current)
        {
            Text = Lang.T("PickLayoutRow");
            LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;
            MaximizeBox = false;
            Width = 520;
            Height = 420;

            _list.Dock = DockStyle.Top;
            _list.Height = 320;

            foreach (var r in rows) _list.Items.Add(r);
            _list.SelectedIndex = Math.Max(0, rows.IndexOf(current));

            _ok.Text = Lang.T("Ok");
            _ok.Width = 90;
            _ok.Left = 300;
            _ok.Top = 330;
            _ok.Click += (_, __) => { Accept(); };

            _cancel.Text = Lang.T("Cancel");
            _cancel.Width = 90;
            _cancel.Left = 395;
            _cancel.Top = 330;
            _cancel.Click += (_, __) => { DialogResult = DialogResult.Cancel; Close(); };

            Controls.Add(_list);
            Controls.Add(_ok);
            Controls.Add(_cancel);

            _list.DoubleClick += (_, __) => Accept();
        }

        private void Accept()
        {
            if (_list.SelectedItem is LayoutRow r)
            {
                SelectedRow = r;
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }

    internal static class ListExt
    {
        public static int IndexOf<T>(this IReadOnlyList<T> list, T item)
        {
            for (int i = 0; i < list.Count; i++)
                if (Equals(list[i], item)) return i;
            return -1;
        }
    }
}
