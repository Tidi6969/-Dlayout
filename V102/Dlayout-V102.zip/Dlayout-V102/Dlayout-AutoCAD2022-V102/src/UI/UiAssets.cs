using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace LayoutMaterial.UI
{
    internal static class UiAssets
    {
        private const string LogoResource = "DcadLogo.png";
        private const string IconResource = "DcadLogo.ico";

        public static Image LoadLogo()
        {
            Assembly asm = typeof(UiAssets).Assembly;
            string resource = FindResource(asm, LogoResource);
            if (resource == null) return null;
            using (Stream stream = asm.GetManifestResourceStream(resource))
            {
                if (stream == null) return null;
                using (Image image = Image.FromStream(stream))
                    return new Bitmap(image);
            }
        }

        public static Icon CreateAppIcon()
        {
            Assembly asm = typeof(UiAssets).Assembly;
            string resource = FindResource(asm, IconResource);
            if (resource == null) return null;
            using (Stream stream = asm.GetManifestResourceStream(resource))
            {
                if (stream == null) return null;
                using (var icon = new Icon(stream))
                    return (Icon)icon.Clone();
            }
        }

        // Match DPunch: assigning Form.Icon once is not enough in AutoCAD,
        // because the host/Windows can recreate the window handle and restore
        // its default title icon. Re-apply both small and big icons whenever
        // the handle is created and again when the form is shown.
        public static void AttachTitleIcon(Form form)
        {
            if (form == null) return;

            Icon titleIcon = CreateAppIcon();
            if (titleIcon == null)
            {
                form.ShowIcon = false;
                return;
            }

            form.ShowIcon = true;
            form.Icon = titleIcon;

            EventHandler forceIcon = delegate
            {
                ForceTitleIcon(form, titleIcon);
            };

            // AutoCAD can touch the native window during modal-dialog setup.
            // Re-apply the DCAD icon at every relevant WinForms lifecycle point,
            // then queue one more refresh after Shown/Activated so it runs after
            // the host has completed its own title-bar initialization.
            form.HandleCreated += forceIcon;
            form.Load += forceIcon;
            form.Shown += delegate
            {
                ForceTitleIcon(form, titleIcon);
                QueueTitleIconRefresh(form, titleIcon);
            };
            form.Activated += delegate
            {
                ForceTitleIcon(form, titleIcon);
                QueueTitleIconRefresh(form, titleIcon);
            };
            form.VisibleChanged += delegate
            {
                if (form.Visible) QueueTitleIconRefresh(form, titleIcon);
            };
            form.FormClosed += delegate
            {
                try { titleIcon.Dispose(); }
                catch { }
            };
        }


        internal static void RefreshTitleIcon(Form form)
        {
            if (form == null || form.IsDisposed) return;
            Icon icon = form.Icon;
            if (icon == null) return;
            ForceTitleIcon(form, icon);
            QueueTitleIconRefresh(form, icon);
        }

        private static void QueueTitleIconRefresh(Form form, Icon icon)
        {
            try
            {
                if (form == null || icon == null || form.IsDisposed || !form.IsHandleCreated) return;
                form.BeginInvoke((System.Windows.Forms.MethodInvoker)delegate
                {
                    ForceTitleIcon(form, icon);
                    try
                    {
                        if (!form.IsDisposed && form.IsHandleCreated)
                            form.BeginInvoke((System.Windows.Forms.MethodInvoker)delegate { ForceTitleIcon(form, icon); });
                    }
                    catch { }
                });
            }
            catch { }
        }

        private static void ForceTitleIcon(Form form, Icon icon)
        {
            try
            {
                if (form == null || icon == null || !form.IsHandleCreated) return;
                form.ShowIcon = true;
                form.Icon = icon;
                SendMessage(form.Handle, WmSetIcon, IconSmall, icon.Handle);
                SendMessage(form.Handle, WmSetIcon, IconBig, icon.Handle);
            }
            catch
            {
                if (form != null) form.ShowIcon = false;
            }
        }

        private const int WmSetIcon = 0x0080;
        private static readonly IntPtr IconSmall = new IntPtr(0);
        private static readonly IntPtr IconBig = new IntPtr(1);

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(
            IntPtr hWnd,
            int message,
            IntPtr wParam,
            IntPtr lParam);

        private static string FindResource(Assembly asm, string fileName)
        {
            foreach (string name in asm.GetManifestResourceNames())
                if (name.EndsWith(fileName, StringComparison.OrdinalIgnoreCase))
                    return name;
            return null;
        }
    }
}
