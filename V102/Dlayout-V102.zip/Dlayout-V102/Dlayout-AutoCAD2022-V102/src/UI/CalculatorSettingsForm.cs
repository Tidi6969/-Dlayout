using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using LayoutMaterial;
using LayoutMaterial.Models;

namespace LayoutMaterial.UI
{
    public sealed class CalculatorSettingsForm : Form
    {
        private static readonly Color ThemeGreen = Color.FromArgb(0, 192, 0);
        private static readonly Color ThemeText = Color.Yellow;

        private readonly TextBox _topMargin = new TextBox();
        private readonly TextBox _bottomMargin = new TextBox();
        private readonly TextBox _nearestGap = new TextBox();
        private readonly TextBox _startAngle = new TextBox();
        private readonly TextBox _endAngle = new TextBox();
        private readonly TextBox _stepAngle = new TextBox();
        private readonly Button _ok = new Button();
        private readonly Button _cancel = new Button();
        private readonly Panel _preview = new Panel();

        public CalculatorInputSettings? Result { get; private set; }

        public CalculatorSettingsForm(CalculatorInputSettings? defaults = null)
        {
            var def = defaults ?? new CalculatorInputSettings();
            LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);

            Text = Lang.T("CalcTitle");
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            BackColor = ThemeGreen;
            ClientSize = new Size(468, 312);

            BuildUi(def);
            WireInputValidation();

            AcceptButton = _ok;
            CancelButton = _cancel;
        }

        private void BuildUi(CalculatorInputSettings def)
        {
            int labelX = 6;
            int inputX = 132;
            int inputW = 72;
            int rowH = 24;
            int rowGap = 10;
            int y = 24;
            int previewX = 228;
            int previewTop = 24;
            int previewWidth = 225;
            int previewHeight = 256;
            int buttonTop = 250;

            Label AddLabel(string text, int top)
            {
                var lbl = new Label
                {
                    Text = text,
                    Left = labelX,
                    Top = top + 4,
                    Width = 122,
                    Height = 20,
                    ForeColor = ThemeText,
                    BackColor = Color.Transparent,
                    Font = new System.Drawing.Font(this.Font, FontStyle.Bold)
                };
                Controls.Add(lbl);
                return lbl;
            }

            TextBox AddTextBox(TextBox tb, string value, int top)
            {
                tb.Left = inputX;
                tb.Top = top;
                tb.Width = inputW;
                tb.Height = rowH;
                tb.Text = value;
                Controls.Add(tb);
                return tb;
            }

            AddLabel(Lang.T("CalcTopMargin"), y);
            AddTextBox(_topMargin, FormatCalcDouble(def.TopMargin), y);
            y += rowH + rowGap;

            AddLabel(Lang.T("CalcBottomMargin"), y);
            AddTextBox(_bottomMargin, FormatCalcDouble(def.BottomMargin), y);
            y += rowH + rowGap;

            AddLabel(Lang.T("CalcNearestGap"), y);
            AddTextBox(_nearestGap, FormatCalcDouble(def.NearestGap), y);
            y += rowH + rowGap;

            AddLabel(Lang.T("CalcStartAngle"), y);
            AddTextBox(_startAngle, def.StartAngle.ToString(CultureInfo.InvariantCulture), y);
            y += rowH + rowGap;

            AddLabel(Lang.T("CalcEndAngle"), y);
            AddTextBox(_endAngle, def.EndAngle.ToString(CultureInfo.InvariantCulture), y);
            y += rowH + rowGap;

            AddLabel(Lang.T("CalcStepAngle"), y);
            AddTextBox(_stepAngle, def.StepAngle.ToString(CultureInfo.InvariantCulture), y);

            _preview.Left = previewX;
            _preview.Top = previewTop;
            _preview.Width = previewWidth;
            _preview.Height = previewHeight;
            _preview.BackColor = Color.Black;
            _preview.BorderStyle = BorderStyle.FixedSingle;
            _preview.Paint += (_, e) => DrawPreview(e.Graphics, _preview.ClientRectangle);
            Controls.Add(_preview);

            _ok.Text = Lang.T("Calculator");
            _ok.Left = 6;
            _ok.Top = buttonTop;
            _ok.Width = 100;
            _ok.Height = 28;
            _ok.Click += (_, __) => OnOk();
            Controls.Add(_ok);

            _cancel.Text = Lang.T("Cancel");
            _cancel.Left = 112;
            _cancel.Top = buttonTop;
            _cancel.Width = 100;
            _cancel.Height = 28;
            _cancel.Click += (_, __) =>
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };
            Controls.Add(_cancel);
        }

        private void WireInputValidation()
        {
            WireDoubleTextBox(_topMargin, allowZero: true, fieldName: Lang.T("FieldTopMargin"));
            WireDoubleTextBox(_bottomMargin, allowZero: true, fieldName: Lang.T("FieldBottomMargin"));
            WireDoubleTextBox(_nearestGap, allowZero: false, fieldName: Lang.T("FieldNearestGap"));
        }

        private void WireDoubleTextBox(TextBox box, bool allowZero, string fieldName)
        {
            box.Enter += (_, __) => box.Tag = box.Text;
            box.Leave += (_, __) => NormalizeDoubleTextBox(box, allowZero, fieldName);
        }

        private bool NormalizeDoubleTextBox(TextBox box, bool allowZero, string fieldName)
        {
            if (!TryParseDouble(box.Text, out double value))
            {
                RestorePrevious(box);
                ShowInvalid(fieldName);
                return false;
            }

            value = NumericFormat.RoundTo(value, NumericFormat.CalculatorDecimals);
            if (value < 0 || (!allowZero && value <= 0))
            {
                RestorePrevious(box);
                ShowInvalid(fieldName);
                return false;
            }

            box.Text = FormatCalcDouble(value);
            box.Tag = box.Text;
            return true;
        }

        private static void RestorePrevious(TextBox box)
        {
            box.Text = box.Tag as string ?? box.Text;
            box.SelectAll();
        }

        private void OnOk()
        {
            if (!NormalizeDoubleTextBox(_topMargin, allowZero: true, fieldName: Lang.T("FieldTopMargin")))
                return;

            if (!NormalizeDoubleTextBox(_bottomMargin, allowZero: true, fieldName: Lang.T("FieldBottomMargin")))
                return;

            if (!NormalizeDoubleTextBox(_nearestGap, allowZero: false, fieldName: Lang.T("FieldNearestGap")))
                return;

            if (!TryParseDouble(_topMargin.Text, out var topMargin) || topMargin < 0)
            {
                ShowInvalid(Lang.T("FieldTopMargin"));
                return;
            }

            if (!TryParseDouble(_bottomMargin.Text, out var bottomMargin) || bottomMargin < 0)
            {
                ShowInvalid(Lang.T("FieldBottomMargin"));
                return;
            }

            if (!TryParseDouble(_nearestGap.Text, out var nearestGap) || nearestGap <= 0)
            {
                ShowInvalid(Lang.T("FieldNearestGap"));
                return;
            }

            if (!TryParseInt(_startAngle.Text, out var startAngle))
            {
                ShowInvalid(Lang.T("FieldStartAngle"));
                return;
            }

            if (!TryParseInt(_endAngle.Text, out var endAngle))
            {
                ShowInvalid(Lang.T("FieldEndAngle"));
                return;
            }

            if (!TryParseInt(_stepAngle.Text, out var stepAngle) || stepAngle <= 0)
            {
                ShowInvalid(Lang.T("FieldStepAngle"));
                return;
            }

            if (endAngle < startAngle)
            {
                MessageBox.Show(this, Lang.T("CalcEndAngleRange"), Lang.T("AppTitle"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _endAngle.Focus();
                _endAngle.SelectAll();
                return;
            }

            Result = new CalculatorInputSettings
            {
                TopMargin = NumericFormat.RoundTo(topMargin, NumericFormat.CalculatorDecimals),
                BottomMargin = NumericFormat.RoundTo(bottomMargin, NumericFormat.CalculatorDecimals),
                NearestGap = NumericFormat.RoundTo(nearestGap, NumericFormat.CalculatorDecimals),
                StartAngle = startAngle,
                EndAngle = endAngle,
                StepAngle = stepAngle
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private void ShowInvalid(string fieldName)
        {
            MessageBox.Show(this, Lang.F("InvalidValue", fieldName), Lang.T("AppTitle"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private static bool TryParseDouble(string? s, out double value)
        {
            if (double.TryParse((s ?? string.Empty).Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                return true;

            if (double.TryParse((s ?? string.Empty).Trim(), NumberStyles.Float, CultureInfo.CurrentCulture, out value))
                return true;

            value = 0;
            return false;
        }

        private static bool TryParseInt(string? s, out int value)
        {
            if (int.TryParse((s ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
                return true;

            if (int.TryParse((s ?? string.Empty).Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out value))
                return true;

            value = 0;
            return false;
        }

        private static string FormatCalcDouble(double value)
            => NumericFormat.FormatUpTo(value, NumericFormat.CalculatorDecimals);

        private static void DrawPreview(Graphics g, Rectangle rect)
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.Clear(Color.Black);

            using var cyanPen = new Pen(Color.Cyan, 1f);
            using var redPen = new Pen(Color.Red, 1f);
            using var yellowPen = new Pen(Color.Yellow, 1f);
            using var cyanBrush = new SolidBrush(Color.Cyan);
            using var yellowBrush = new SolidBrush(Color.Yellow);
            using var cyanFont = new Font("Arial", 10f, FontStyle.Regular);

            int left = 34;
            int right = rect.Width - 34;
            int topLineY = 32;
            int bottomLineY = rect.Height - 42;
            int partTop = 56;
            int partBottom = 160;

            g.DrawLine(redPen, left, topLineY, right, topLineY);
            g.DrawLine(redPen, left, bottomLineY, right, bottomLineY);

            g.DrawString("A1", cyanFont, cyanBrush, 8, topLineY + 2);
            g.DrawString("A2", cyanFont, cyanBrush, 8, bottomLineY - 18);
            g.DrawString("B", cyanFont, cyanBrush, rect.Width / 2 - 4, bottomLineY - 16);

            g.DrawLine(cyanPen, 20, topLineY - 12, 20, topLineY + 12);
            g.DrawLine(cyanPen, 16, topLineY - 12, 24, topLineY - 12);
            g.DrawLine(cyanPen, 16, topLineY + 12, 24, topLineY + 12);

            g.DrawLine(cyanPen, 20, bottomLineY - 12, 20, bottomLineY + 12);
            g.DrawLine(cyanPen, 16, bottomLineY - 12, 24, bottomLineY - 12);
            g.DrawLine(cyanPen, 16, bottomLineY + 12, 24, bottomLineY + 12);

            int bMidX = rect.Width / 2;
            g.DrawLine(cyanPen, bMidX, bottomLineY - 16, bMidX, bottomLineY + 2);
            g.DrawLine(cyanPen, bMidX - 34, bottomLineY + 8, bMidX + 34, bottomLineY + 8);

            Point[] leftPart =
            {
                new Point(56, partTop), new Point(82, partTop), new Point(82, 72), new Point(96, 72),
                new Point(96, 100), new Point(110, 100), new Point(110, 116), new Point(116, 122),
                new Point(112, 134), new Point(116, 144), new Point(110, 154), new Point(74, 154),
                new Point(74, 148), new Point(56, 148), new Point(56, 132), new Point(70, 132),
                new Point(70, 100), new Point(56, 100)
            };

            Point[] rightPart =
            {
                new Point(rect.Width - 56, partTop), new Point(rect.Width - 82, partTop), new Point(rect.Width - 82, 72), new Point(rect.Width - 96, 72),
                new Point(rect.Width - 96, 100), new Point(rect.Width - 110, 100), new Point(rect.Width - 110, 116), new Point(rect.Width - 116, 122),
                new Point(rect.Width - 112, 134), new Point(rect.Width - 116, 144), new Point(rect.Width - 110, 154), new Point(rect.Width - 74, 154),
                new Point(rect.Width - 74, 148), new Point(rect.Width - 56, 148), new Point(rect.Width - 56, 132), new Point(rect.Width - 70, 132),
                new Point(rect.Width - 70, 100), new Point(rect.Width - 56, 100)
            };

            g.DrawPolygon(yellowPen, leftPart);
            g.DrawPolygon(yellowPen, rightPart);
            g.DrawEllipse(yellowPen, 86, 112, 10, 10);
            g.DrawEllipse(yellowPen, rect.Width - 96, 112, 10, 10);
            g.DrawRectangle(yellowPen, 56, 148, 16, 16);
            g.DrawRectangle(yellowPen, rect.Width - 72, 148, 16, 16);
            g.DrawLine(yellowPen, 88, 149, 98, 149);
            g.DrawLine(yellowPen, rect.Width - 98, 149, rect.Width - 88, 149);
        }
    }
}
