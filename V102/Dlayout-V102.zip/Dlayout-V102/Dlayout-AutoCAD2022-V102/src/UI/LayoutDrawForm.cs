using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using LayoutMaterial;
using LayoutMaterial.Models;

using ModelLayoutSettings = LayoutMaterial.Models.LayoutSettings;

namespace LayoutMaterial.UI
{
    public sealed class RotatePickerNumericUpDown : NumericUpDown
    {
        public event EventHandler? BodyClick;
        public event EventHandler? SpinUpRequested;
        public event EventHandler? SpinDownRequested;

        protected override void OnCreateControl()
        {
            base.OnCreateControl();

            foreach (Control child in Controls)
            {
                if (child is TextBox)
                {
                    child.MouseDown -= ChildTextMouseDown;
                    child.MouseDown += ChildTextMouseDown;
                }
            }
        }

        private void ChildTextMouseDown(object? sender, MouseEventArgs e)
        {
            BodyClick?.Invoke(this, EventArgs.Empty);
        }

        public override void UpButton()
        {
            SpinUpRequested?.Invoke(this, EventArgs.Empty);
        }

        public override void DownButton()
        {
            SpinDownRequested?.Invoke(this, EventArgs.Empty);
        }
    }

    public sealed class LayoutDrawForm : Form
    {
        private static readonly Color ThemeGreen = Color.FromArgb(0, 192, 0);
        private static readonly Color ThemeText = Color.Yellow;

        private readonly IReadOnlyList<LayoutRow> _rows;
        private readonly CalculatorInputSettings? _calcDefaults;
        private readonly LayoutDrawDefaults _drawDefaults;
        private readonly bool _hasCalculatedRows;
        private LayoutRow _current;
        private bool _updating;

        private readonly TextBox thickness = new TextBox();
        private readonly TextBox material = new TextBox();
        private readonly NumericUpDown stno = new NumericUpDown();
        private readonly RotatePickerNumericUpDown rot = new RotatePickerNumericUpDown();
        private readonly TextBox mw = new TextBox();
        private readonly ComboBox mwRound = new ComboBox();
        private readonly TextBox up = new TextBox();
        private readonly TextBox low = new TextBox();
        private readonly TextBox ph = new TextBox();
        private readonly TextBox pitch = new TextBox();
        private readonly ComboBox pitchRound = new ComboBox();
        private readonly TextBox gap = new TextBox();
        private readonly TextBox pw = new TextBox();
        private readonly ComboBox feed = new ComboBox();
        private readonly CheckBox createInfo = new CheckBox();
        private readonly CheckBox xLineParallel = new CheckBox();
        private readonly CheckBox yLineParallel = new CheckBox();
        private readonly Label rateLbl = new Label();
        private readonly Button calculator = new Button();
        private readonly Button multiDesktop = new Button();
        private readonly Button ok = new Button();
        private readonly Button cancel = new Button();

        public bool OpenCalculatorRequested { get; private set; }
        public bool OpenMultiRequested { get; private set; }
        public ModelLayoutSettings? Result { get; private set; }
        public LayoutDrawDefaults? DrawDefaultsResult { get; private set; }

        public LayoutDrawForm(IReadOnlyList<LayoutRow> rows, LayoutRow best, CalculatorInputSettings? calcDefaults = null, bool hasCalculatedRows = true, LayoutDrawDefaults? drawDefaults = null)
        {
            _rows = rows;
            LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
            _current = best;
            _calcDefaults = calcDefaults;
            _drawDefaults = drawDefaults ?? new LayoutDrawDefaults();
            _hasCalculatedRows = hasCalculatedRows;

            Text = Lang.T("DrawTitle");
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            BackColor = ThemeGreen;
            ClientSize = new Size(367, 532);

            BuildUI();
            LoadFromRow(firstTime: true);
            ApplyDataAvailabilityState();

            AcceptButton = ok;
            CancelButton = cancel;
        }

        private void BuildUI()
        {
            int y = 14;
            int lx = 12, lw = 157, ex = 177, ew = 160, h = 24, gapY = 8;
            int shortW = 35;
            int roundLabelW = 42;
            int roundComboW = 71;
            int roundGap = 6;

            Label AddLabel(string t, int yy)
            {
                var l = new Label
                {
                    Text = t,
                    Left = lx,
                    Top = yy + 4,
                    Width = lw,
                    Height = 20,
                    ForeColor = ThemeText,
                    BackColor = Color.Transparent,
                    Font = new Font(Font, FontStyle.Bold)
                };
                Controls.Add(l);
                return l;
            }

            void AddControl(Control c, int yy, int width = -1)
            {
                c.Left = ex;
                c.Top = yy;
                c.Width = width > 0 ? width : ew;
                c.Height = h;
                Controls.Add(c);
            }

            Label AddRoundLabel(int left, int top)
            {
                var l = new Label
                {
                    Text = Lang.T("Round"),
                    Left = left,
                    Top = top + 4,
                    Width = roundLabelW,
                    Height = 20,
                    ForeColor = ThemeText,
                    BackColor = Color.Transparent,
                    Font = new Font(Font, FontStyle.Bold)
                };
                Controls.Add(l);
                return l;
            }

            ComboBox BuildRoundCombo(ComboBox cb, int left, int top)
            {
                cb.Left = left;
                cb.Top = top;
                cb.Width = roundComboW;
                cb.Height = h;
                cb.DropDownStyle = ComboBoxStyle.DropDownList;
                cb.Items.AddRange(new object[] { "0", "0.0", "0.00", "0.000", "0.0000" });
                cb.SelectedItem = "0";
                Controls.Add(cb);
                return cb;
            }

            AddLabel(Lang.T("LblThickness"), y);
            thickness.Text = "0";
            WireTrackedTextBox(thickness, (_, __) => ValidateThickness());
            AddControl(thickness, y);
            y += h + gapY;

            AddLabel(Lang.T("LblMaterial"), y);
            material.Text = "...";
            AddControl(material, y);
            y += h + gapY;

            AddLabel(Lang.T("LblStationNo"), y);
            stno.Minimum = 1;
            stno.Maximum = 999;
            stno.Value = 2;
            AddControl(stno, y);
            y += h + gapY;

            AddLabel(Lang.T("LblRotate"), y);
            rot.ReadOnly = true;
            rot.DecimalPlaces = 4;
            rot.Minimum = -3600;
            rot.Maximum = 3600;
            rot.Increment = 1;
            rot.ThousandsSeparator = false;
            rot.TextAlign = HorizontalAlignment.Left;
            rot.BodyClick += (_, __) => OnPick();
            rot.SpinUpRequested += (_, __) => OnRotateSpin(-1);
            rot.SpinDownRequested += (_, __) => OnRotateSpin(+1);
            rot.KeyDown += (_, e) =>
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space)
                {
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    OnPick();
                }
            };
            AddControl(rot, y);
            y += h + gapY;

            AddLabel(Lang.T("LblMaterWidth"), y);
            WireTrackedTextBox(mw, (_, __) => ValidateMaterWidth());
            AddControl(mw, y, shortW);
            AddRoundLabel(ex + shortW + roundGap, y);
            BuildRoundCombo(mwRound, ex + shortW + roundGap + roundLabelW + roundGap, y);
            mwRound.SelectedIndexChanged += (_, __) => OnMaterRoundChanged();
            y += h + gapY;

            AddLabel(Lang.T("LblUpper"), y);
            WireTrackedTextBox(up, (_, __) => ValidateUpper());
            AddControl(up, y);
            y += h + gapY;

            AddLabel(Lang.T("LblLower"), y);
            WireTrackedTextBox(low, (_, __) => ValidateLower());
            AddControl(low, y);
            y += h + gapY;

            AddLabel(Lang.T("LblPartHeight"), y);
            ph.ReadOnly = true;
            ph.BackColor = Color.White;
            AddControl(ph, y);
            y += h + gapY;

            AddLabel(Lang.T("LblPitch"), y);
            WireTrackedTextBox(pitch, (_, __) => ValidatePitch());
            AddControl(pitch, y, shortW);
            AddRoundLabel(ex + shortW + roundGap, y);
            BuildRoundCombo(pitchRound, ex + shortW + roundGap + roundLabelW + roundGap, y);
            pitchRound.SelectedIndexChanged += (_, __) => OnPitchRoundChanged();
            y += h + gapY;

            AddLabel(Lang.T("LblGap"), y);
            gap.ReadOnly = true;
            gap.BackColor = Color.White;
            AddControl(gap, y);
            y += h + gapY;

            AddLabel(Lang.T("LblPartWidth"), y);
            pw.ReadOnly = true;
            pw.BackColor = Color.White;
            AddControl(pw, y);
            y += h + gapY;

            AddLabel(Lang.T("LblFeedDirection"), y);
            feed.DropDownStyle = ComboBoxStyle.DropDownList;
            feed.Items.Add(Lang.T("FeedLftToRg"));
            feed.Items.Add(Lang.T("FeedRgToLft"));
            feed.SelectedIndex = 0;
            AddControl(feed, y);
            y += h + gapY;

            rateLbl.Left = lx;
            rateLbl.Top = y + 6;
            rateLbl.Width = 308;
            rateLbl.Height = 20;
            rateLbl.ForeColor = ThemeText;
            rateLbl.BackColor = Color.Transparent;
            rateLbl.Font = new Font(Font, FontStyle.Bold);
            Controls.Add(rateLbl);
            y += h + gapY - 2;

            void SetupCheckBox(CheckBox cb, string textValue, int yy, int width)
            {
                cb.Left = lx;
                cb.Top = yy;
                cb.Width = width;
                cb.Height = 22;
                cb.Text = textValue;
                cb.ForeColor = ThemeText;
                cb.BackColor = Color.Transparent;
                cb.Font = new Font(Font, FontStyle.Bold);
                Controls.Add(cb);
            }

            SetupCheckBox(createInfo, Lang.T("LblCreateInformation"), y, 220);
            y += h + gapY - 2;

            var parallelLbl = new Label
            {
                Text = Lang.T("LblParallelLine"),
                Left = lx,
                Top = y + 4,
                Width = 120,
                Height = 20,
                ForeColor = ThemeText,
                BackColor = Color.Transparent,
                Font = new Font(Font, FontStyle.Bold)
            };
            Controls.Add(parallelLbl);

            void SetupInlineCheck(CheckBox cb, string textValue, int left)
            {
                cb.Left = left;
                cb.Top = y;
                cb.Width = 38;
                cb.Height = 22;
                cb.Text = textValue;
                cb.ForeColor = ThemeText;
                cb.BackColor = Color.Transparent;
                cb.Font = new Font(Font, FontStyle.Bold);
                Controls.Add(cb);
            }

            SetupInlineCheck(xLineParallel, Lang.T("LblParallelX"), ex);
            SetupInlineCheck(yLineParallel, Lang.T("LblParallelY"), ex + 44);
            y += h + gapY;

            int buttonTop = y + 2;
            int buttonWidth = 81;
            int buttonHeight = 28;

            multiDesktop.Text = Lang.T("MultiDesktop");
            multiDesktop.Left = 12;
            multiDesktop.Top = buttonTop;
            multiDesktop.Width = buttonWidth;
            multiDesktop.Height = buttonHeight;
            multiDesktop.Click += (_, __) => { OpenMultiRequested = true; DialogResult = DialogResult.Retry; Close(); };
            Controls.Add(multiDesktop);

            calculator.Text = Lang.T("Calculator");
            calculator.Left = multiDesktop.Right + 6;
            calculator.Top = buttonTop;
            calculator.Width = buttonWidth;
            calculator.Height = buttonHeight;
            calculator.Click += (_, __) => OnCalculator();
            Controls.Add(calculator);

            ok.Text = Lang.T("Draw");
            ok.Left = calculator.Right + 6;
            ok.Top = buttonTop;
            ok.Width = buttonWidth;
            ok.Height = buttonHeight;
            ok.Click += (_, __) => OnOk();
            Controls.Add(ok);

            cancel.Text = Lang.T("Cancel");
            cancel.Left = ok.Right + 6;
            cancel.Top = buttonTop;
            cancel.Width = buttonWidth;
            cancel.Height = buttonHeight;
            cancel.Click += (_, __) =>
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };
            Controls.Add(cancel);
        }

        private void ApplyDataAvailabilityState()
        {
            if (_hasCalculatedRows) return;

            ok.Enabled = false;
            rot.Enabled = false;
            stno.Enabled = false;
            rateLbl.Text = Lang.T("LblRateAreaNA");
        }

        private void WireTrackedTextBox(TextBox box, EventHandler leaveHandler)
        {
            box.Enter += (_, __) => box.Tag = box.Text;
            box.Leave += leaveHandler;
        }

        private void LoadFromRow(bool firstTime)
        {
            _updating = true;

            if (firstTime)
            {
                thickness.Text = FormatGeneral(NumericFormat.RoundTo(System.Math.Max(0.0, _drawDefaults.Thickness), NumericFormat.CalculatorDecimals));
                material.Text = NormalizeMaterialText(_drawDefaults.Material);
                stno.Value = Math.Max(stno.Minimum, Math.Min(stno.Maximum, _drawDefaults.StationNo));
                mwRound.SelectedItem = NormalizeRoundSelection(_drawDefaults.MaterRound);
                pitchRound.SelectedItem = NormalizeRoundSelection(_drawDefaults.PitchRound);
                feed.SelectedItem = FeedDisplayFromToken(_drawDefaults.Feed);
                createInfo.Checked = _drawDefaults.CreateInformation;
                xLineParallel.Checked = _drawDefaults.XLineParallel;
                yLineParallel.Checked = _drawDefaults.YLineParallel;
            }

            rot.Value = ClampDecimal(_current.RotateDeg, rot.Minimum, rot.Maximum);
            ph.Text = FormatGeneral(_current.Height);
            gap.Text = FormatGeneral(_current.Gap);

            double upperDefault = DefaultUpper;
            double lowerDefault = DefaultLower;
            double materDefault = NumericFormat.RoundTo(_current.Height + upperDefault + lowerDefault, GetMaterRoundDecimals());
            double pitchDefault = NumericFormat.RoundTo(_current.Pitch, GetPitchRoundDecimals());

            up.Text = FormatGeneral(upperDefault);
            low.Text = FormatGeneral(lowerDefault);
            mw.Text = FormatMaterWidth(materDefault);
            pitch.Text = FormatPitch(pitchDefault);

            RefreshDerivedValues();
            RememberValidInputs();
            _updating = false;
        }

        private double DefaultUpper => _calcDefaults != null ? Math.Max(0.0, NumericFormat.RoundTo(_calcDefaults.TopMargin, NumericFormat.CalculatorDecimals)) : 4.0;
        private double DefaultLower => _calcDefaults != null ? Math.Max(0.0, NumericFormat.RoundTo(_calcDefaults.BottomMargin, NumericFormat.CalculatorDecimals)) : 4.0;
        private double CurrentPartHeight => _current.Height;

        private void RememberValidInputs()
        {
            thickness.Tag = thickness.Text;
            mw.Tag = mw.Text;
            up.Tag = up.Text;
            low.Tag = low.Text;
            pitch.Tag = pitch.Text;
        }

        private int GetMaterRoundDecimals() => NumericFormat.DecimalsFromRoundText(mwRound.SelectedItem?.ToString());
        private int GetPitchRoundDecimals() => NumericFormat.DecimalsFromRoundText(pitchRound.SelectedItem?.ToString());

        private static string NormalizeRoundSelection(string? value)
        {
            var text = (value ?? string.Empty).Trim();
            return text == "0.0" || text == "0.00" || text == "0.000" || text == "0.0000" ? text : "0";
        }

        private static string NormalizeFeedSelection(string? value)
        {
            string text = (value ?? string.Empty).Trim();
            return string.Equals(text, "Rg-to-Lft", StringComparison.OrdinalIgnoreCase)
                || string.Equals(text, Lang.T("FeedRgToLft"), StringComparison.OrdinalIgnoreCase)
                ? "Rg-to-Lft"
                : "Lft-to-Rg";
        }

        private static string FeedDisplayFromToken(string? token)
            => string.Equals((token ?? string.Empty).Trim(), "Rg-to-Lft", StringComparison.OrdinalIgnoreCase)
                ? Lang.T("FeedRgToLft")
                : Lang.T("FeedLftToRg");

        private static string NormalizeMaterialText(string? value)
        {
            var text = (value ?? string.Empty).Trim();
            return string.IsNullOrWhiteSpace(text) ? "..." : text;
        }

        private string FormatGeneral(double value) => NumericFormat.FormatUpTo(value, NumericFormat.CalculatorDecimals);
        private string FormatMaterWidth(double value) => NumericFormat.FormatUpTo(value, GetMaterRoundDecimals());
        private string FormatPitch(double value) => NumericFormat.FormatUpTo(value, GetPitchRoundDecimals());

        private double ParseRounded(TextBox box, int decimals)
        {
            return TryParseDouble(box.Text, out double value) ? NumericFormat.RoundTo(value, decimals) : 0.0;
        }

        private double CurrentMaterWidthValue => ParseRounded(mw, GetMaterRoundDecimals());
        private double CurrentPitchValue => ParseRounded(pitch, GetPitchRoundDecimals());

        private void OnRotateSpin(int delta)
        {
            if (!_hasCalculatedRows || _rows == null || _rows.Count == 0) return;

            int idx = IndexOfCurrentRow();
            int next = Math.Max(0, Math.Min(_rows.Count - 1, idx + delta));
            if (next == idx) return;

            _current = _rows[next];
            LoadFromRow(firstTime: false);
        }

        private int IndexOfCurrentRow()
        {
            for (int i = 0; i < _rows.Count; i++)
            {
                if (ReferenceEquals(_rows[i], _current)) return i;
            }

            int best = 0;
            double bestDiff = double.MaxValue;
            for (int i = 0; i < _rows.Count; i++)
            {
                double diff = Math.Abs(_rows[i].RotateDeg - _current.RotateDeg);
                if (diff < bestDiff)
                {
                    best = i;
                    bestDiff = diff;
                }
            }
            return best;
        }

        private void OnPick()
        {
            if (!_hasCalculatedRows) return;

            using var dlg = new PickRowForm(_rows, _current);
            if (dlg.ShowDialog(this) == DialogResult.OK && dlg.SelectedRow != null)
            {
                _current = dlg.SelectedRow;
                LoadFromRow(firstTime: false);
            }
        }

        private void OnCalculator()
        {
            OpenCalculatorRequested = true;
            DialogResult = DialogResult.Retry;
            Close();
        }

        private void OnMaterRoundChanged()
        {
            if (_updating) return;
            ValidateMaterWidth();
        }

        private void OnPitchRoundChanged()
        {
            if (_updating) return;
            ValidatePitch();
        }

        private bool ValidateThickness()
        {
            if (_updating) return true;

            if (!TryParseDouble(thickness.Text, out double value) || value < 0)
            {
                RestorePreviousValue(thickness, Lang.T("MsgThicknessInvalid"));
                return false;
            }

            _updating = true;
            value = NumericFormat.RoundTo(value, NumericFormat.CalculatorDecimals);
            thickness.Text = FormatGeneral(value);
            thickness.Tag = thickness.Text;
            _updating = false;
            return true;
        }

        private bool ValidateMaterWidth()
        {
            if (_updating) return true;

            if (!TryParseDouble(mw.Text, out double materWidth))
            {
                RestorePreviousValue(mw, Lang.T("MsgMaterInvalid"));
                return false;
            }

            materWidth = NumericFormat.RoundTo(materWidth, GetMaterRoundDecimals());
            double partH = CurrentPartHeight;
            double margin = materWidth - partH;
            double split = NumericFormat.RoundTo(margin / 2.0, NumericFormat.CalculatorDecimals);
            if (split < 0)
            {
                RestorePreviousValue(mw, Lang.T("MsgMaterNegative"));
                return false;
            }

            _updating = true;
            mw.Text = FormatMaterWidth(materWidth);
            up.Text = FormatGeneral(split);
            low.Text = FormatGeneral(split);
            RefreshDerivedValues();
            RememberValidInputs();
            _updating = false;
            return true;
        }

        private bool ValidateUpper()
        {
            if (_updating) return true;

            if (!TryParseDouble(up.Text, out double upperVal))
            {
                RestorePreviousValue(up, Lang.T("MsgUpperInvalid"));
                return false;
            }

            double materWidth = CurrentMaterWidthValue;
            double lowerVal = NumericFormat.RoundTo(materWidth - CurrentPartHeight - upperVal, NumericFormat.CalculatorDecimals);
            if (upperVal < 0 || lowerVal < 0)
            {
                RestorePreviousValue(up, Lang.T("MsgUpperNegative"));
                return false;
            }

            _updating = true;
            up.Text = FormatGeneral(NumericFormat.RoundTo(upperVal, NumericFormat.CalculatorDecimals));
            low.Text = FormatGeneral(lowerVal);
            RefreshDerivedValues();
            RememberValidInputs();
            _updating = false;
            return true;
        }

        private bool ValidateLower()
        {
            if (_updating) return true;

            if (!TryParseDouble(low.Text, out double lowerVal))
            {
                RestorePreviousValue(low, Lang.T("MsgLowerInvalid"));
                return false;
            }

            double materWidth = CurrentMaterWidthValue;
            double upperVal = NumericFormat.RoundTo(materWidth - CurrentPartHeight - lowerVal, NumericFormat.CalculatorDecimals);
            if (lowerVal < 0 || upperVal < 0)
            {
                RestorePreviousValue(low, Lang.T("MsgLowerNegative"));
                return false;
            }

            _updating = true;
            low.Text = FormatGeneral(NumericFormat.RoundTo(lowerVal, NumericFormat.CalculatorDecimals));
            up.Text = FormatGeneral(upperVal);
            RefreshDerivedValues();
            RememberValidInputs();
            _updating = false;
            return true;
        }

        private bool ValidatePitch()
        {
            if (_updating) return true;

            if (!TryParseDouble(pitch.Text, out double pitchVal) || pitchVal <= 0)
            {
                RestorePreviousValue(pitch, Lang.T("MsgPitchInvalid"));
                return false;
            }

            _updating = true;
            pitchVal = NumericFormat.RoundTo(pitchVal, GetPitchRoundDecimals());
            if (pitchVal <= 0)
            {
                _updating = false;
                RestorePreviousValue(pitch, Lang.T("MsgPitchInvalid"));
                return false;
            }

            pitch.Text = FormatPitch(pitchVal);
            RefreshDerivedValues();
            RememberValidInputs();
            _updating = false;
            return true;
        }

        private void RefreshDerivedValues()
        {
            double partH = NumericFormat.RoundTo(CurrentPartHeight, NumericFormat.CalculatorDecimals);
            double materWidth = CurrentMaterWidthValue;
            double pitchVal = CurrentPitchValue;
            double gapVal = NumericFormat.RoundTo(_current.Gap, NumericFormat.CalculatorDecimals);
            double partWidthVal = NumericFormat.RoundTo(pitchVal - gapVal, NumericFormat.CalculatorDecimals);
            double rateVal = 0.0;

            ph.Text = FormatGeneral(partH);
            gap.Text = FormatGeneral(gapVal);
            pw.Text = FormatGeneral(partWidthVal);

            if (pitchVal > 1e-12 && materWidth > 1e-12)
                rateVal = NumericFormat.RoundTo(100.0 * _current.Area / (pitchVal * materWidth), NumericFormat.CalculatorDecimals);

            rateLbl.Text = Lang.F("LblRateArea", FormatGeneral(rateVal), FormatGeneral(_current.Area));
        }

        private void RestorePreviousValue(TextBox box, string message)
        {
            string oldText = box.Tag as string ?? box.Text;
            _updating = true;
            box.Text = oldText;
            RefreshDerivedValues();
            _updating = false;
            MessageBox.Show(this, message, Lang.T("Warning"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            box.Focus();
            box.SelectAll();
        }

        private void OnOk()
        {
            if (!ValidateThickness()) return;
            if (!ValidateMaterWidth()) return;
            if (!ValidatePitch()) return;
            if (!ValidateCurrentState()) return;

            int st = (int)stno.Value;
            double thicknessVal = ParseRounded(thickness, NumericFormat.CalculatorDecimals);
            double r = _current.RotateDeg;
            double m = CurrentMaterWidthValue;
            double u = ParseRounded(up, NumericFormat.CalculatorDecimals);
            double l = ParseRounded(low, NumericFormat.CalculatorDecimals);
            double pitchVal = CurrentPitchValue;
            double gapVal = NumericFormat.RoundTo(_current.Gap, NumericFormat.CalculatorDecimals);
            double partH = NumericFormat.RoundTo(CurrentPartHeight, NumericFormat.CalculatorDecimals);
            double partWVal = NumericFormat.RoundTo(pitchVal - gapVal, NumericFormat.CalculatorDecimals);
            double rateVal = 0.0;

            if (pitchVal > 1e-12 && m > 1e-12)
                rateVal = NumericFormat.RoundTo(100.0 * _current.Area / (pitchVal * m), NumericFormat.CalculatorDecimals);

            string materialValue = NormalizeMaterialText(material.Text);

            Result = new ModelLayoutSettings
            {
                StationNo = st,
                Thickness = thicknessVal,
                Material = materialValue,
                RotateDeg = NumericFormat.RoundTo(r, NumericFormat.CalculatorDecimals),
                MaterWidth = m,
                Upper = u,
                Lower = l,
                Pitch = pitchVal,
                Gap = gapVal,
                Feed = NormalizeFeedSelection(feed.SelectedItem?.ToString()),
                PartHeight = partH,
                PartWidth = partWVal,
                Rate = rateVal,
                Area = NumericFormat.RoundTo(_current.Area, NumericFormat.CalculatorDecimals),
                CreateInformation = createInfo.Checked,
                XLineParallel = xLineParallel.Checked,
                YLineParallel = yLineParallel.Checked
            };

            DrawDefaultsResult = new LayoutDrawDefaults
            {
                Thickness = thicknessVal,
                Material = materialValue,
                StationNo = st,
                MaterRound = NormalizeRoundSelection(mwRound.SelectedItem?.ToString()),
                PitchRound = NormalizeRoundSelection(pitchRound.SelectedItem?.ToString()),
                Feed = NormalizeFeedSelection(feed.SelectedItem?.ToString()),
                CreateInformation = createInfo.Checked,
                XLineParallel = xLineParallel.Checked,
                YLineParallel = yLineParallel.Checked
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private bool ValidateCurrentState()
        {
            if (!TryParseDouble(mw.Text, out double materWidth))
            {
                RestorePreviousValue(mw, Lang.T("MsgMaterInvalid"));
                return false;
            }

            if (!TryParseDouble(up.Text, out double upperVal))
            {
                RestorePreviousValue(up, Lang.T("MsgUpperInvalid"));
                return false;
            }

            if (!TryParseDouble(low.Text, out double lowerVal))
            {
                RestorePreviousValue(low, Lang.T("MsgLowerInvalid"));
                return false;
            }

            materWidth = NumericFormat.RoundTo(materWidth, GetMaterRoundDecimals());
            upperVal = NumericFormat.RoundTo(upperVal, NumericFormat.CalculatorDecimals);
            lowerVal = NumericFormat.RoundTo(lowerVal, NumericFormat.CalculatorDecimals);

            if (upperVal < 0 || lowerVal < 0)
            {
                MessageBox.Show(this, Lang.T("MsgUpperLowerCheck"), Lang.T("Warning"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            double expectedMater = NumericFormat.RoundTo(CurrentPartHeight + upperVal + lowerVal, GetMaterRoundDecimals());
            if (Math.Abs(expectedMater - materWidth) > 0.00005)
            {
                _updating = true;
                mw.Text = FormatMaterWidth(expectedMater);
                RefreshDerivedValues();
                RememberValidInputs();
                _updating = false;
            }

            return true;
        }

        private static decimal ClampDecimal(double value, decimal min, decimal max)
        {
            decimal d = (decimal)value;
            if (d < min) return min;
            if (d > max) return max;
            return d;
        }

        private static bool TryParseDouble(string? s, out double value)
        {
            if (double.TryParse((s ?? string.Empty).Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                return true;

            if (double.TryParse((s ?? string.Empty).Trim(), NumberStyles.Float, CultureInfo.CurrentCulture, out value))
                return true;

            value = 0.0;
            return false;
        }
    }
}
