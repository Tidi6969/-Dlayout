using System;
using System.Globalization;

namespace LayoutMaterial
{
    internal static class NumericFormat
    {
        public const int CalculatorDecimals = 4;

        public static double RoundTo(double value, int decimals)
        {
            if (decimals < 0) decimals = 0;
            if (decimals > 15) decimals = 15;
            return Math.Round(value, decimals, MidpointRounding.AwayFromZero);
        }

        public static string FormatUpTo(double value, int decimals)
        {
            if (double.IsNaN(value) || double.IsInfinity(value))
                return "0";

            double rounded = RoundTo(value, decimals);
            if (Math.Abs(rounded) < 1e-12)
                rounded = 0.0;

            string pattern = decimals <= 0 ? "0" : "0." + new string('#', decimals);
            return rounded.ToString(pattern, CultureInfo.InvariantCulture);
        }

        public static int DecimalsFromRoundText(string? text)
        {
            string value = (text ?? string.Empty).Trim();
            if (value.Length == 0 || value == "0") return 0;

            int dot = value.IndexOf('.');
            if (dot < 0) return 0;
            return Math.Max(0, value.Length - dot - 1);
        }

        public static string NormalizeRoundText(string? text)
        {
            return DecimalsFromRoundText(text) switch
            {
                0 => "0",
                1 => "0.0",
                2 => "0.00",
                3 => "0.000",
                _ => "0.0000"
            };
        }
    }
}
