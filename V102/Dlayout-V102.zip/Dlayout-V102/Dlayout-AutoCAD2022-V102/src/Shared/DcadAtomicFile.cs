using System;
using System.IO;
using System.Text;
namespace LayoutMaterial
{
    internal static class DcadAtomicFile
    {
        internal static void WriteAllText(string path, string contents)
        {
            if (string.IsNullOrWhiteSpace(path)) throw new ArgumentException("Invalid DUser target");
            string folder = Path.GetDirectoryName(Path.GetFullPath(path));
            if (!Directory.Exists(folder)) throw new DirectoryNotFoundException("DUser missing: " + folder);
            string temp = Path.Combine(folder, "." + Path.GetFileName(path) + "." + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                {
                    writer.Write(contents); writer.Flush(); stream.Flush(true);
                }
                if (File.Exists(path)) File.Replace(temp, path, null, true);
                else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
}
