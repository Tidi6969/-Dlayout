using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace LayoutMaterial
{
    // DCPart-compatible embedded language store.  No runtime lang.dat dependency.
    internal static class Lang
    {
        private const string MisSetFileName = "MIS_SET.SET";
        private const int MisSetLanguageLineNumber = 28;
        private const int FallbackLangId = 0;
        private static int _currentLangId = FallbackLangId;
        private static bool _warnedThisCommand;
        private static readonly Dictionary<int, Dictionary<string, string>> Texts =
            new Dictionary<int, Dictionary<string, string>>();
        private static readonly Regex HeaderRegex = new Regex(
            @"^Lang_(\d+)\(([^_()]+)_([^_()]+)\)$", RegexOptions.Compiled);

        public static int CurrentLanguageId { get { return _currentLangId; } }
        public static void BeginCommand() { _warnedThisCommand = false; }

        public static void Reload()
        {
            Texts.Clear();
            _currentLangId = FallbackLangId;
            string content = ReadEmbeddedLangDat();
            if (string.IsNullOrEmpty(content))
            {
                Warn("Cannot read embedded lang.dat in Layout_material DLL; language translations unavailable.");
                return;
            }
            Parse(content);
            if (!Texts.ContainsKey(FallbackLangId))
            {
                Warn("Embedded lang.dat does not contain Lang_0(English_en-US).");
                return;
            }
            int requested = ReadLanguageId();
            if (Texts.ContainsKey(requested))
            {
                _currentLangId = requested;
                return;
            }
            Warn(F("LangWarnRequestedBlockMissing", requested) + " " + T("LangWarnFallbackSuffix"));
        }

        public static string T(string key)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;
            Dictionary<string, string> block;
            string value;
            if (Texts.TryGetValue(_currentLangId, out block) && block.TryGetValue(key, out value))
                return Decode(value);
            if (Texts.TryGetValue(FallbackLangId, out block) && block.TryGetValue(key, out value))
                return Decode(value);
            return key;
        }

        public static string F(string key, params object[] args)
        {
            string format = T(key);
            if (args == null || args.Length == 0) return format;
            try { return string.Format(CultureInfo.CurrentCulture, format, args); }
            catch (FormatException) { return format; }
        }

        private static string ReadEmbeddedLangDat()
        {
            try
            {
                Assembly asm = typeof(Lang).Assembly;
                string resource = asm.GetManifestResourceNames().FirstOrDefault(name =>
                    name.EndsWith(".lang.dat", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(name, "lang.dat", StringComparison.OrdinalIgnoreCase));
                if (string.IsNullOrEmpty(resource)) return null;
                using (Stream stream = asm.GetManifestResourceStream(resource))
                {
                    if (stream == null) return null;
                    using (var reader = new StreamReader(stream)) return reader.ReadToEnd();
                }
            }
            catch { return null; }
        }

        private static void Parse(string text)
        {
            int? currentId = null;
            Dictionary<string, string> current = null;
            foreach (string original in (text ?? "").Replace("\r\n", "\n").Replace('\r', '\n').Split('\n'))
            {
                string line = (original ?? "").Trim();
                if (line.Length == 0 || line.StartsWith("#") || line.StartsWith(";") || line.StartsWith("//")) continue;
                Match m = HeaderRegex.Match(line);
                if (m.Success)
                {
                    Flush(currentId, current);
                    currentId = int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
                    current = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    continue;
                }
                if (line == "-")
                {
                    Flush(currentId, current);
                    currentId = null;
                    current = null;
                    continue;
                }
                if (current == null) continue;
                int equals = line.IndexOf('=');
                if (equals <= 0) continue;
                string key = line.Substring(0, equals).Trim();
                if (key.Length > 0) current[key] = line.Substring(equals + 1);
            }
            Flush(currentId, current);
        }

        private static void Flush(int? id, Dictionary<string, string> block)
        {
            if (id.HasValue && block != null && block.Count > 0) Texts[id.Value] = block;
        }
        private static string Decode(string value)
        {
            return (value ?? "").Replace("\\r\\n", Environment.NewLine)
                .Replace("\\n", Environment.NewLine).Replace("\\t", "\t");
        }

        private static int ReadLanguageId()
        {
            string path;
            try
            {
                var all = RuntimeDataResolver.FindAllFilesInNamedFolder("DUser", MisSetFileName);
                if (all.Count > 1) Warn("MIS_SET_CONFLICT: " + string.Join("; ", all.ToArray()));
                path = all.Count == 0 ? null : all[0];
            }
            catch (Exception ex)
            {
                Warn("MIS_SET_PATH: " + ex.Message);
                return FallbackLangId;
            }
            if (string.IsNullOrEmpty(path) || !File.Exists(path))
            {
                Warn(T("LangWarnMisSetMissing") + " " + T("LangWarnFallbackSuffix"));
                return FallbackLangId;
            }
            try
            {
                string[] lines = File.ReadAllLines(path);
                if (lines.Length < MisSetLanguageLineNumber)
                {
                    Warn(T("LangWarnMisSetLineMissing") + " " + T("LangWarnFallbackSuffix"));
                    return FallbackLangId;
                }
                int langId;
                if (!TryParseLeadingInt(lines[MisSetLanguageLineNumber - 1], out langId) || langId < 0)
                {
                    Warn(T("LangWarnMisSetInvalid") + " " + T("LangWarnFallbackSuffix"));
                    return FallbackLangId;
                }
                return langId;
            }
            catch (Exception ex)
            {
                Warn(F("LangWarnMisSetReadError", ex.Message) + " " + T("LangWarnFallbackSuffix"));
                return FallbackLangId;
            }
        }

        private static bool TryParseLeadingInt(string raw, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(raw)) return false;
            Match m = Regex.Match(raw, @"[-+]?\d+");
            return m.Success && int.TryParse(m.Value, NumberStyles.Integer,
                CultureInfo.InvariantCulture, out value);
        }


        private static void Warn(string message)
        {
            if (_warnedThisCommand) return;
            _warnedThisCommand = true;
            string shown = "Layout_material - Language\n\n" + (message ?? "");
            // Keep missing-language diagnostics in command line; no blocking modal dialog.
            try
            {
                var doc = AcApp.DocumentManager.MdiActiveDocument;
                if (doc != null && doc.Editor != null) doc.Editor.WriteMessage("\n[Layout_material - Language] " + message);
            }
            catch { }
        }
    }
}
