using LayoutMaterial;

namespace LayoutMaterial.Models
{
    public sealed class LayoutRow
    {
        public double Area { get; set; }
        public double Pitch { get; set; }
        public double Height { get; set; }
        public double RotateDeg { get; set; }
        public double Gap { get; set; }
        public double Rate { get; set; }

        public override string ToString()
            => Lang.F("RowSummary", NumericFormat.FormatUpTo(RotateDeg, NumericFormat.CalculatorDecimals), NumericFormat.FormatUpTo(Pitch, NumericFormat.CalculatorDecimals), NumericFormat.FormatUpTo(Height, NumericFormat.CalculatorDecimals), NumericFormat.FormatUpTo(Gap, NumericFormat.CalculatorDecimals), NumericFormat.FormatUpTo(Rate, NumericFormat.CalculatorDecimals));
    }
}
