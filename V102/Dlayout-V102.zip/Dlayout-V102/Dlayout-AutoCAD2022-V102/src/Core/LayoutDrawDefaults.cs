namespace LayoutMaterial.Models
{
    public sealed class LayoutDrawDefaults
    {
        public double Thickness { get; set; }
        public string Material { get; set; } = "...";
        public int StationNo { get; set; } = 2;
        public string MaterRound { get; set; } = "0";
        public string PitchRound { get; set; } = "0";
        public string Feed { get; set; } = "Lft-to-Rg";
        public bool CreateInformation { get; set; }
        public bool XLineParallel { get; set; } = true;
        public bool YLineParallel { get; set; }
    }
}
