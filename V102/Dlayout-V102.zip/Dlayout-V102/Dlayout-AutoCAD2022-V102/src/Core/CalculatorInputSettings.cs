namespace LayoutMaterial.Models
{
    public sealed class CalculatorInputSettings
    {
        public double TopMargin { get; set; } = 5.0;
        public double BottomMargin { get; set; } = 5.0;
        public double NearestGap { get; set; } = 5.0;
        public int StartAngle { get; set; } = 5;
        public int EndAngle { get; set; } = 180;
        public int StepAngle { get; set; } = 2;
    }
}
