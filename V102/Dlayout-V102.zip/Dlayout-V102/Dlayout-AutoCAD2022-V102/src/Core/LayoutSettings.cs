namespace LayoutMaterial.Models
{
    public sealed class LayoutSettings
    {
        public int StationNo { get; set; } = 2;
        public double Thickness { get; set; }
        public string Material { get; set; } = "...";
        public double RotateDeg { get; set; }
        public double MaterWidth { get; set; }
        public double Upper { get; set; } = 4.0;
        public double Lower { get; set; } = 4.0;
        public double Pitch { get; set; }
        public double Gap { get; set; }
        public string Feed { get; set; } = "Lft-to-Rg"; // or "Rg-to-Lft"

        public double PartHeight { get; set; }
        public double PartWidth { get; set; }
        public double Rate { get; set; }
        public double Area { get; set; }
        public bool CreateInformation { get; set; }
        public bool XLineParallel { get; set; }
        public bool YLineParallel { get; set; }
    }
}
