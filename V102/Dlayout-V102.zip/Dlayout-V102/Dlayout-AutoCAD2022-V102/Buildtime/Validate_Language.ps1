﻿param([string]$Root)
if ([string]::IsNullOrWhiteSpace($Root)) { $Root = Split-Path -Parent $PSScriptRoot }
$ErrorActionPreference = 'Stop'
$langPath = Join-Path $Root 'Buildtime\lang.dat'
$srcPath = Join-Path $Root 'src'
if (-not (Test-Path $langPath)) { throw 'LANGUAGE QA FAIL: lang.dat missing.' }
$bytes = [IO.File]::ReadAllBytes($langPath)
if ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) { throw 'LANGUAGE QA FAIL: UTF-8 BOM not permitted.' }
$text = [Text.Encoding]::UTF8.GetString($bytes).Replace("`r`n","`n").Replace("`r","`n")
$blocks = @{}; $headers = @{}; $current = $null; $currentId = $null; $lineNo = 0
$headerRegex = [regex]'^Lang_(\d+)\(([^_()]+)_([^_()]+)\)$'
foreach ($raw in ($text -split "`n")) {
  $lineNo++
  $line = ($raw + '').Trim()
  if ($line.Length -eq 0 -or $line.StartsWith('#') -or $line.StartsWith(';') -or $line.StartsWith('//')) { continue }
  if ($line -eq '-') { $current = $null; $currentId = $null; continue }
  $match = $headerRegex.Match($line)
  if ($match.Success) {
    $id = [int]$match.Groups[1].Value
    if ($blocks.ContainsKey($id)) { throw "LANGUAGE QA FAIL: duplicate Lang_$id" }
    $current = @{}; $blocks[$id] = $current
    $headers[$id] = $match.Groups[2].Value + '_' + $match.Groups[3].Value
    $currentId = $id
    continue
  }
  if ($null -eq $current) { throw "LANGUAGE QA FAIL: content outside block at line $lineNo" }
  $eq = $line.IndexOf('=')
  if ($eq -le 0) { throw "LANGUAGE QA FAIL: invalid key=value at line $lineNo" }
  $key = $line.Substring(0, $eq).Trim(); $value = $line.Substring($eq + 1)
  if ($current.ContainsKey($key)) { throw "LANGUAGE QA FAIL: duplicate $key in Lang_$currentId" }
  if ([string]::IsNullOrWhiteSpace($value)) { throw "LANGUAGE QA FAIL: empty $key in Lang_$currentId" }
  $current[$key] = $value
}
$expected = @{ 0='English_en-US'; 1='Vietnamese_vi-VN'; 2='SimplifiedChinese_zh-CN'; 3='Japanese_ja-JP'; 4='Korean_ko-KR'; 5='Thai_th-TH' }
foreach ($id in 0..5) {
  if (-not $blocks.ContainsKey($id)) { throw "LANGUAGE QA FAIL: missing Lang_$id" }
  if ($headers[$id] -ne $expected[$id]) { throw "LANGUAGE QA FAIL: unexpected Lang_$id header" }
}
$base = @($blocks[0].Keys | Sort-Object)
foreach ($id in 0..5) {
  $missing = @($base | Where-Object { -not $blocks[$id].ContainsKey($_) })
  $extra = @($blocks[$id].Keys | Where-Object { -not $blocks[0].ContainsKey($_) })
  if ($missing.Count -or $extra.Count) { throw "LANGUAGE QA FAIL: Lang_$id key mismatch. Missing=$($missing -join ',') Extra=$($extra -join ',')" }
  foreach ($key in $base) {
    $expectedArgs = @([regex]::Matches($blocks[0][$key], '(?<!\{)\{\d+\}') | ForEach-Object { $_.Value } | Sort-Object -Unique)
    $actualArgs = @([regex]::Matches($blocks[$id][$key], '(?<!\{)\{\d+\}') | ForEach-Object { $_.Value } | Sort-Object -Unique)
    if (($expectedArgs -join ',') -ne ($actualArgs -join ',')) { throw "LANGUAGE QA FAIL: Lang_$id.$key placeholder mismatch" }
  }
}
$used = @{}
Get-ChildItem -Path $srcPath -Recurse -Filter '*.cs' -File | ForEach-Object {
  $source = [IO.File]::ReadAllText($_.FullName)
  foreach ($m in [regex]::Matches($source, 'Lang\.(?:T|F)\(\s*"([^"]+)"\s*(?=[,\)])')) { $used[$m.Groups[1].Value] = $true }
}
$missingSrc = @($used.Keys | Where-Object { -not $blocks[0].ContainsKey($_) })
if ($missingSrc.Count) { throw ('LANGUAGE QA FAIL: source keys missing: ' + ($missingSrc -join ', ')) }
Write-Output ("LANGUAGE QA PASS: {0} languages, {1} keys/language, {2} referenced keys." -f $blocks.Count, $base.Count, $used.Count)
