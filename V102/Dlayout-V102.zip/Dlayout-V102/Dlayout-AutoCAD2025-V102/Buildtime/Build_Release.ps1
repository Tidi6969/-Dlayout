﻿param()
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$LogDir = Join-Path $Root 'log'
$BinDir = Join-Path $Root 'bin'
$ObjDir = Join-Path $Root 'obj'
$LogFile = Join-Path $LogDir 'Build-V102.log'
New-Item -ItemType Directory -Force -Path $LogDir,$BinDir | Out-Null
if (Test-Path $LogFile) { Remove-Item $LogFile -Force }
function Log([string]$Value) { $Value | Tee-Object -FilePath $LogFile -Append }
function Fail([string]$Value) { Log ('FAIL: ' + $Value); exit 1 }
function RunStep([string]$Label,[string]$Exe,[string[]]$Params) {
    Log ('[' + $Label + ']')
    & $Exe @Params 2>&1 | ForEach-Object { Log ([string]$_) }
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) { Fail ($Label + ' exited ' + $exitCode) }
}
Log 'Dlayout V102 AutoCAD2025'
$validator = Join-Path $Root 'Buildtime\Validate_Language.ps1'
if (-not (Test-Path $validator)) { Fail 'Language validator missing.' }
RunStep 'LANGUAGE QA' 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File',$validator)
$refs = @('AcCoreMgd.dll','AcDbMgd.dll','AcMgd.dll')
foreach ($dll in $refs) {
    if (-not (Test-Path (Join-Path $Root ('Reference\' + $dll)))) { Fail ('Missing CAD SDK: ' + $dll) }
}
$extras = @(Get-ChildItem (Join-Path $Root 'Reference') -File | Where-Object { $_.Name -notin $refs })
if ($extras.Count -ne 0) { Fail ('Unexpected SDK DLL: ' + ($extras.Name -join ',')) }
$dotnet = Get-Command dotnet.exe -ErrorAction SilentlyContinue
if (-not $dotnet) { Fail 'Install .NET 8 SDK.' }
$sdks = @(& $dotnet.Source --list-sdks)
if (-not @($sdks | Where-Object { $_ -match '^8\.' }).Count) { Fail '.NET 8 SDK is required.' }
$selectedSdk = (& $dotnet.Source --version | Select-Object -First 1).Trim()
if ($selectedSdk -notmatch '^8\.') { Fail ('global.json did not select .NET 8: ' + $selectedSdk) }
if (Test-Path $ObjDir) { Remove-Item $ObjDir -Recurse -Force }
Get-ChildItem $BinDir -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse
$proj = Join-Path $Root 'Layout_material.csproj'
RunStep 'RESTORE' $dotnet.Source @('restore',$proj,'-p:Platform=x64','--verbosity','minimal')
RunStep 'BUILD' $dotnet.Source @('build',$proj,'-c','Release','-p:Platform=x64','--no-restore','--verbosity','minimal')
$out = Join-Path $BinDir 'DlayoutC25.dll'
if (-not (Test-Path $out)) { Fail ('Output file missing: ' + $out) }
$others = @(Get-ChildItem $BinDir -File | Where-Object { $_.Name -ne 'DlayoutC25.dll' })
if ($others.Count -gt 0) { $others | Remove-Item -Force }
Log ('BUILD PASS: ' + $out)
Log 'NETLOAD=NOT VERIFIED'
exit 0
