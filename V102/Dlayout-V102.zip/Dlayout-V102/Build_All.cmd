@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "ROOT=%~dp0"
cd /d "%ROOT%"
set "LOGDIR=%ROOT%log"
set "OUT=%ROOT%Dprogram"
set "STAGE=%ROOT%Dprogram.stage"
set "BUILD_EXIT_CODE=0"
set "DSTATUS=NOT RUN"
set "TSTATUS=NOT RUN"
set "CSTATUS=NOT RUN"
set "A25STATUS=NOT RUN"
set "G27STATUS=NOT RUN"
set "PSTATUS=NOT RUN"
set "NO_PAUSE=0"
if /I "%~1"=="/nopause" set "NO_PAUSE=1"
set "USE_PS=0"
if not defined NO_COLOR (
    where powershell.exe >nul 2>&1
    if not errorlevel 1 set "USE_PS=1"
)
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
if not exist "%LOGDIR%" (
    echo [FAIL] Cannot create log folder: "%LOGDIR%"
    set "BUILD_EXIT_CODE=1"
    goto :FINISH
)
set "MAINLOG=%LOGDIR%\Build_All.log"
set "STATUS=%LOGDIR%\BUILD-STATUS.txt"
>"%MAINLOG%" echo DLAYOUT V102 - BUILD ALL - %DATE% %TIME%
call :REPORT HEADER "DLAYOUT V102 - RELEASE x64 - BUILD ALL"
call :REPORT INFO "Targets: Desktop .NET 8, AutoCAD 2022 .NET Framework 4.8, AutoCAD 2025 .NET 8, GstarCAD 2027 .NET 8"

rem Stale output must not be mistaken for a successful NEW build.
if exist "%STAGE%" rmdir /s /q "%STAGE%" >nul 2>&1
if exist "%OUT%" rmdir /s /q "%OUT%" >nul 2>&1
if exist "%STAGE%" (
    call :REPORT FAIL "Old staging output is locked: %STAGE%"
    set "BUILD_EXIT_CODE=1"
)
if exist "%OUT%" (
    call :REPORT FAIL "Old published output is locked: %OUT%"
    set "BUILD_EXIT_CODE=1"
)
if not "%BUILD_EXIT_CODE%"=="0" goto :FINISH

call :TARGET DSTATUS "Desktop .NET 8 / win-x64" "Dlayout-Desktop-V102" "Desktop.log" "bin\Publish\Dlayout.exe"

call :REPORT BUILD "Desktop DXF / CAD protocol SelfTest"
if not "%DSTATUS%"=="PASS" goto :TEST_SKIP
"%ROOT%Dlayout-Desktop-V102\bin\Publish\Dlayout.exe" --selftest "%ROOT%Dlayout-Desktop-V102\Data\Benchmarks\RedYellow-A2.dxf" "%ROOT%Dlayout-Desktop-V102\Data\Benchmarks\RedYellow-AB.dxf" "%ROOT%Dlayout-Desktop-V102\Data\Benchmarks\Three-Part-V63.dxf" >"%LOGDIR%\SelfTest.log" 2>&1
set "TEST_RC=%ERRORLEVEL%"
if not "%TEST_RC%"=="0" goto :TEST_FAIL
if not exist "%ROOT%Dlayout-Desktop-V102\bin\Publish\Dlayout-SelfTest.log" goto :TEST_FAIL
findstr /C:"DLAYOUT V102 SELFTEST PASS" "%ROOT%Dlayout-Desktop-V102\bin\Publish\Dlayout-SelfTest.log" >nul 2>&1
if errorlevel 1 goto :TEST_FAIL
set "TSTATUS=PASS"
call :REPORT PASS "Desktop SelfTest"
goto :TEST_END
:TEST_FAIL
set "TSTATUS=FAIL"
set "BUILD_EXIT_CODE=1"
call :REPORT FAIL "Desktop SelfTest (see log\SelfTest.log)"
goto :TEST_END
:TEST_SKIP
>"%LOGDIR%\SelfTest.log" echo SKIPPED: Desktop build not successful.
set "TSTATUS=SKIPPED"
call :REPORT WARNING "SelfTest skipped (Desktop FAIL)"
:TEST_END
call :TARGET CSTATUS "AutoCAD 2022 / net48 x64" "Dlayout-AutoCAD2022-V102" "AutoCAD2022.log" "bin\DlayoutC22.dll"
call :TARGET A25STATUS "AutoCAD 2025 / net8.0-windows x64" "Dlayout-AutoCAD2025-V102" "AutoCAD2025.log" "bin\DlayoutC25.dll"
call :TARGET G27STATUS "GstarCAD 2027 / net8.0-windows x64" "Dlayout-Gstarcad2027-V102" "GstarCAD2027.log" "bin\DlayoutG27.dll"


call :REPORT BUILD "Publish portable Dprogram"
if not "%BUILD_EXIT_CODE%"=="0" goto :PUBLISH_SKIP
if not "%DSTATUS%"=="PASS" goto :PUBLISH_SKIP
if not "%TSTATUS%"=="PASS" goto :PUBLISH_SKIP
if not "%CSTATUS%"=="PASS" goto :PUBLISH_SKIP
if not "%A25STATUS%"=="PASS" goto :PUBLISH_SKIP
if not "%G27STATUS%"=="PASS" goto :PUBLISH_SKIP
mkdir "%STAGE%\Dlayout" >nul 2>&1
if errorlevel 1 goto :PUBLISH_FAIL
copy /Y "%ROOT%Dlayout-AutoCAD2022-V102\bin\DlayoutC22.dll" "%STAGE%\DlayoutC22.dll" >nul 2>&1
if errorlevel 1 goto :PUBLISH_FAIL
copy /Y "%ROOT%Dlayout-AutoCAD2025-V102\bin\DlayoutC25.dll" "%STAGE%\DlayoutC25.dll" >nul 2>&1
if errorlevel 1 goto :PUBLISH_FAIL
copy /Y "%ROOT%Dlayout-Gstarcad2027-V102\bin\DlayoutG27.dll" "%STAGE%\DlayoutG27.dll" >nul 2>&1
if errorlevel 1 goto :PUBLISH_FAIL
if errorlevel 1 goto :PUBLISH_FAIL
copy /Y "%ROOT%Dlayout-Desktop-V102\bin\Publish\Dlayout.exe" "%STAGE%\Dlayout\Dlayout.exe" >nul 2>&1
if errorlevel 1 goto :PUBLISH_FAIL
if exist "%ROOT%Dlayout-Desktop-V102\THIRD_PARTY_NOTICES.txt" copy /Y "%ROOT%Dlayout-Desktop-V102\THIRD_PARTY_NOTICES.txt" "%STAGE%\Dlayout\THIRD_PARTY_NOTICES.txt" >nul 2>&1
if not exist "%STAGE%\DlayoutC22.dll" goto :PUBLISH_FAIL
if not exist "%STAGE%\DlayoutC25.dll" goto :PUBLISH_FAIL
if not exist "%STAGE%\DlayoutG27.dll" goto :PUBLISH_FAIL
if not exist "%STAGE%\Dlayout\Dlayout.exe" goto :PUBLISH_FAIL
ren "%STAGE%" "Dprogram"
if errorlevel 1 goto :PUBLISH_FAIL
set "PSTATUS=PASS"
call :REPORT PASS "Dprogram publish"
goto :FINISH
:PUBLISH_FAIL
set "BUILD_EXIT_CODE=1"
set "PSTATUS=FAIL"
call :REPORT FAIL "Dprogram publish (copy/rename failed)"
goto :FINISH
:PUBLISH_SKIP
set "PSTATUS=SKIPPED"
call :REPORT WARNING "Dprogram skipped; one or more checks failed"
goto :FINISH

rem Argument contract: %~1 status variable, %~2 display label,
rem %~3 actual project directory, %~4 log name, %~5 required fresh output.
:TARGET
call :REPORT BUILD "%~2"
set "%~1=FAIL"
set "CHILD=%ROOT%%~3\Build_Release.cmd"
set "CHILDOUT=%ROOT%%~3\%~5"
set "CHILDLOG=%LOGDIR%\%~4"
if not exist "%CHILD%" (
    >"%CHILDLOG%" echo MISSING BUILD SCRIPT: "%CHILD%"
    call :REPORT FAIL "%~2 - missing Build_Release.cmd"
    set "BUILD_EXIT_CODE=1"
    exit /b 0
)
rem Delete only the output of THIS target, so an old file cannot create false PASS.
if exist "%CHILDOUT%" del /f /q "%CHILDOUT%" >nul 2>&1
if exist "%CHILDOUT%" (
    >"%CHILDLOG%" echo OLD OUTPUT LOCKED: "%CHILDOUT%"
    call :REPORT FAIL "%~2 - old output cannot be removed"
    set "BUILD_EXIT_CODE=1"
    exit /b 0
)
call "%CHILD%" /nopause >"%CHILDLOG%" 2>&1
set "CHILD_RC=%ERRORLEVEL%"
if not "%CHILD_RC%"=="0" (
    call :REPORT FAIL "%~2 - exit code %CHILD_RC% (see log\%~4)"
    set "BUILD_EXIT_CODE=1"
    exit /b 0
)
if not exist "%CHILDOUT%" (
    call :REPORT FAIL "%~2 - output file missing: %~5"
    set "BUILD_EXIT_CODE=1"
    exit /b 0
)
set "%~1=PASS"
call :REPORT PASS "%~2"
exit /b 0

rem Color is purely cosmetic and never participates in build decisions.
rem Root log stays plain text (no embedded ANSI control sequences).
:REPORT
set "KIND=%~1"
set "MSG=%~2"
if defined MAINLOG >>"%MAINLOG%" echo [%KIND%] %MSG%
if "%USE_PS%"=="1" (
    if /I "%KIND%"=="HEADER" (powershell.exe -NoProfile -NonInteractive -Command "Write-Host '========== %MSG% ==========' -ForegroundColor Cyan" & exit /b 0)
    if /I "%KIND%"=="BUILD" (powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[BUILD] %MSG%' -ForegroundColor Blue" & exit /b 0)
    if /I "%KIND%"=="PASS" (powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[PASS] %MSG%' -ForegroundColor Green" & exit /b 0)
    if /I "%KIND%"=="FAIL" (powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[FAIL] %MSG%' -ForegroundColor Red" & exit /b 0)
    if /I "%KIND%"=="WARNING" (powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[WARNING] %MSG%' -ForegroundColor Yellow" & exit /b 0)
)
echo [%KIND%] %MSG%
exit /b 0

:FINISH
if exist "%STAGE%" rmdir /s /q "%STAGE%" >nul 2>&1
if not "%BUILD_EXIT_CODE%"=="0" (
    if exist "%OUT%" rmdir /s /q "%OUT%" >nul 2>&1
)
if defined STATUS (
    >"%STATUS%" echo DLAYOUT V102 BUILD RESULT
    >>"%STATUS%" echo Desktop EXE      : %DSTATUS%
    >>"%STATUS%" echo Desktop SelfTest : %TSTATUS%
    >>"%STATUS%" echo AutoCAD 2022 DLL : %CSTATUS%
    >>"%STATUS%" echo AutoCAD 2025 DLL : %A25STATUS%
    >>"%STATUS%" echo GstarCAD 2027 DLL: %G27STATUS%
    >>"%STATUS%" echo Portable Dprogram: %PSTATUS%
    >>"%STATUS%" echo NETLOAD         : NOT VERIFIED
)
echo.
call :REPORT HEADER "BUILD RESULT - DLAYOUT V102"
echo Desktop EXE       : %DSTATUS%
echo Desktop SelfTest  : %TSTATUS%
echo AutoCAD 2022 DLL  : %CSTATUS%
echo AutoCAD 2025 DLL  : %A25STATUS%
echo GstarCAD 2027 DLL : %G27STATUS%
echo Portable Dprogram : %PSTATUS%
if "%BUILD_EXIT_CODE%"=="0" (
    call :REPORT PASS "BUILD ALL: PASS"
    title DLAYOUT V102 - BUILD ALL PASS
    if defined STATUS >>"%STATUS%" echo BUILD ALL: PASS
) else (
    call :REPORT FAIL "BUILD ALL: FAIL"
    title DLAYOUT V102 - BUILD ALL FAIL
    if defined STATUS >>"%STATUS%" echo BUILD ALL: FAIL
)
if defined LOGDIR echo Logs: "%LOGDIR%"
echo NETLOAD / real CAD check: NOT VERIFIED
if defined MAINLOG >>"%MAINLOG%" echo Finished: %DATE% %TIME%
if not "%BUILD_EXIT_CODE%"=="0" (
    echo.
    echo ---------- ERROR DETAILS ----------
    if defined LOGDIR (
        if exist "%LOGDIR%\Desktop.log" findstr /I /C:"error " /C:"FAIL" /C:"Exception" "%LOGDIR%\Desktop.log"
        if exist "%LOGDIR%\SelfTest.log" findstr /I /C:"error " /C:"FAIL" /C:"Exception" "%LOGDIR%\SelfTest.log"
        if exist "%LOGDIR%\AutoCAD2022.log" findstr /I /C:"error " /C:"FAIL" /C:"Exception" "%LOGDIR%\AutoCAD2022.log"
        if exist "%LOGDIR%\AutoCAD2025.log" findstr /I /C:"error " /C:"FAIL" /C:"Exception" "%LOGDIR%\AutoCAD2025.log"
        if exist "%LOGDIR%\GstarCAD2027.log" findstr /I /C:"error " /C:"FAIL" /C:"Exception" "%LOGDIR%\GstarCAD2027.log"
    )
    echo ---------- END DETAILS ------------
)
echo.
if "%NO_PAUSE%"=="0" (
    echo Nhan phim bat ky de thoat... / Press any key to close this window...
    pause >nul
)
endlocal & exit /b %BUILD_EXIT_CODE%
