@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "NO_PAUSE=0"
if /I "%~1"=="/nopause" set "NO_PAUSE=1"
set "BUILD_EXIT_CODE=1"
if not exist "log" mkdir "log" >nul 2>&1
if not exist "log" (
    echo [FAIL] Cannot create AutoCAD 2022 log directory.
    goto :FINISH
)
if not exist "Buildtime\Build_Release.ps1" (
    echo [FAIL] Missing Buildtime\Build_Release.ps1
    goto :FINISH
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Buildtime\Build_Release.ps1"
set "BUILD_EXIT_CODE=%ERRORLEVEL%"
if not "%BUILD_EXIT_CODE%"=="0" goto :FINISH
if not exist "bin\DlayoutC22.dll" set "BUILD_EXIT_CODE=1"
:FINISH
if "%BUILD_EXIT_CODE%"=="0" (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[PASS] AutoCAD 2022 V105 - bin\DlayoutC22.dll' -ForegroundColor Green"
) else (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[FAIL] AutoCAD 2022 V105 - see log\Build-V105.log' -ForegroundColor Red"
)
if "%NO_PAUSE%"=="0" (
    echo Nhan phim bat ky de thoat... / Press any key to close this window...
    pause >nul
)
endlocal & exit /b %BUILD_EXIT_CODE%
