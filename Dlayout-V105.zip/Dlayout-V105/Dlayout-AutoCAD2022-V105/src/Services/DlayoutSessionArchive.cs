using System;
using System.IO;
using System.Text;

namespace LayoutMaterial.Services
{
    internal static class DlayoutSessionArchive
    {
        internal static void Finish(string jobDir, bool successOrCleanCancel, string details, Action<string> report)
        {
            if (string.IsNullOrEmpty(jobDir) || !Directory.Exists(jobDir)) return;
            if (successOrCleanCancel)
            {
                try { Directory.Delete(jobDir, true); }
                catch (Exception ex)
                {
                    try { File.WriteAllText(Path.Combine(jobDir, ".completed"), DateTime.UtcNow.ToString("O")); }
                    catch { }
                    report("[DLAYOUT] Completed session cleanup deferred: " + ex.Message);
                }
                return;
            }
            string folder = Path.Combine(Path.GetDirectoryName(DlayoutSettingsStore.PathName),
                "Dlayout_diagnostics", Path.GetFileName(jobDir));
            try
            {
                Directory.CreateDirectory(folder);
                foreach (string source in Directory.GetFiles(jobDir))
                    File.Copy(source, Path.Combine(folder, Path.GetFileName(source)), true);
                File.WriteAllText(Path.Combine(folder, "error.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " V105\r\n" +
                    (details ?? "Dlayout did not complete its CAD session.") + "\r\n", new UTF8Encoding(false));
                report("[DLAYOUT] Diagnostic data retained: " + folder);
                TryDelete(jobDir);
            }
            catch (Exception ex)
            {
                report("[DLAYOUT] Cannot archive session: " + ex.Message +
                    "; temporary data retained at " + jobDir);
            }
        }
        internal static void CleanupStaleCompleted()
        {
            // Never delete unmarked sessions: a CAD crash may have left a failed JOB.
            string baseFolder = Path.Combine(Path.GetTempPath(), "DCAD", "DlayoutBridge");
            if (!Directory.Exists(baseFolder)) return;
            foreach (string folder in Directory.GetDirectories(baseFolder))
            {
                try
                {
                    string marker = Path.Combine(folder, ".completed");
                    if (File.Exists(marker) && File.GetLastWriteTimeUtc(marker) < DateTime.UtcNow.AddDays(-7))
                        Directory.Delete(folder, true);
                }
                catch { /* Never interrupt CAD for stale-temp housekeeping. */ }
            }
        }
        private static void TryDelete(string path) { try { Directory.Delete(path, true); } catch { } }
    }
}
