using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using LayoutMaterial.Models;
using LayoutMaterial.Services;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace LayoutMaterial.Commands
{
    // V70 protocol 2: CAD selects ORIGINAL outer silhouettes and Desktop solves
    // their STEP quantities. CAD draws a selected result from ORIGINAL entities,
    // preserving exact polyline bulges / circle curvature, not sampled DXF edges.
    public sealed class DlayoutMultiCommand
    {
        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        private const int MaxTypes = 12;
        internal sealed class SourcePart
        {
            public ObjectId Id;
            public string Handle;
            public Point3d Center;
            public List<Point2d> Polygon;
            public double SignedArea;
            public double GrossArea;
            public double NetArea;
            public readonly List<ObjectId> InnerContours = new List<ObjectId>();
            public readonly List<List<Point2d>> PreviewExtras = new List<List<Point2d>>();
        }
        internal sealed class CadSolution
        {
            public List<Placement> Placements;
            public double Pitch, Width, Score;
            // Global angle tested by the optimizer; distinct from each part's own rotation.
            public double RelativeAngle = double.NaN;
            public int OriginalIndex;
        }
        internal sealed class Placement
        {
            public SourcePart Source;
            public string Handle;
            public Point2d Center;
            public double Angle;
        }

        // Only public CAD command: DLAYOUT. The old DLAYOUTM alias was removed in V98.
        [CommandMethod("DLAYOUT")]
        public void Dlayout()
        {
            var doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;
            RuntimeDataResolver.ClearRuntimePathCache();
            Lang.BeginCommand();
            Lang.Reload();
            Run(doc);
        }

        internal void Run(Document doc)
        {
            var ed = doc.Editor;
            var db = doc.Database;
            string jobDir = null;
            bool cleanSession = false;
            string failure = "Desktop session ended without confirmed CAD insertion.";
            try
            {
                DlayoutSessionArchive.CleanupStaleCompleted();
                // Require a uniquely DIRECT-registered DUser before CAD workflows
                // that load or persist drawing settings (DCAD-STD-05 V1.6).
                StripDisplaySettings initialDisplay = StripDisplaySettingsStore.Load();
                // Only one allowed location: <DIRECT DProgram>\Dlayout\Dlayout.exe.
                // If missing, stop with an actionable localized setup message.
                string exeError;
                string exe = FindDesktopExecutable(out exeError);
                if (exe == null)
                {
                    ed.WriteMessage("\n" + exeError);
                    try { AcApp.ShowAlertDialog(exeError); } catch { /* Command line message is authoritative. */ }
                    return;
                }
                // Prevent a stale Desktop EXE from silently running against V105 CAD DLL.
                var desktopVersion = FileVersionInfo.GetVersionInfo(exe);
                string[] versionParts = (desktopVersion.FileVersion ?? "").Split('.');
                bool versionOk = (versionParts.Length >= 3 && versionParts[2] == "105") ||
                    (versionParts.Length >= 1 && versionParts[0] == "105");
                if (!versionOk) throw new InvalidOperationException(
                    "Dlayout.exe version mismatch: expected V105, found " +
                    (desktopVersion.FileVersion ?? "unknown") + ". Copy the V105 Dlayout.exe to DProgram\\Dlayout.");
                ed.WriteMessage("\n[DLAYOUT] EXE: " + exe + " (" + desktopVersion.FileVersion + ")");
                // Preload during CAD selection, as in DNesting V38.
                using (var preload = DlayoutPreloadSession.Start(exe, Lang.CurrentLanguageId))
                {
                var opt = new PromptSelectionOptions { MessageForAdding = Lang.T("MultiSelect") };
                ed.WriteMessage("\n" + Lang.T("MultiLayerSelectionNotice"));
                PromptSelectionResult chosen;
                using (var layerScope = new CadSelectionLayerScope(db, ed))
                    chosen = ed.GetSelection(opt);
                if (chosen.Status != PromptStatus.OK || chosen.Value == null) return;
                // V98: accept whole mixed CAD selection; automatically extract
                // outer silhouettes and rigidly group their selected contents.
                var ids = new List<ObjectId>();
                foreach (SelectedObject so in chosen.Value)
                    if (so != null && so.ObjectId.IsValid) ids.Add(so.ObjectId);
                var parts = CadSelectionGrouper.Build(db, ids, Tessellate,
                    message => ed.WriteMessage("\n" + message));
                if (parts.Count < 1) throw new InvalidOperationException(Lang.T("MultiNeedOne"));
                if (parts.Count > MaxTypes) throw new InvalidOperationException(Lang.T("MultiMaxContour"));
                // Only SELECTED closed interiors count as holes; touching,
                // open, or annotation geometry follows the group without being
                // subtracted from usable material area.
                parts = CadHoleScanner.Scan(db, parts, Tessellate, Inside, ed);
                if (parts.Count == 0) throw new InvalidOperationException(Lang.T("GroupNoSafe"));

                // One authoritative INI; corrupted values must not be silently ignored.
                var defaults = DlayoutSettingsStore.LoadCalculation();
                string id = Guid.NewGuid().ToString("N");
                var body = new XElement("parts");
                foreach (var source in parts)
                {
                    var el = new XElement("part", new XAttribute("handle", source.Handle),
                        new XAttribute("cx", Num(source.Center.X)), new XAttribute("cy", Num(source.Center.Y)),
                        new XAttribute("netArea", Num(source.NetArea)));
                    foreach (var p in source.Polygon)
                        el.Add(new XElement("p", new XAttribute("x", Num(p.X)), new XAttribute("y", Num(p.Y))));
                    body.Add(el);
                }
                var request = new XElement("dlayoutJob", new XAttribute("protocol", "2"),
                    new XAttribute("id", id), new XAttribute("version", "98"),
                    new XAttribute("language", Lang.CurrentLanguageId),
                    new XAttribute("duser", Path.GetDirectoryName(DlayoutSettingsStore.PathName)),
                    new XAttribute("gap", Num(Math.Max(0, defaults.NearestGap))),
                    new XAttribute("top", Num(Math.Max(0, defaults.TopMargin))),
                    new XAttribute("bottom", Num(Math.Max(0, defaults.BottomMargin))), body);
                jobDir = Path.Combine(Path.GetTempPath(), "DCAD", "DlayoutBridge", id);
                Directory.CreateDirectory(jobDir);
                string jobPath = Path.Combine(jobDir, "job.xml");
                string resultPath = Path.Combine(jobDir, "result.xml");
                new XDocument(request).Save(jobPath);
                // V98: Keep the preloaded process hidden while CAD finishes its selection
                // UI. Only dispatch the job AFTER the CAD modal gate is visible and a
                // short WinForms message-pump settle period has elapsed. This prevents
                // CAD's floating cursor/Dynamic Input tooltip from being painted over
                // the separately hosted Desktop window during the CAD->EXE transition.
                using (var wait = new DlayoutDesktopWaitForm(preload, jobPath, resultPath))
                {
                    // The modal CAD gate stays active until Desktop exits. A result
                    // is never applied while the Desktop is still running.
                    DialogResult waitResult = AcApp.ShowModalDialog(wait);
                    if (wait.DispatchError != null) throw wait.DispatchError;
                    if (waitResult != DialogResult.OK || !File.Exists(resultPath))
                    {
                        string trace = Path.Combine(jobDir, "session.log");
                        string traceText = File.Exists(trace) ? File.ReadAllText(trace) : "";
                        // A deliberate close without a Calculate attempt is a normal cancel.
                        // If Calculate was attempted, keep the JOB even when no result was created.
                        bool finished = !traceText.Contains("CALCULATE_CLICK") ||
                            traceText.Contains("OPTIMIZER_DONE") || traceText.Contains("OPTIMIZER_CANCELLED");
                        cleanSession = traceText.Contains("JOB_VALIDATED") &&
                            traceText.Contains("USER_CLOSED") && finished &&
                            !traceText.Contains("ERROR:") && !traceText.Contains("INPUT_INVALID") &&
                            !traceText.Contains("NO_SOLUTION");
                        failure = "Desktop exited without result.xml. " + traceText;
                        ed.WriteMessage("\n" + Lang.T("MultiCancelled"));
                        return;
                    }
                }
                var answer = XDocument.Load(resultPath).Root;
                var requestRoot = request;
                var solutions = ParseSolutions(requestRoot, answer, parts,
                    out int selectedIndex, out double top, out double bottom);
                double gap = Read(answer, "gap");
                // Reuse exactly the same Desktop results when choosing another option.
                // No optimizer rerun and no CAD geometry mutation until Commit.
                int currentIndex = selectedIndex;
                while (true)
                {
                    CadSolution solution;
                    using (var picker = new CadSolutionPicker(solutions, currentIndex, bottom, initialDisplay))
                    {
                        if (AcApp.ShowModalDialog(picker) != DialogResult.OK || picker.Selected == null)
                        { cleanSession = true; return; }
                        solution = picker.Selected;
                        currentIndex = solutions.IndexOf(solution);
                    }
                    var edit = new CadStripEditor(doc, solution.Placements, solution.Pitch,
                        solution.Width, top, bottom, gap);
                    if (!edit.EditAndPick())
                    {
                        if (edit.BackToSolutions) continue;
                        cleanSession = true;
                        return;
                    }
                    edit.Commit();
                    ed.Regen();
                    ed.WriteMessage("\n" + Lang.T("MultiApplied") + "  P=" + edit.Pitch.ToString("0.###", Inv) +
                        "  W=" + edit.Width.ToString("0.###", Inv) + "  η=" + edit.Efficiency.ToString("0.##", Inv) + "%");
                    break;
                }
                cleanSession = true; // Exact CAD commit + display completed.
                } // preload session
            }
            catch (System.Exception ex)
            {
                failure = ex.ToString();
                ed.WriteMessage("\n" + Lang.F("MultiError", ex.Message));
            }
            finally
            {
                // A successful CAD commit / clean cancellation removes temporary data.
                // Any unsuccessful calculation or failed transfer is copied to DUser.
                DlayoutSessionArchive.Finish(jobDir, cleanSession, failure,
                    message => ed.WriteMessage("\n" + message));
            }
        }

        private static string FindDesktopExecutable(out string error)
        {
            error = null;
            string programDirectory;
            try
            {
                // This resolver only accepts a DIRECT Support File Search Path entry.
                // Multiple DProgram entries are an error, never choose the first.
                programDirectory = RuntimeDataResolver.FindNamedFolder("DProgram", false);
            }
            catch (System.Exception ex)
            {
                error = Lang.F("MultiDesktopPathError", ex.Message) +
                    "\n" + Lang.T("MultiDesktopSetupHelp");
                return null;
            }
            if (string.IsNullOrWhiteSpace(programDirectory))
            {
                error = Lang.T("MultiDesktopFolderMissing") +
                    "\n" + Lang.T("MultiDesktopSetupHelp");
                return null;
            }
            // No registry, Program Files, EXE/DLL directory, recursion, or fallback.
            string requiredPath = Path.GetFullPath(
                Path.Combine(programDirectory, "Dlayout", "Dlayout.exe"));
            if (!File.Exists(requiredPath))
            {
                error = Lang.F("MultiDesktopFileMissing", requiredPath) +
                    "\n" + Lang.T("MultiDesktopSetupHelp");
                return null;
            }
            return requiredPath;
        }
        private static string Num(double d) { return d.ToString("R", Inv); }
        private static double Read(XElement e, string attr)
        {
            double v;
            if (e == null || !double.TryParse((string)e.Attribute(attr), NumberStyles.Float, Inv, out v) ||
                double.IsInfinity(v) || double.IsNaN(v))
                throw new InvalidDataException("Invalid result attribute " + attr);
            return v;
        }
        private static double ReadOptional(XElement e, string attr)
        {
            if (e == null || e.Attribute(attr) == null) return double.NaN;
            double value;
            if (!double.TryParse((string)e.Attribute(attr), NumberStyles.Float, Inv, out value) ||
                double.IsNaN(value) || double.IsInfinity(value))
                throw new InvalidDataException("Invalid optional result attribute " + attr);
            return value;
        }
        private static List<CadSolution> ParseSolutions(XElement request, XElement answer,
            List<SourcePart> parts, out int selectedIndex, out double top, out double bottom)
        {
            if (answer == null || (string)answer.Attribute("protocol") != "2" ||
                (string)answer.Attribute("id") != (string)request.Attribute("id") ||
                (string)answer.Attribute("status") != "COMPLETED")
                throw new InvalidDataException("Dlayout CAD result mismatch.");
            top = Read(answer,"top"); bottom = Read(answer,"bottom");
            var archive = answer.Element("solutions");
            selectedIndex = 0;
            var results = new List<CadSolution>();
            if (archive == null)
            {
                var single=ParseResult(request, answer, parts, out double p,
                    out double unusedTop, out double unusedBottom);
                results.Add(new CadSolution { Placements=single, Pitch=p,
                    Width=Read(answer,"width"), RelativeAngle=ReadOptional(answer,"relativeAngle"), OriginalIndex=0 });
                return results;
            }
            var nodes = archive.Elements("solution").ToList();
            if (nodes.Count < 1 || nodes.Count > 500)
                throw new InvalidDataException("CAD archive must contain 1-500 results.");
            if (!int.TryParse((string)archive.Attribute("selected"), out selectedIndex) ||
                selectedIndex < 0 || selectedIndex >= nodes.Count)
                throw new InvalidDataException("Invalid selected solution index.");
            HashSet<string> baseline = null;
            for (int i=0;i<nodes.Count;i++)
            {
                var element = nodes[i];
                // Re-use the verified V70 identity/finite-number checks for
                // every archived candidate, without trusting XML transforms.
                var wrapped = new XElement("dlayoutResult",
                    new XAttribute("protocol","2"),
                    new XAttribute("id",(string)answer.Attribute("id")),
                    new XAttribute("status","COMPLETED"),
                    new XAttribute("copies","2"),
                    new XAttribute("pitch",(string)element.Attribute("pitch")),
                    new XAttribute("width",(string)element.Attribute("width")),
                    new XAttribute("gap",(string)answer.Attribute("gap")),
                    new XAttribute("top",(string)answer.Attribute("top")),
                    new XAttribute("bottom",(string)answer.Attribute("bottom")),
                    new XElement(element.Element("placements")));
                var placed = ParseResult(request,wrapped,parts,out double pitch,
                    out double readTop,out double readBottom);
                var handles = new HashSet<string>(placed.Select(x=>x.Handle),StringComparer.OrdinalIgnoreCase);
                if (baseline==null) baseline=handles;
                else if (!baseline.SetEquals(handles))
                    throw new InvalidDataException("Different parts in CAD result archive.");
                results.Add(new CadSolution { Placements=placed,Pitch=pitch,
                    Width=Read(element,"width"),Score=Read(element,"score"),
                    RelativeAngle=ReadOptional(element,"relativeAngle"),OriginalIndex=i });
            }
            return results;
        }

        private static List<Placement> ParseResult(XElement job, XElement answer,
            List<SourcePart> parts, out double pitch, out double top, out double bottom)
        {
            if (answer == null || (string)answer.Attribute("protocol") != "2" ||
                (string)answer.Attribute("id") != (string)job.Attribute("id") ||
                (string)answer.Attribute("status") != "COMPLETED" ||
                (string)answer.Attribute("copies") != "2")
                throw new InvalidDataException("Desktop result version / job ID mismatch.");
            pitch = Read(answer, "pitch"); top = Read(answer, "top"); bottom = Read(answer, "bottom");
            double gap = Read(answer, "gap"), width = Read(answer, "width");
            if (pitch <= 0 || width <= 0 || gap < 0 || top < 0 || bottom < 0)
                throw new InvalidDataException("Invalid pitch or margins in result.");
            var byHandle = parts.ToDictionary(p => p.Handle, StringComparer.OrdinalIgnoreCase);
            var list = new List<Placement>();
            var groups = new Dictionary<string, HashSet<int>>(StringComparer.OrdinalIgnoreCase);
            var nodes = answer.Element("placements");
            if (nodes == null) throw new InvalidDataException("No CAD placements returned.");
            foreach (var el in nodes.Elements("part"))
            {
                string handle = (string)el.Attribute("handle") ?? "";
                int pos = handle.LastIndexOf('#');
                int unit;
                SourcePart source;
                if (pos < 1 || !int.TryParse(handle.Substring(pos + 1), out unit) ||
                    unit < 1 || unit > 12 || !byHandle.TryGetValue(handle.Substring(0, pos), out source))
                    throw new InvalidDataException("Unknown part identity: " + handle);
                HashSet<int> indices;
                if (!groups.TryGetValue(source.Handle, out indices))
                {
                    indices = new HashSet<int>(); groups[source.Handle] = indices;
                }
                if (!indices.Add(unit)) throw new InvalidDataException("Duplicate part in Desktop result.");
                list.Add(new Placement { Source = source, Handle = handle,
                    Center = new Point2d(Read(el, "x"), Read(el, "y")), Angle = Read(el, "angle") });
            }
            if (list.Count is < 1 or > 12) throw new InvalidDataException("Invalid parts per P.");
            foreach (var pair in groups)
                for (int unit = 1; unit <= pair.Value.Count; unit++)
                    if (!pair.Value.Contains(unit)) throw new InvalidDataException("Missing indexed part copy.");
            return list;
        }

        private static void EnsureLayer(Transaction tr, Database db, string name, int color)
        {
            var table = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (table.Has(name)) return;
            table.UpgradeOpen();
            var rec = new LayerTableRecord { Name = name, Color = Autodesk.AutoCAD.Colors.Color.FromColorIndex(
                Autodesk.AutoCAD.Colors.ColorMethod.ByAci, (short)color) };
            table.Add(rec); tr.AddNewlyCreatedDBObject(rec, true);
        }
        private static List<SourcePart> RemoveNestedHoles(List<SourcePart> all)
        {
            return all.Where(candidate => !all.Any(outer =>
                outer != candidate && Math.Abs(outer.SignedArea) > Math.Abs(candidate.SignedArea) * 1.00001 &&
                candidate.Polygon.All(p => Inside(p, outer.Polygon)))).ToList();
        }
        internal static bool Inside(Point2d p, List<Point2d> ring)
        {
            bool result = false;
            for (int i = 0, j = ring.Count - 1; i < ring.Count; j = i++)
            {
                var a = ring[i]; var b = ring[j];
                if ((a.Y > p.Y) != (b.Y > p.Y) &&
                    p.X < (b.X - a.X) * (p.Y - a.Y) / (b.Y - a.Y) + a.X)
                    result = !result;
            }
            return result;
        }
        private static Point3d PolygonCenter(List<Point2d> p) => new Point3d(
            (p.Min(x => x.X) + p.Max(x => x.X)) * .5,
            (p.Min(x => x.Y) + p.Max(x => x.Y)) * .5, 0);
        internal static double Area(List<Point2d> p)
        {
            double twice = 0;
            for (int i = 0; i < p.Count; i++)
            { var a = p[i]; var b = p[(i + 1) % p.Count]; twice += a.X * b.Y - b.X * a.Y; }
            return twice * .5;
        }
        internal static List<Point2d> Tessellate(Polyline pl, double sagitta)
        {
            var result = new List<Point2d>();
            for (int i = 0; i < pl.NumberOfVertices; i++)
            {
                Point2d a = pl.GetPoint2dAt(i), b = pl.GetPoint2dAt((i + 1) % pl.NumberOfVertices);
                if (result.Count == 0 || result[result.Count - 1].GetDistanceTo(a) > 1e-8) result.Add(a);
                double bulge = pl.GetBulgeAt(i);
                if (Math.Abs(bulge) < 1e-10) continue;
                double sweep = 4 * Math.Atan(bulge);
                double chord = a.GetDistanceTo(b);
                if (chord <= 1e-10) continue;
                double radius = Math.Abs(chord / (2.0 * Math.Sin(sweep / 2)));
                var mid = new Point2d((a.X + b.X) * .5, (a.Y + b.Y) * .5);
                double h = chord / (2 * Math.Tan(sweep / 2));
                double nx = -(b.Y - a.Y) / chord, ny = (b.X - a.X) / chord;
                double cx = mid.X + nx * h, cy = mid.Y + ny * h;
                double start = Math.Atan2(a.Y - cy, a.X - cx);
                double maxArc = radius > sagitta ? 2 * Math.Acos(Math.Max(-1.0, 1.0 - sagitta / radius)) : Math.PI / 8;
                double required = Math.Ceiling(Math.Abs(sweep) / Math.Max(.005, maxArc));
                if (required > 2000) throw new InvalidOperationException(Lang.T("MultiTooDetailed"));
                int count = Math.Max(1, (int)required);
                for (int j = 1; j < count; j++)
                {
                    double t = start + sweep * j / count;
                    result.Add(new Point2d(cx + radius * Math.Cos(t), cy + radius * Math.Sin(t)));
                }
            }
            return result;
        }
    }

    // DNest V38 modal command lock: CAD stays protected until Desktop exits.
    // Closing Desktop without Apply cancels the CAD session without drawing.
    internal sealed class DlayoutDesktopWaitForm : Form
    {
        private readonly Process process;
        private readonly string result;
        private readonly DlayoutPreloadSession preload;
        private readonly string jobPath;
        private readonly Timer poll;
        private readonly Timer launchDelay;
        private bool dispatched;
        private bool activated;
        private int exitTicks;
        public System.Exception DispatchError { get; private set; }

        public DlayoutDesktopWaitForm(DlayoutPreloadSession session, string pendingJobPath, string resultFile)
        {
            preload = session ?? throw new ArgumentNullException(nameof(session));
            process = session.DesktopProcess;
            jobPath = pendingJobPath;
            LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
            result = resultFile;
            Text = "Dlayout V105";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            Width = 465;
            Height = 135;
            ControlBox = false;
            MinimizeBox = false;
            MaximizeBox = false;
            Controls.Add(new Label {
                Dock = DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Padding = new Padding(15),
                Text = Lang.T("MultiWindowInstruction") + "\n" +
                    Lang.T("MultiChooseHint")
            });
            poll = new Timer { Interval = 250 };
            poll.Tick += OnTick;
            // Do not use Thread.Sleep or DoEvents inside a CAD command. A WinForms
            // timer allows the CAD modal gate to paint and process pending input.
            launchDelay = new Timer { Interval = 400 };
            launchDelay.Tick += OnLaunchDelay;
            Shown += (sender, args) => { poll.Start(); launchDelay.Start(); };
            FormClosed += (sender, args) => {
                launchDelay.Stop(); launchDelay.Dispose();
                poll.Stop(); poll.Dispose();
            };
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hwnd);

        private void OnLaunchDelay(object sender, EventArgs args)
        {
            launchDelay.Stop();
            try
            {
                // The Desktop process already exists but blocks on the private pipe;
                // this is the ONLY operation that allows MainForm to become visible.
                preload.SendJob(jobPath);
                dispatched = true;
            }
            catch (System.Exception ex)
            {
                DispatchError = ex;
                DialogResult = DialogResult.Cancel;
                Close();
            }
        }

        private void ActivateDesktopOnce()
        {
            if (activated || !dispatched) return;
            try
            {
                process.Refresh();
                IntPtr hwnd = process.MainWindowHandle;
                if (hwnd == IntPtr.Zero) return; // Desktop is not visible yet.
                activated = true;
                // One initial activation only; never steal focus back from CAD.
                SetForegroundWindow(hwnd);
            }
            catch { activated = true; }
        }

        private void OnTick(object sender, EventArgs args)
        {
            bool exited;
            try { exited = process == null || process.HasExited; }
            catch { exited = true; }
            if (!exited)
            {
                exitTicks = 0;
                ActivateDesktopOnce();
                return;
            }
            // Let the Desktop's atomic result.xml flush finish before consuming it.
            if (File.Exists(result))
            {
                poll.Stop();
                DialogResult = DialogResult.OK;
                Close();
                return;
            }
            if (++exitTicks >= 4)
            {
                poll.Stop();
                DialogResult = DialogResult.Cancel;
                Close();
            }
        }
    }
}
