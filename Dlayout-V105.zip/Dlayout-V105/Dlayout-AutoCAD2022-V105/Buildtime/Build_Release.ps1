param()
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$LogDir = Join-Path $Root 'log'
$BinDir = Join-Path $Root 'bin'
$ObjDir = Join-Path $Root 'obj'
$LogFile = Join-Path $LogDir 'Build-V105.log'
New-Item -ItemType Directory -Path $LogDir,$BinDir -Force | Out-Null
if (Test-Path $LogFile) { Remove-Item -LiteralPath $LogFile -Force }
function Log([string]$Message) { $Message | Tee-Object -FilePath $LogFile -Append }
function Fail([string]$Message) { Log $Message; exit 1 }
function RunStep([string]$Name,[string]$Executable,[string[]]$Parameters) {
    Log ('[' + $Name + ']')
    # Preserve the native process exit code before any other command runs.
    & $Executable @Parameters 2>&1 | ForEach-Object { Log ([string]$_) }
    $rc = $LASTEXITCODE
    if ($rc -ne 0) { Fail ($Name + ' FAIL (exit ' + $rc + ')') }
}
Log 'Dlayout V105 AutoCAD2022 BUILD'
Log 'TargetFramework=net48; Configuration=Release; Platform=x64'
$validator = Join-Path $Root 'Buildtime\Validate_Language.ps1'
if (-not (Test-Path $validator)) { Fail 'LANGUAGE QA FAIL: missing Validate_Language.ps1' }
RunStep 'LANGUAGE QA' 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File',$validator)
$required = @('AcCoreMgd.dll','AcDbMgd.dll','AcMgd.dll')
foreach ($name in $required) {
    if (-not (Test-Path (Join-Path $Root ('Reference\' + $name)))) { Fail ('HARD STOP: missing Reference\' + $name) }
}
$extra = @(Get-ChildItem (Join-Path $Root 'Reference') -File | Where-Object { $_.Name -notin $required })
if ($extra.Count -gt 0) { Fail ('HARD STOP: unexpected Reference files: ' + (($extra.Name) -join ', ')) }
$proj = Join-Path $Root 'Layout_material.csproj'
# Clean generated output BEFORE restore; never allow stale obj/assets to masquerade as a new build.
if (Test-Path $ObjDir) { Remove-Item $ObjDir -Recurse -Force }
Get-ChildItem $BinDir -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
$msbuild = $null
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (Test-Path $vswhere) {
    $found = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' 2>$null | Select-Object -First 1
    if ($found) { $msbuild = [string]$found }
}
if (-not $msbuild) { $command = Get-Command msbuild.exe -ErrorAction SilentlyContinue; if ($command) { $msbuild = $command.Source } }
if (-not $msbuild) { Fail 'HARD STOP: Visual Studio MSBuild not found; install MSBuild and .NET Framework 4.8 targeting pack.' }
Log ('MSBuild=' + $msbuild)
# SDK-style net48 requires a NuGet Restore too. V45 skipped it and failed with NETSDK1004.
$dotnet = Get-Command dotnet.exe -ErrorAction SilentlyContinue
if (-not $dotnet) { Fail 'HARD STOP: dotnet SDK not found for net48 NuGet restore.' }
RunStep 'RESTORE' $dotnet.Source @('restore',$proj,'--property:Configuration=Release','--property:Platform=x64','--verbosity','minimal')
$assets = Join-Path $ObjDir 'project.assets.json'
if (-not (Test-Path $assets)) { Fail 'RESTORE FAIL: obj\project.assets.json not generated' }
RunStep 'BUILD' $msbuild @($proj,'/nologo','/t:Build','/p:Configuration=Release','/p:Platform=x64','/p:RestoreDuringBuild=false','/v:minimal')
$dll = Join-Path $BinDir 'DlayoutC22.dll'
if (-not (Test-Path $dll)) { Fail 'BUILD FAIL: expected DLL missing: DlayoutC22.dll' }
$unexpected = @(Get-ChildItem $BinDir -File | Where-Object { $_.Name -ne 'DlayoutC22.dll' })
if ($unexpected.Count -gt 0) { $unexpected | Remove-Item -Force }
Log ('BUILD PASS: ' + $dll)
exit 0
