DLAYOUT V105 - RETURN TO SOLUTIONS + FIT TO MATERIAL LENGTH - 05/11/2026

BASELINE AND SCOPE
- V105 has been rebuilt independently from the original Dlayout-V102.zip source, not patched on V103/V104.
- V102 optimizers, solution picker, source selection, existing fixed-count drawing and DUser INI format remain unchanged.
- In the CAD editor, choose Back to Solutions, or enter Solutions in DrawJig, to reselect without rerunning Desktop.
- Use Length... to fit the maximum complete stations into material length L, with the original G gap at both strip ends.
- Size of existing CAD edit window remains 470x500; only localized Back and Length controls are added.
- New features are source-only pending Windows build and CAD NETLOAD verification.
- CAD selection no longer rejects entities based on a DLAYOUT_ layer-name prefix.
  Previously generated part copies can therefore be selected again as source geometry.
- During selection, layers currently Lock/Off/Freeze are temporarily unlocked, turned
  On and Thawed so their objects can be picked. Their original states are restored
  immediately after selection and before contour processing; source layers are not
  left changed by Dlayout.
- The CAD insertion dialog now offers MATER, the current layer, and existing drawing
  layers as the destination for inserted part copies. The selection is saved in the
  single DUser\Dlayout_settings.ini file.
- The selected destination layer is made On, Thawed and Unlocked before insertion.
  Source layers are not modified. The DLAYOUT_STRIP helper layer is also made visible
  and writable for the strip boundary and annotation.
- At the CAD "Choose solution" step, the solution picker now sorts by Angle,
  Efficiency, Step/Pitch (P), or Height/Width (W), in ascending or descending order.
  Nearest-value search uses the same four fields and orders the full solution list
  by absolute distance from the entered value, nearest first.
- The Desktop results panel retains its matching sort/search controls. The Desktop
  now also transmits each solution's global tested angle to CAD; this is the optimizer
  sweep angle, not the individual rotation angle of a part.
- The optimizer, geometry scoring, global Top-N archive, per-angle journal and live
  preview remain unchanged. CAD job protocol 2 / schema version 98 remains compatible.

SUPPORTED CAD
- AutoCAD 2022 (.NET Framework 4.8): DlayoutC22.dll
- AutoCAD 2025 (.NET 8 Windows): DlayoutC25.dll
- GstarCAD 2027 (.NET 8 Windows): DlayoutG27.dll
- CAD command: DLAYOUT only.

INSTALLATION / FILE LOCATIONS
1. Register DIRECT folders DUser and DProgram in the active CAD profile:
   CAD Options -> Files -> Support File Search Path.
2. Place the V105 Desktop executable at DProgram\Dlayout\Dlayout.exe.
3. DUser\Dlayout_settings.ini is the ONE long-term configuration file Dlayout owns.
   See Docs\DUser_settings_example.ini for the format and suggested values.
4. DUser\MIS_SET.SET is shared and read-only for CAD language.
5. Legacy Layout_material_*, AppData Preferences.xml/ContourSelections.xml and
   Dlayout_strip.ini are not read or written by this package.
6. To run standalone Dlayout.exe, pass --duser "C:\DCAD\DUser", or choose the
   existing DUser directory when asked (no AppData fallback).

TEMPORARY CAD-DESKTOP DATA
- %TEMP%\DCAD\DlayoutBridge\<SessionID>\job.xml / result.xml / session.log
- Automatically removed after successful CAD commit or normal user cancellation.
- Errors, unsuccessful calculations or broken handoff are copied to
  DUser\Dlayout_diagnostics\<SessionID> (job, result if present, trace, error.log).
- The diagnostic archive is NOT automatically deleted.

BUILD
- On Windows x64 run Build_All.cmd in ZIP root; it runs all targets and a Desktop
  SelfTest and generates portable Dprogram only after PASS checks.
- Each CAD/Desktop branch includes Build_Release.cmd.
- Windows BUILD PASS, CAD NETLOAD and real-machine output are NOT VERIFIED here.
- For manual QA see Docs\QA_V105.md and Docs\CHANGES_V105.txt.
