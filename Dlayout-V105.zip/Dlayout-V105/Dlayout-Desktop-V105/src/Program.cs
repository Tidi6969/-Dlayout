using System.Windows.Forms;
using System.Drawing;
using System.Globalization;
using System.Reflection;

namespace DCAD.Dlayout;
internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Contains("--selftest")) return SelfTest.Run(args.SkipWhile(a => a != "--selftest").Skip(1).ToArray());
            if (args.Contains("--probe"))
            {
                Console.WriteLine("Dlayout Desktop V105; Input=DXF; Output=DXF; Periodic=1; LivePreview=1");
                return 0;
            }
            ApplicationConfiguration.Initialize();
            string? session = GetArgValue(args, "--preload-session");
            if (!string.IsNullOrWhiteSpace(session))
            {
                long hwnd = 0;
                int lang = 1;
                long.TryParse(GetArgValue(args, "--cad-owner-hwnd"), NumberStyles.Integer, CultureInfo.InvariantCulture, out hwnd);
                int.TryParse(GetArgValue(args, "--language-index"), NumberStyles.Integer, CultureInfo.InvariantCulture, out lang);
                return DlayoutPreloadServer.Run(session, lang, new IntPtr(hwnd));
            }
            string? path = null;
            string? cadJob = null;
            for (int i = 0; i + 1 < args.Length; i++) if (args[i] == "--dxf") path = args[i + 1];
            else if (args[i] == "--job") cadJob = args[i + 1];
            if (path == null && args.Length == 1 && args[0].EndsWith(".dxf", StringComparison.OrdinalIgnoreCase)) path = args[0];
            if (cadJob != null) { DlayoutSettingsStore.ConfigureFromJob(cadJob); CadRunTrace.Start(cadJob); }
            else
            {
                string? duserArg = GetArgValue(args, "--duser");
                if (!string.IsNullOrWhiteSpace(duserArg)) DlayoutSettingsStore.Configure(duserArg);
                else
                {
                    using var picker = new FolderBrowserDialog {
                        Description = "Select the existing DIRECT DCAD DUser folder (Dlayout settings).",
                        ShowNewFolderButton = false };
                    if (picker.ShowDialog() != DialogResult.OK) return 0;
                    DlayoutSettingsStore.Configure(picker.SelectedPath);
                }
            }
            int savedLanguage = PreferenceStore.LoadLanguage();
            string? cadLanguage = GetArgValue(args, "--language-index");
            int requestedLanguage;
            if (cadJob != null && int.TryParse(cadLanguage, NumberStyles.Integer,
                    CultureInfo.InvariantCulture, out requestedLanguage))
                Strings.Load(requestedLanguage);
            else Strings.Load(savedLanguage);
            var mainForm = new MainForm(path, cadJob);
            if (cadJob != null) mainForm.ShowInTaskbar = false;
            Application.Run(mainForm);
            return 0;
        }
        catch (Exception ex)
        {
            CadRunTrace.Write("ERROR: " + ex);
            MessageBox.Show(ex.ToString(), "Dlayout Desktop", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    private static string? GetArgValue(string[] args, string name)
    {
        for (int i = 0; i + 1 < args.Length; ++i)
            if (string.Equals(args[i], name, StringComparison.OrdinalIgnoreCase))
                return args[i + 1];
        return null;
    }
}
internal static class Strings
{
    private static readonly Dictionary<int, Dictionary<string, string>> All = new();
    private static int language;
    public static void Load(int lang)
    {
        language = Math.Clamp(lang, 0, 5);
        if (All.Count > 0) return;
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Dlayout.Buildtime.lang.dat");
        if (stream == null) throw new InvalidDataException("Missing embedded Dlayout lang.dat");
        using var reader = new StreamReader(stream);
        Dictionary<string, string>? block = null;
        foreach (var raw in reader.ReadToEnd().Replace("\r", "").Split('\n'))
        {
            var line = raw.Trim();
            if (line.StartsWith("Lang_", StringComparison.Ordinal) && int.TryParse(line.Split('(')[0].Substring(5), out int code))
            {
                block = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                All[code] = block;
            }
            else if (line == "-") block = null;
            else if (block != null && !line.StartsWith("#") && line.Contains('='))
            {
                int pos = line.IndexOf('='); block[line[..pos]] = line[(pos + 1)..];
            }
        }
    }
    public static string F(string key, params object[] args)
    {
        string template = T(key);
        try { return string.Format(CultureInfo.CurrentCulture, template, args); }
        catch (FormatException) { return template; }
    }
    public static int CurrentLanguage => language;
    public static string T(string key)
    {
        if (All.TryGetValue(language, out var localized) && localized.TryGetValue(key, out var text)) return text;
        return All.TryGetValue(0, out var english) && english.TryGetValue(key, out var fallback) ? fallback : key;
    }
}
