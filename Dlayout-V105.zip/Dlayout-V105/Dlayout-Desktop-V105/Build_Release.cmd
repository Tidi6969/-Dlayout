@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "NO_PAUSE=0"
if /I "%~1"=="/nopause" set "NO_PAUSE=1"
set "BUILD_EXIT_CODE=1"
if not exist "log" mkdir "log" >nul 2>&1
if not exist "log" (
    echo [FAIL] Cannot create Desktop log directory.
    goto :FINISH
)
set "LOG=%~dp0log\Build-V105.log"
>"%LOG%" echo Dlayout Desktop V105 BUILD / net8.0-windows x64
if not exist "Buildtime\lang.dat" (
    >>"%LOG%" echo [FAIL] Missing embedded language source
    goto :FINISH
)
>>"%LOG%" echo [LANGUAGE QA]
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Buildtime\Validate_Language.ps1" >>"%LOG%" 2>&1
if errorlevel 1 goto :FINISH
>>"%LOG%" echo [RESTORE] win-x64
where dotnet.exe >>"%LOG%" 2>&1
if errorlevel 1 goto :FINISH
dotnet restore "Dlayout.csproj" -r win-x64 >>"%LOG%" 2>&1
if errorlevel 1 goto :FINISH
>>"%LOG%" echo [PUBLISH] portable self-contained EXE
if exist "bin\Publish" rmdir /s /q "bin\Publish"
dotnet publish "Dlayout.csproj" -c Release -r win-x64 --no-restore -p:Platform=x64 -o "%~dp0bin\Publish" >>"%LOG%" 2>&1
if errorlevel 1 goto :FINISH
if not exist "bin\Publish\Dlayout.exe" goto :FINISH
set "BUILD_EXIT_CODE=0"
:FINISH
if "%BUILD_EXIT_CODE%"=="0" (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[PASS] Desktop V105 - Release x64' -ForegroundColor Green"
    if defined LOG >>"%LOG%" echo BUILD PASS
) else (
    powershell.exe -NoProfile -NonInteractive -Command "Write-Host '[FAIL] Desktop V105 - see log\Build-V105.log' -ForegroundColor Red"
    if defined LOG >>"%LOG%" echo BUILD FAIL
)
if "%NO_PAUSE%"=="0" (
    echo Nhan phim bat ky de thoat... / Press any key to close this window...
    pause >nul
)
endlocal & exit /b %BUILD_EXIT_CODE%
