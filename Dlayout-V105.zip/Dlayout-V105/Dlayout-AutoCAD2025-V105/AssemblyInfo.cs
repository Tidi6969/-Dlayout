using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Dlayout")]
[assembly: AssemblyDescription("Layout material AutoCAD2025 add-in")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Dlayout")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("0c53cf1b-7b9a-4e5f-bf0c-7d594a600443")]
[assembly: AssemblyVersion("1.0.105.0")]
[assembly: AssemblyFileVersion("1.0.105.0")]
[assembly: AssemblyInformationalVersion("Dlayout-V105")]
