using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Gssoft.Gscad.DatabaseServices;
using Gssoft.Gscad.EditorInput;
using Gssoft.Gscad.Geometry;
using Gssoft.Gscad.GraphicsInterface;
using Gssoft.Gscad.ApplicationServices;
using LayoutMaterial.Commands;
using AcApp = Gssoft.Gscad.ApplicationServices.Application;
using CadEntity = Gssoft.Gscad.DatabaseServices.Entity;

namespace LayoutMaterial.Services
{
    // AutoCAD 2022-only. Desktop V70 remains the canonical optimiser. All
    // changes here are post-solve parameter editing, CAD preview and atomic draw.
    internal sealed class CadStripEditor
    {
        private readonly Document document;
        private readonly List<DlayoutMultiCommand.Placement> placements;
        private readonly double originalPitch, originalWidth, top, bottom, gap;
        private double minX, maxX;
        private readonly double minY, maxY, netArea;
        private Point3d insertion;
        private readonly Dictionary<DlayoutMultiCommand.SourcePart, int> partOrdinal =
            new Dictionary<DlayoutMultiCommand.SourcePart, int>();
        private StripDisplaySettings drawSettings;
        private bool byLength;
        private double stripLength;
        private int lengthSteps;
        internal bool BackToSolutions { get; private set; }
        internal int DrawSteps => byLength ? lengthSteps : drawSettings.Steps;
        internal StripColorMode ColorMode => drawSettings.ColorMode;
        internal double Pitch { get; private set; }
        internal double Width { get; private set; }
        internal double Efficiency => netArea / (Pitch * Width) * 100;
        internal double MinimumWidth => maxY - minY + top + bottom;
        private static bool Finite(double n) => !double.IsNaN(n) && !double.IsInfinity(n);

        internal CadStripEditor(Document doc, List<DlayoutMultiCommand.Placement> placed,
            double pitch, double width, double t, double b, double clearance)
        {
            // Work on private copies: revisiting an option must not alter its archived solution.
            document = doc;
            placements = placed.Select(p => new DlayoutMultiCommand.Placement {
                Source = p.Source, Handle = p.Handle, Center = p.Center, Angle = p.Angle
            }).ToList();
            drawSettings = StripDisplaySettingsStore.Load();
            foreach (var placement in placements)
                if (!partOrdinal.ContainsKey(placement.Source))
                    partOrdinal.Add(placement.Source, partOrdinal.Count);
            originalPitch = Pitch = pitch; originalWidth = Width = width;
            top = t; bottom = b; gap = clearance;
            if (!Finite(pitch) || !Finite(width) || pitch <= 0 || width <= 0 ||
                clearance < 0 || t < 0 || b < 0 || placed.Count == 0)
                throw new InvalidOperationException("Invalid Dlayout Desktop result.");
            double x1 = double.PositiveInfinity, x2 = double.NegativeInfinity;
            double y1 = double.PositiveInfinity, y2 = double.NegativeInfinity;
            double a = 0;
            foreach (var p in placements)
            {
                a += p.Source.NetArea;
                foreach (var q in TransformedOutline(p))
                {
                    x1 = Math.Min(x1, q.X); x2 = Math.Max(x2, q.X);
                    y1 = Math.Min(y1, q.Y); y2 = Math.Max(y2, q.Y);
                }
            }
            minX = x1; maxX = x2; minY = y1; maxY = y2; netArea = a;
            RebaseToCurrentPitch();
            if (!Finite(netArea) || netArea <= 0)
                throw new InvalidOperationException("Missing usable CAD shape area.");
        }

        internal bool EditAndPick()
        {
            using (var sources = new SourceTemplates(document.Database, placements))
            {
                while (true)
                {
                    using (var edit = new EditForm(originalPitch, originalWidth, Pitch, Width,
                        MinimumWidth, netArea, drawSettings, document.Database,
                        gap, SpanAtPitch, placements.Count, byLength, stripLength))
                    {
                        DialogResult choice = AcApp.ShowModalDialog(edit);
                        if (choice == DialogResult.Retry)
                        { BackToSolutions = true; return false; }
                        if (choice != DialogResult.OK) return false;
                        Pitch = edit.Pitch; Width = edit.Width;
                        // The chosen drawing phase must follow the edited P,
                        // not the far-away integer-period offsets from solving.
                        RebaseToCurrentPitch();
                        byLength = edit.ByLength;
                        stripLength = edit.StripLength;
                        if (byLength)
                        {
                            lengthSteps = StripLengthFit.Count(stripLength, gap, maxX - minX, Pitch);
                            if (lengthSteps < 1)
                            {
                                MessageBox.Show(Lang.T(lengthSteps == -2 ? "StripLengthExcess" :
                                    "StripLengthInsufficient"), Lang.T("StripDialogTitle"),
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                continue;
                            }
                        }
                        else drawSettings.Steps = edit.Steps; // Keep V102 INI schema unchanged.
                        drawSettings.ColorMode = edit.ColorMode;
                        drawSettings.TargetLayer = edit.TargetLayer;
                    }
                    bool userReducedPitch = Pitch + 1e-6 < originalPitch;
                    bool userReducedWidth = Width + 1e-6 < originalWidth;
                    bool widthOutsideStrip = Width + 1e-6 < MinimumWidth;
                    string failure = CadStripValidator.InvalidReason(placements, Pitch, Width,
                        gap, byLength ? false : userReducedPitch,
                        byLength ? DrawSteps : int.MaxValue);
                    if (failure != null)
                    {
                        MessageBox.Show(failure, Lang.T("StripDialogTitle"),
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }
                    // User overrides P/W are advisory only. Show all applicable
                    // engineering risks together, then honor positive finite inputs.
                    // The geometry itself is not rescaled/cropped by the strip edge.
                    var warnings = new List<string>();
                    if (userReducedPitch)
                        warnings.Add(Lang.F("StripPitchBelowComputed",
                            Pitch.ToString("0.###", CultureInfo.InvariantCulture),
                            originalPitch.ToString("0.###", CultureInfo.InvariantCulture)));
                    if (userReducedWidth)
                        warnings.Add(Lang.F("StripWidthBelowComputed",
                            Width.ToString("0.###", CultureInfo.InvariantCulture),
                            originalWidth.ToString("0.###", CultureInfo.InvariantCulture)));
                    if (widthOutsideStrip)
                        warnings.Add(Lang.F("StripWidthBelowRequired",
                            Width.ToString("0.###", CultureInfo.InvariantCulture),
                            MinimumWidth.ToString("0.###", CultureInfo.InvariantCulture)));
                    if (warnings.Count > 0)
                        MessageBox.Show(string.Join(Environment.NewLine + Environment.NewLine,
                            warnings.ToArray()), Lang.T("Warning"),
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    var jig = new PlacementPreviewJig(this, sources);
                    var drag = document.Editor.Drag(jig);
                    if (jig.RequestSettings) continue;
                    if (jig.RequestSolutions)
                    { BackToSolutions = true; return false; }
                    if (drag.Status != PromptStatus.OK) return false;
                    Point3d point = jig.Position;
                    insertion = new Point3d(point.X, point.Y, 0);
                    // Final invariant check after preview but before any DB write.
                    failure = CadStripValidator.InvalidReason(placements, Pitch, Width,
                        gap, byLength ? false : userReducedPitch,
                        byLength ? DrawSteps : int.MaxValue);
                    if (failure != null) throw new InvalidOperationException(failure);
                    return true;
                }
            }
        }

        internal void Commit()
        {
            // Reject invalid drawing configuration before any CAD database mutation.
            if ((byLength ? (DrawSteps < 1 || DrawSteps > StripDisplaySettings.MaxSteps ||
                    StripLengthFit.Count(stripLength, gap, maxX - minX, Pitch) != DrawSteps)
                    : !StripDisplaySettings.ValidSteps(DrawSteps)) ||
                !Enum.IsDefined(typeof(StripColorMode), ColorMode))
                throw new InvalidOperationException(Lang.T("StripInvalidSteps"));
            // Always keep the selected CAD language, including for SHX styles.
            // Some SHX fonts cannot render every Unicode glyph; warn without
            // modifying the text or the user's active TextStyle.
            string annotation = Annotation();
            if (annotation.Any(c => c > 127) && IsCurrentStyleShx(document.Database))
                document.Editor.WriteMessage("\n[Dlayout] " + Lang.T("StripShxUnicodeWarning"));
            using (var tr = document.Database.TransactionManager.StartTransaction())
            {
                var db = document.Database;
                var space = (BlockTableRecord)tr.GetObject(db.CurrentSpaceId, OpenMode.ForWrite);
                string targetLayerName = ResolveTargetLayer(tr, db, drawSettings.TargetLayer);
                EnsureLayer(tr, db, targetLayerName, 7, targetLayerName.Equals("MATER", StringComparison.OrdinalIgnoreCase));
                EnsureLayer(tr, db, "DLAYOUT_STRIP", 8, true);
                foreach (var p in placements)
                {
                    foreach (var id in AllIds(p.Source))
                    {
                        var original = tr.GetObject(id, OpenMode.ForRead) as CadEntity;
                        if (original == null || original.IsErased)
                            throw new InvalidOperationException(Lang.T("StripSourceMissing"));
                        for (int step = 0; step < DrawSteps; step++)
                        {
                            var clone = original.Clone() as CadEntity;
                            if (clone == null) throw new InvalidOperationException(Lang.T("StripCloneFailed"));
                            Transform(clone, p, step, insertion);
                            clone.Layer = targetLayerName;
                            if (ColorMode != StripColorMode.Original)
                                clone.ColorIndex = ColorIndexFor(p, step);
                            // Source entities are never modified. All inserted part
                            // copies use the user-selected destination layer.
                            space.AppendEntity(clone);
                            tr.AddNewlyCreatedDBObject(clone, true);
                        }
                    }
                }
                double xStart = insertion.X;
                double xEnd = byLength ? insertion.X + stripLength :
                    insertion.X + (maxX - minX) + (DrawSteps - 1) * Pitch;
                double extra = byLength ? 0 : Math.Max(1, (xEnd - xStart) * .03);
                foreach (double y in new[] { insertion.Y, insertion.Y + Width })
                {
                    var line = new Line(new Point3d(xStart - extra, y, 0), new Point3d(xEnd + extra, y, 0))
                    { Layer = "DLAYOUT_STRIP", ColorIndex = 8 };
                    space.AppendEntity(line); tr.AddNewlyCreatedDBObject(line, true);
                }
                double textHeight = Math.Max(.5, Math.Min(10, Width * .04));
                var note = new MText {
                    Location = new Point3d(xStart, insertion.Y + Width + textHeight * 1.5, 0),
                    TextHeight = textHeight, Layer = "DLAYOUT_STRIP", ColorIndex = 8,
                    TextStyleId = db.Textstyle, Attachment = AttachmentPoint.BottomLeft,
                    Contents = annotation
                };
                space.AppendEntity(note); tr.AddNewlyCreatedDBObject(note, true);
                tr.Commit();
            }
            try { document.Editor.Regen(); }
            catch (System.Exception ex)
            {
                document.Editor.WriteMessage("\n[DLAYOUT] REGEN warning: " + ex.Message);
            }
            // Last-used display settings are saved only after CAD Commit succeeds.
            try { StripDisplaySettingsStore.Save(drawSettings); }
            catch (Exception ex)
            {
                document.Editor.WriteMessage("\n" + Lang.F("StripSettingsSaveWarning", ex.Message));
            }
        }

        private int ColorIndexFor(DlayoutMultiCommand.Placement part, int step)
        {
            if (ColorMode == StripColorMode.ByStation)
                return StripAciPalette.ForIndex(step);
            if (ColorMode == StripColorMode.ByPart)
                return StripAciPalette.ForIndex(partOrdinal[part.Source]);
            return 256;
        }

        internal string Annotation() => "P=" + Pitch.ToString("0.###", CultureInfo.InvariantCulture) +
            "  W=" + Width.ToString("0.###", CultureInfo.InvariantCulture) +
            "  " + Lang.T("StripEfficiencyLabel") + "=" + Efficiency.ToString("0.##", CultureInfo.InvariantCulture) + "%" +
            (byLength ? "  L=" + stripLength.ToString("0.###", CultureInfo.InvariantCulture) +
                "  N=" + DrawSteps.ToString(CultureInfo.InvariantCulture) : string.Empty);

        private static bool IsCurrentStyleShx(Database db)
        {
            try
            {
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    var style = tr.GetObject(db.Textstyle, OpenMode.ForRead) as TextStyleTableRecord;
                    return style != null && (style.FileName ?? string.Empty).EndsWith(
                        ".shx", StringComparison.OrdinalIgnoreCase);
                }
            }
            catch { return false; } // Never override the active CAD text style.
        }

        // Choose each part's equivalent period so its LEFTMOST boundary begins
        // within the first P zone. All source CAD entities belonging to the part
        // (outer boundary, holes and companion curves) share the same transform.
        // A silhouette physically wider than P cannot fit wholly in a P-wide
        // zone: never scale, clip or silently change the optimiser's P for that.
        private double SpanAtPitch(double candidatePitch)
        {
            if (!Finite(candidatePitch) || candidatePitch <= 0) return double.NaN;
            var extents = new List<(double Left, double Right)>();
            double anchor = double.PositiveInfinity;
            foreach (var p in placements)
            {
                var points = TransformedOutline(p);
                double left = points.Min(q => q.X), right = points.Max(q => q.X);
                if (!Finite(left) || !Finite(right)) return double.NaN;
                extents.Add((left, right));
                anchor = Math.Min(anchor, left);
            }
            double leftBound = double.PositiveInfinity, rightBound = double.NegativeInfinity;
            foreach (var bounds in extents)
            {
                double shift = Math.Floor((bounds.Left - anchor) / candidatePitch) * candidatePitch;
                if (!Finite(shift)) return double.NaN;
                leftBound = Math.Min(leftBound, bounds.Left - shift);
                rightBound = Math.Max(rightBound, bounds.Right - shift);
            }
            return rightBound - leftBound;
        }

        private void RebaseToCurrentPitch()
        {
            if (!Finite(Pitch) || Pitch <= 0) throw new InvalidOperationException(Lang.T("StripPitchPositive"));
            double anchor = double.PositiveInfinity;
            var bounds = new List<(DlayoutMultiCommand.Placement Part, double Left)>();
            foreach (var p in placements)
            {
                double left = TransformedOutline(p).Min(q => q.X);
                if (!Finite(left)) throw new InvalidOperationException(Lang.T("StripNoParts"));
                bounds.Add((p, left));
                anchor = Math.Min(anchor, left);
            }
            foreach (var item in bounds)
            {
                double periods = Math.Floor((item.Left - anchor) / Pitch);
                double shift = periods * Pitch;
                if (!Finite(shift)) throw new InvalidOperationException(Lang.T("StripPitchPositive"));
                var p = item.Part;
                p.Center = new Point2d(p.Center.X - shift, p.Center.Y);
            }
            minX = double.PositiveInfinity; maxX = double.NegativeInfinity;
            foreach (var p in placements)
                foreach (var q in TransformedOutline(p))
                {
                    minX = Math.Min(minX, q.X);
                    maxX = Math.Max(maxX, q.X);
                }
        }

        private void Transform(CadEntity entity, DlayoutMultiCommand.Placement p, int station, Point3d at)
        {
            entity.TransformBy(Matrix3d.Rotation(p.Angle * Math.PI / 180.0,
                Vector3d.ZAxis, p.Source.Center));
            var shift = new Vector3d(
                p.Center.X - p.Source.Center.X + at.X - minX + station * Pitch +
                    (byLength ? gap : 0),
                p.Center.Y - p.Source.Center.Y + at.Y - minY + bottom, 0);
            entity.TransformBy(Matrix3d.Displacement(shift));
        }
        private static IEnumerable<ObjectId> AllIds(DlayoutMultiCommand.SourcePart p)
        {
            yield return p.Id;
            foreach (ObjectId id in p.InnerContours) yield return id;
        }
        private static List<Point2d> TransformedOutline(DlayoutMultiCommand.Placement p)
        {
            var points = new List<Point2d>(p.Source.Polygon.Count);
            double theta = p.Angle * Math.PI / 180.0;
            double cosine = Math.Cos(theta), sine = Math.Sin(theta);
            foreach (var q in p.Source.Polygon)
            {
                double dx = q.X - p.Source.Center.X, dy = q.Y - p.Source.Center.Y;
                points.Add(new Point2d(p.Center.X + dx * cosine - dy * sine,
                    p.Center.Y + dx * sine + dy * cosine));
            }
            return points;
        }
        private static string ResolveTargetLayer(Transaction tr, Database db, string setting)
        {
            if (string.Equals(setting, StripDisplaySettings.CurrentLayerToken, StringComparison.Ordinal))
            {
                var current = tr.GetObject(db.Clayer, OpenMode.ForRead) as LayerTableRecord;
                if (current == null) throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
                return current.Name;
            }
            if (string.IsNullOrWhiteSpace(setting))
                throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
            string name = setting.Trim();
            if (name.IndexOf('|') >= 0)
                throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
            var layers = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (!layers.Has(name) && !name.Equals("MATER", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
            return name;
        }

        private static void EnsureLayer(Transaction tr, Database db, string name, int color, bool createIfMissing)
        {
            var layers = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            if (layers.Has(name))
            {
                var existing = tr.GetObject(layers[name], OpenMode.ForWrite) as LayerTableRecord;
                if (existing == null || existing.Name.IndexOf('|') >= 0)
                    throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
                // A destination layer must be writable and visible for the new copies.
                // Only the destination/helper layer is normalized; source layers are untouched.
                existing.IsOff = false;
                existing.IsFrozen = false;
                existing.IsLocked = false;
                return;
            }
            if (!createIfMissing)
                throw new InvalidOperationException(Lang.T("StripLayerUnavailable"));
            layers.UpgradeOpen();
            var record = new LayerTableRecord {
                Name = name, Color = Gssoft.Gscad.Colors.Color.FromColorIndex(
                    Gssoft.Gscad.Colors.ColorMethod.ByAci, (short)color)
            };
            layers.Add(record);
            tr.AddNewlyCreatedDBObject(record, true);
        }

        private sealed class SourceTemplates : IDisposable
        {
            internal readonly List<(CadEntity Entity, DlayoutMultiCommand.Placement Part)> Entities =
                new List<(CadEntity, DlayoutMultiCommand.Placement)>();
            internal SourceTemplates(Database db, IEnumerable<DlayoutMultiCommand.Placement> parts)
            {
                try
                {
                    using (var tr = db.TransactionManager.StartTransaction())
                    {
                        foreach (var p in parts)
                            foreach (var id in AllIds(p.Source))
                            {
                                var entity = tr.GetObject(id, OpenMode.ForRead) as CadEntity;
                                if (entity == null || entity.IsErased)
                                    throw new InvalidOperationException(Lang.T("StripSourceMissing"));
                                var clone = entity.Clone() as CadEntity;
                                if (clone == null) throw new InvalidOperationException(Lang.T("StripCloneFailed"));
                                Entities.Add((clone, p));
                            }
                        tr.Commit();
                    }
                }
                catch { Dispose(); throw; }
            }
            public void Dispose()
            {
                foreach (var e in Entities) e.Entity.Dispose();
                Entities.Clear();
            }
        }

        private sealed class PlacementPreviewJig : DrawJig
        {
            private readonly CadStripEditor owner;
            private readonly SourceTemplates templates;
            internal Point3d Position { get; private set; }
            internal bool RequestSettings { get; private set; }
            internal bool RequestSolutions { get; private set; }
            internal PlacementPreviewJig(CadStripEditor editor, SourceTemplates sources)
            { owner = editor; templates = sources; Position = Point3d.Origin; }
            protected override SamplerStatus Sampler(JigPrompts prompts)
            {
                var opt = new JigPromptPointOptions("\n" + Lang.T("StripEditPrompt") +
                    Lang.T("StripBackHint"))
                { UserInputControls = UserInputControls.Accept3dCoordinates };
                opt.Keywords.Add("Settings");
                opt.Keywords.Add("Solutions");
                var got = prompts.AcquirePoint(opt);
                if (got.Status == PromptStatus.Keyword)
                {
                    RequestSolutions = string.Equals(got.StringResult, "Solutions", StringComparison.OrdinalIgnoreCase);
                    RequestSettings = !RequestSolutions;
                    return SamplerStatus.Cancel;
                }
                if (got.Status != PromptStatus.OK) return SamplerStatus.Cancel;
                if (got.Value.IsEqualTo(Position)) return SamplerStatus.NoChange;
                Position = got.Value;
                return SamplerStatus.OK;
            }
            protected override bool WorldDraw(WorldDraw draw)
            {
                var at = new Point3d(Position.X, Position.Y, 0);
                foreach (var template in templates.Entities)
                    for (int step = 0; step < owner.DrawSteps; step++)
                    {
                        using (var drawn = (CadEntity)template.Entity.Clone())
                        {
                            owner.Transform(drawn, template.Part, step, at);
                            if (owner.ColorMode != StripColorMode.Original)
                                drawn.ColorIndex = owner.ColorIndexFor(template.Part, step);
                            draw.Geometry.Draw(drawn);
                        }
                    }
                double end = owner.byLength ? at.X + owner.stripLength :
                    at.X + owner.maxX - owner.minX + (owner.DrawSteps - 1) * owner.Pitch;
                double extra = owner.byLength ? 0 : Math.Max(1, (end - at.X) * .03);
                foreach (double y in new[] { at.Y, at.Y + owner.Width })
                    using (var line = new Line(new Point3d(at.X - extra, y, 0),
                        new Point3d(end + extra, y, 0)) { ColorIndex = 8 })
                        draw.Geometry.Draw(line);
                double height = Math.Max(.5, Math.Min(10, owner.Width * .04));
                using (var note = new MText {
                    Location = new Point3d(at.X, at.Y + owner.Width + height * 1.5, 0),
                    TextHeight = height, TextStyleId = owner.document.Database.Textstyle,
                    Attachment = AttachmentPoint.BottomLeft,
                    Contents = owner.Annotation(), ColorIndex = 8 })
                    draw.Geometry.Draw(note);
                return true;
            }
        }

        private static bool TryNumber(string input, out double value)
        {
            return (double.TryParse(input, NumberStyles.Float, CultureInfo.CurrentCulture, out value) ||
                double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) &&
                Finite(value);
        }

        private sealed class StripLengthDialog : Form
        {
            private readonly RadioButton fixedCount = new RadioButton();
            private readonly RadioButton fitLength = new RadioButton();
            private readonly TextBox input = new TextBox();
            internal bool ByLength { get; private set; }
            internal double Length { get; private set; }
            internal StripLengthDialog(bool enabled, double previousLength)
            {
                LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
                Text = Lang.T("StripLengthTitle");
                StartPosition = FormStartPosition.CenterParent;
                FormBorderStyle = FormBorderStyle.FixedDialog;
                MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
                ClientSize = new Size(390, 194);
                Font = new System.Drawing.Font("Segoe UI", 10);
                fixedCount.SetBounds(16, 12, 356, 27);
                fitLength.SetBounds(16, 48, 356, 27);
                fixedCount.Text = Lang.T("StripFixedCount");
                fitLength.Text = Lang.T("StripFitLength");
                Controls.Add(fixedCount); Controls.Add(fitLength);
                Controls.Add(new Label { Left=17,Top=89,Width=188,Height=26,
                    Text=Lang.T("StripLengthLabel") });
                input.SetBounds(212, 85, 158, 29);
                input.Text = previousLength > 0 ? previousLength.ToString("G17", CultureInfo.CurrentCulture) : string.Empty;
                Controls.Add(input);
                fixedCount.Checked = !enabled;
                fitLength.Checked = enabled;
                fixedCount.CheckedChanged += (s, e) => input.Enabled = fitLength.Checked;
                fitLength.CheckedChanged += (s, e) => input.Enabled = fitLength.Checked;
                input.Enabled = enabled;
                var ok = new Button { Text = Lang.T("Ok") };
                var cancel = new Button { Text = Lang.T("Cancel"), DialogResult = DialogResult.Cancel };
                ok.SetBounds(193, 144, 84, 34);
                cancel.SetBounds(286, 144, 84, 34);
                Controls.Add(ok); Controls.Add(cancel);
                AcceptButton = ok; CancelButton = cancel;
                ok.Click += (s, e) =>
                {
                    double length;
                    if (fitLength.Checked && (!TryNumber(input.Text, out length) || length <= 0))
                    {
                        MessageBox.Show(this, Lang.T("StripLengthInvalid"), Text,
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    ByLength = fitLength.Checked;
                    Length = TryNumber(input.Text, out length) && length > 0 ? length : 0;
                    DialogResult = DialogResult.OK;
                    Close();
                };
            }
        }

        private sealed class EditForm : Form
        {
            private readonly TextBox inputP = new TextBox(), inputW = new TextBox();
            private readonly NumericUpDown inputSteps = new NumericUpDown();
            private readonly Button lengthOptions = new Button();
            private readonly ComboBox inputColorMode = new ComboBox();
            private readonly ComboBox inputTargetLayer = new ComboBox();
            private readonly Label result = new Label(), validity = new Label();
            private readonly Button preview = new Button();
            private readonly double minWidth, net, baseP, baseW, clearance;
            private readonly Func<double, double> projectedSpan;
            private readonly int partsPerStation;
            private bool byLength, updating, hasLength;
            private double targetLength;
            private int fixedSteps;
            internal bool ByLength => byLength;
            internal double StripLength => targetLength;
            internal double Pitch { get; private set; }
            internal double Width { get; private set; }
            internal int Steps { get; private set; }
            internal StripColorMode ColorMode { get; private set; }
            internal string TargetLayer { get; private set; } = "MATER";
            private sealed class LayerChoice
            {
                internal readonly string Value;
                private readonly string display;
                internal LayerChoice(string value, string text) { Value = value; display = text; }
                public override string ToString() => display;
            }
            internal EditForm(double initialP, double initialW, double currentP, double currentW,
                double min, double usableArea, StripDisplaySettings display, Database db,
                double edgeGap, Func<double, double> spanForPitch, int partCount,
                bool startByLength, double startLength)
            {
                baseP = initialP; baseW = initialW; minWidth = min; net = usableArea;
                clearance = edgeGap; projectedSpan = spanForPitch; partsPerStation = partCount;
                byLength = startByLength; targetLength = startLength; hasLength = startLength > 0;
                fixedSteps = StripDisplaySettings.ValidSteps(display.Steps) ? display.Steps : 2;
                LayoutMaterial.UI.UiAssets.AttachTitleIcon(this);
                Text = Lang.T("StripDialogTitle");
                StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
                MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
                ClientSize = new Size(470, 500); Font = new System.Drawing.Font("Segoe UI", 10);
                Controls.Add(new Label { Left=20, Top=15, Width=435, Height=28,
                    Text=Lang.T("StripDesktopValues") });
                Controls.Add(new Label { Left=20, Top=54, Width=176, Height=24, Text=Lang.T("StripPitchLabel") });
                Controls.Add(new Label { Left=20, Top=92, Width=176, Height=24, Text=Lang.T("StripWidthLabel") });
                Controls.Add(new Label { Left=20, Top=130, Width=176, Height=24, Text=Lang.T("StripDrawSteps") });
                Controls.Add(new Label { Left=20, Top=168, Width=176, Height=24, Text=Lang.T("StripColorMode") });
                Controls.Add(new Label { Left=20, Top=206, Width=176, Height=24, Text=Lang.T("StripTargetLayer") });
                inputP.SetBounds(205, 49, 238, 29); inputW.SetBounds(205, 87, 238, 29);
                inputP.Text = currentP.ToString("G17", CultureInfo.CurrentCulture);
                inputW.Text = currentW.ToString("G17", CultureInfo.CurrentCulture);
                Controls.Add(inputP); Controls.Add(inputW);
                inputSteps.SetBounds(205, 126, 113, 29);
                inputSteps.Minimum = byLength ? 1 : 2;
                inputSteps.Maximum = StripDisplaySettings.MaxSteps;
                inputSteps.Increment = 1;
                inputSteps.DecimalPlaces = 0;
                inputSteps.Value = fixedSteps;
                inputSteps.Enabled = !byLength;
                Controls.Add(inputSteps);
                lengthOptions.Text = Lang.T("StripLengthButton");
                lengthOptions.SetBounds(325, 126, 118, 29);
                Controls.Add(lengthOptions);
                inputColorMode.DropDownStyle = ComboBoxStyle.DropDownList;
                inputColorMode.SetBounds(205, 164, 238, 29);
                inputColorMode.Items.AddRange(new object[] {
                    Lang.T("StripColorOriginal"), Lang.T("StripColorByStation"), Lang.T("StripColorByPart") });
                inputColorMode.SelectedIndex = (int)display.ColorMode;
                Controls.Add(inputColorMode);
                inputTargetLayer.DropDownStyle = ComboBoxStyle.DropDownList;
                inputTargetLayer.SetBounds(205, 202, 238, 29);
                inputTargetLayer.DropDownWidth = 300;
                foreach (LayerChoice choice in ReadLayerChoices(db)) inputTargetLayer.Items.Add(choice);
                int targetIndex = -1;
                for (int i = 0; i < inputTargetLayer.Items.Count; i++)
                    if (string.Equals(((LayerChoice)inputTargetLayer.Items[i]).Value,
                        display.TargetLayer, StringComparison.OrdinalIgnoreCase)) { targetIndex = i; break; }
                inputTargetLayer.SelectedIndex = targetIndex >= 0 ? targetIndex : 0;
                Controls.Add(inputTargetLayer);
                result.SetBounds(20, 247, 435, 30); Controls.Add(result);
                validity.SetBounds(20, 282, 435, 142); validity.ForeColor=Color.Maroon;
                validity.AutoSize = false; Controls.Add(validity);
                preview.Text = Lang.T("StripPreview"); preview.SetBounds(193, 445, 153, 35);
                var cancel = new Button { Text=Lang.T("Cancel"), DialogResult=DialogResult.Cancel };
                var back = new Button { Text=Lang.T("StripBackSolutions"), DialogResult=DialogResult.Retry };
                back.SetBounds(20, 445, 165, 35);
                cancel.SetBounds(355, 445, 88, 35);
                Controls.Add(back); Controls.Add(preview); Controls.Add(cancel);
                CancelButton = cancel;
                inputP.TextChanged += (sender, e) => Recompute();
                inputW.TextChanged += (sender, e) => Recompute();
                inputSteps.ValueChanged += (sender, e) => Recompute();
                inputColorMode.SelectedIndexChanged += (sender, e) => Recompute();
                inputTargetLayer.SelectedIndexChanged += (sender, e) => Recompute();
                lengthOptions.Click += (sender, e) =>
                {
                    using (var choices = new StripLengthDialog(byLength, hasLength ? targetLength : 0))
                    {
                        if (choices.ShowDialog(this) != DialogResult.OK) return;
                        if (!byLength && choices.ByLength) fixedSteps = (int)inputSteps.Value;
                        byLength = choices.ByLength;
                        targetLength = choices.Length;
                        hasLength = targetLength > 0;
                        inputSteps.Enabled = !byLength;
                        if (!byLength)
                        {
                            updating = true;
                            try
                            {
                                inputSteps.Minimum = 2;
                                inputSteps.Value = fixedSteps;
                            }
                            finally { updating = false; }
                        }
                        Recompute();
                    }
                };
                preview.Click += (sender, e) => { if (Recompute()) { DialogResult=DialogResult.OK; Close(); } };
                Recompute();
            }
            private static List<LayerChoice> ReadLayerChoices(Database db)
            {
                var choices = new List<LayerChoice> {
                    new LayerChoice("MATER", Lang.T("StripLayerMater"))
                };
                using (var tr = db.TransactionManager.StartTransaction())
                {
                    string currentName = "0";
                    var current = tr.GetObject(db.Clayer, OpenMode.ForRead) as LayerTableRecord;
                    if (current != null) currentName = current.Name;
                    choices.Add(new LayerChoice(StripDisplaySettings.CurrentLayerToken,
                        Lang.F("StripLayerCurrentValue", currentName)));
                    var table = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
                    var names = new List<string>();
                    foreach (ObjectId id in table)
                    {
                        var layer = tr.GetObject(id, OpenMode.ForRead) as LayerTableRecord;
                        if (layer == null || layer.Name.IndexOf('|') >= 0 ||
                            layer.Name.Equals("MATER", StringComparison.OrdinalIgnoreCase) ||
                            layer.Name.Equals(StripDisplaySettings.CurrentLayerToken, StringComparison.OrdinalIgnoreCase))
                            continue;
                        names.Add(layer.Name);
                    }
                    foreach (string name in names.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
                        choices.Add(new LayerChoice(name, name));
                    tr.Commit();
                }
                return choices;
            }

            private static bool Number(string input, out double number)
            {
                return (double.TryParse(input, NumberStyles.Float, CultureInfo.CurrentCulture, out number) ||
                    double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out number)) &&
                    !double.IsNaN(number) && !double.IsInfinity(number);
            }
            private bool Recompute()
            {
                if (updating) return false;
                updating = true;
                try
                {
                    double p, w;
                    bool valid = Number(inputP.Text, out p) & Number(inputW.Text, out w);
                    valid = valid && p > 0 && w > 0 && inputColorMode.SelectedIndex >= 0 &&
                        inputTargetLayer.SelectedItem is LayerChoice;
                    int computed = 0;
                    if (byLength)
                    {
                        computed = valid ? StripLengthFit.Count(targetLength, clearance,
                            projectedSpan(p), p) : -1;
                        valid = valid && computed > 0;
                        inputSteps.Minimum = 1;
                        if (computed > 0) inputSteps.Value = computed;
                    }
                    else
                    {
                        inputSteps.Minimum = 2;
                        if (inputSteps.Value < 2) inputSteps.Value = fixedSteps;
                        fixedSteps = (int)inputSteps.Value;
                        valid = valid && StripDisplaySettings.ValidSteps(fixedSteps);
                    }
                    if (valid)
                    {
                        Pitch = p; Width = w;
                        Steps = byLength ? computed : fixedSteps;
                        ColorMode = (StripColorMode)inputColorMode.SelectedIndex;
                        TargetLayer = ((LayerChoice)inputTargetLayer.SelectedItem).Value;
                        double oldEta = net / (baseP * baseW) * 100;
                        double eta = net / (p * w) * 100;
                        result.Text = Lang.F("StripEtaFormat", eta.ToString("0.##"), oldEta.ToString("0.##"),
                            (eta - oldEta).ToString("+0.##;-0.##;0"));
                        var hints = new List<string>();
                        if (byLength) hints.Add(Lang.F("StripLengthSummary", computed,
                            (computed * partsPerStation).ToString(CultureInfo.CurrentCulture),
                            targetLength.ToString("0.###", CultureInfo.CurrentCulture),
                            clearance.ToString("0.###", CultureInfo.CurrentCulture)));
                        if (p + 1e-6 < baseP)
                            hints.Add(Lang.F("StripPitchShortHint",
                                baseP.ToString("0.###", CultureInfo.InvariantCulture)));
                        if (w + 1e-6 < baseW)
                            hints.Add(Lang.F("StripWidthShortHint",
                                baseW.ToString("0.###", CultureInfo.InvariantCulture)));
                        if (w + 1e-6 < minWidth)
                            hints.Add(Lang.F("StripWidthOutsideHint",
                                minWidth.ToString("0.###", CultureInfo.InvariantCulture)));
                        validity.Text = hints.Count == 0
                            ? Lang.F("StripMinimumW", minWidth.ToString("0.###", CultureInfo.InvariantCulture))
                            : string.Join(Environment.NewLine, hints.ToArray());
                        validity.ForeColor = (p + 1e-6 < baseP || w + 1e-6 < baseW || w + 1e-6 < minWidth)
                            ? Color.DarkOrange : Color.DarkGreen;
                    }
                    else
                    {
                        result.Text = Lang.T("StripEtaEmpty");
                        validity.Text = byLength
                            ? Lang.T(computed == -2 ? "StripLengthExcess" :
                                computed == 0 ? "StripLengthInsufficient" : "StripLengthInvalid")
                            : !StripDisplaySettings.ValidSteps((int)inputSteps.Value)
                                ? Lang.T("StripInvalidSteps") : Lang.T("StripInvalidPW");
                        validity.ForeColor = Color.Maroon;
                    }
                    preview.Enabled = valid;
                    return valid;
                }
                finally { updating = false; }
            }
        }
    }

    internal static class StripLengthFit
    {
        // Negative: invalid input (-1) / exceeds safe drawing count (-2).
        // Zero: no complete placement fits with G at both ends.
        internal static int Count(double length, double gap, double span, double pitch)
        {
            if (double.IsNaN(length) || double.IsInfinity(length) || length <= 0 ||
                double.IsNaN(gap) || double.IsInfinity(gap) || gap < 0 ||
                double.IsNaN(span) || double.IsInfinity(span) || span < 0 ||
                double.IsNaN(pitch) || double.IsInfinity(pitch) || pitch <= 0) return -1;
            double available = length - 2 * gap - span;
            if (available < 0) return 0;
            double raw = Math.Floor(available / pitch) + 1;
            if (double.IsNaN(raw) || double.IsInfinity(raw) || raw > StripDisplaySettings.MaxSteps) return -2;
            int count = (int)raw;
            while (count > 0 && span + (count - 1) * pitch + 2 * gap > length) count--;
            return count;
        }
    }

    internal static class CadStripValidator
    {
        private static bool Finite(double n) => !double.IsNaN(n) && !double.IsInfinity(n);
        private sealed class Placed
        {
            internal Point2d[] Points;
            internal double MinX, MaxX, MinY, MaxY;
        }
        internal static string InvalidReason(List<DlayoutMultiCommand.Placement> parts,
            double pitch, double width, double gap,
            bool allowReducedUserPitch = false, int repeatCount = int.MaxValue)
        {
            if (!Finite(pitch) || pitch <= 0) return Lang.T("StripPitchPositive");
            // A smaller manual W may put some parts outside the two strip
            // boundaries, but is not a reason to block CAD preview/drawing.
            if (!Finite(width) || width <= 0)
                return Lang.T("StripWidthInvalid");
            if (parts.Count == 0) return Lang.T("StripNoParts");
            var placed = parts.Select(ToPlaced).ToArray();
            for (int i = 0; i < placed.Length; i++)
                for (int j = i + 1; j < placed.Length; j++)
                    if (TooClose(placed[i], placed[j], gap, 0)) return Lang.T("StripGapOne");
            // Only periodic overlap checks are advisory for a deliberately
            // reduced manual P. Positive P, width and in-step clearances remain mandatory.
            if (allowReducedUserPitch || repeatCount <= 1) return null;
            double minX = placed.Min(p => p.MinX), maxX = placed.Max(p => p.MaxX);
            double cycles = Math.Ceiling((maxX - minX + gap + .02) / pitch);
            // Validate before converting to int: a tiny positive P could
            // otherwise overflow, bypass all collision checks, and commit.
            if (!Finite(cycles) || cycles > 100000)
                return Lang.T("StripPitchTiny");
            int periods = (int)Math.Min(cycles, (double)repeatCount - 1);
            for (int k = 1; k <= periods; k++)
            {
                double dx = k * pitch;
                for (int i = 0; i < placed.Length; i++)
                    for (int j = 0; j < placed.Length; j++)
                        if (TooClose(placed[i], placed[j], gap, dx))
                            return Lang.F("StripGapRepeat", k);
            }
            return null;
        }
        private static Placed ToPlaced(DlayoutMultiCommand.Placement p)
        {
            double angle = p.Angle * Math.PI / 180, co = Math.Cos(angle), si = Math.Sin(angle);
            Point2d[] points = p.Source.Polygon.Select(q => {
                double x = q.X - p.Source.Center.X, y = q.Y - p.Source.Center.Y;
                return new Point2d(p.Center.X + x * co - y * si, p.Center.Y + x * si + y * co);
            }).ToArray();
            return new Placed { Points=points, MinX=points.Min(q=>q.X), MaxX=points.Max(q=>q.X),
                MinY=points.Min(q=>q.Y), MaxY=points.Max(q=>q.Y) };
        }
        private static bool Inside(Point2d[] ring, double x, double y)
        {
            bool inside = false;
            for (int i=0, j=ring.Length-1; i<ring.Length; j=i++)
            {
                Point2d a=ring[i], b=ring[j];
                if ((a.Y>y)!=(b.Y>y) && x<(b.X-a.X)*(y-a.Y)/(b.Y-a.Y)+a.X) inside = !inside;
            }
            return inside;
        }
        private static double Cross(Point2d a,Point2d b,Point2d c) =>
            (b.X-a.X)*(c.Y-a.Y)-(b.Y-a.Y)*(c.X-a.X);
        private static bool ProperIntersect(Point2d a,Point2d b,Point2d c,Point2d d) =>
            Cross(a,b,c)*Cross(a,b,d)<-1e-16 && Cross(c,d,a)*Cross(c,d,b)<-1e-16;
        private static double SegmentPointDist2(Point2d a, Point2d b, Point2d p)
        {
            double dx=b.X-a.X,dy=b.Y-a.Y,px=p.X-a.X,py=p.Y-a.Y;
            double denominator=dx*dx+dy*dy;
            if (denominator<=1e-20) return px*px+py*py;
            double t=Math.Max(0,Math.Min(1,(dx*px+dy*py)/denominator));
            double x=a.X+t*dx-p.X, y=a.Y+t*dy-p.Y;
            return x*x+y*y;
        }
        private static bool TooClose(Placed a, Placed b,double gap,double dx)
        {
            double req=gap+.01001;
            if (a.MaxX+req<b.MinX+dx || b.MaxX+dx+req<a.MinX ||
                a.MaxY+req<b.MinY || b.MaxY+req<a.MinY) return false;
            if (Inside(a.Points,b.Points[0].X+dx,b.Points[0].Y) ||
                Inside(b.Points,a.Points[0].X-dx,a.Points[0].Y)) return true;
            double limit=req*req;
            for(int i=0;i<a.Points.Length;i++)
            {
                Point2d a1=a.Points[i],a2=a.Points[(i+1)%a.Points.Length];
                for(int j=0;j<b.Points.Length;j++)
                {
                    Point2d p=b.Points[j],q=b.Points[(j+1)%b.Points.Length];
                    Point2d b1=new Point2d(p.X+dx,p.Y),b2=new Point2d(q.X+dx,q.Y);
                    if(Math.Max(a1.X,a2.X)+req<Math.Min(b1.X,b2.X) ||
                        Math.Max(b1.X,b2.X)+req<Math.Min(a1.X,a2.X) ||
                        Math.Max(a1.Y,a2.Y)+req<Math.Min(b1.Y,b2.Y) ||
                        Math.Max(b1.Y,b2.Y)+req<Math.Min(a1.Y,a2.Y)) continue;
                    if(ProperIntersect(a1,a2,b1,b2) ||
                        SegmentPointDist2(a1,a2,b1)<limit || SegmentPointDist2(a1,a2,b2)<limit ||
                        SegmentPointDist2(b1,b2,a1)<limit || SegmentPointDist2(b1,b2,a2)<limit) return true;
                }
            }
            return false;
        }
    }
}
